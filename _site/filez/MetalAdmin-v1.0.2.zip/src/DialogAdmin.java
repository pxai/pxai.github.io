//
//Title:        Jini Administrator
//Version:      
//Copyright:    Copyright (c) 1998
//Author:       Pello Xabier Altadill Izura
//Company:      Pello X ltd.
//Description:  Jini Inguruneak administratzeko tresna

package com.ebila.jini.JiniAdministrator;

//import gunea
import java.awt.*;
import java.awt.event.*;
import net.jini.admin.JoinAdmin;
import net.jini.core.discovery.LookupLocator;
import net.jini.core.lookup.ServiceItem;
import net.jini.core.lookup.ServiceID;
import net.jini.lookup.entry.ServiceInfo;
//import com.sun.jini.lookup.entry.BasicService;
import net.jini.core.entry.Entry;
import com.sun.jini.admin.DestroyAdmin;
import com.sun.jini.admin.StorageLocationAdmin;
import java.rmi.RemoteException;
import java.net.MalformedURLException;

// klasearen deklarazioa
public
class DialogAdmin
extends Dialog {

  // atributuak
  Panel panel1 = new Panel();
  BorderLayout borderLayout1 = new BorderLayout();
  Panel panelLabela = new Panel();
  Label labelTituloa = new Label();
  Label labelZerbitzu = new Label();
  FlowLayout flowLayout1 = new FlowLayout();
  Label labelHost = new Label();
  Panel panelControl = new Panel();
  GridLayout gridLayout1 = new GridLayout();
  Panel panelLocator = new Panel();
  FlowLayout flowLayout2 = new FlowLayout();
  Panel panelStorage = new Panel();
  FlowLayout flowLayout4 = new FlowLayout();
  Panel panelGroups = new Panel();
  Panel panelDestroy = new Panel();
  FlowLayout flowLayout5 = new FlowLayout();
  Label labelLocator = new Label();
  Label labelGroups = new Label();
  Label labelStorage = new Label();
  List listLocator = new List();
  List listTaldeak = new List();
  TextField textFieldStorage = new TextField();
  Button buttonLocatorDel = new Button();
  TextField textFieldLocator = new TextField();
  Button buttonLocatorAdd = new Button();
  Button buttonGroupsDel = new Button();
  TextField textFieldGroups = new TextField();
  Button buttonGroupsAdd = new Button();
  Button buttonStorage = new Button();
  Button buttonDestroy = new Button();
  List listEntry = new List();
  Button buttonServiceInfo = new Button();
  Button button2 = new Button();
  Button buttonService2 = new Button();
  Panel panelBotoiak = new Panel();
  Panel panelEntry = new Panel();
  FlowLayout flowLayout3 = new FlowLayout();
  Label labelEntry = new Label();
  GridLayout gridLayout2 = new GridLayout();
  PanelLookup plookup = null;
  protected String zerbitzuID;
  DestroyAdmin zerbitzuSuntsitzailea = null;
  JoinAdmin joinAdministratzailea = null;
  StorageLocationAdmin storageLocationAdmin = null;
  ServiceItem si = null;
  ServiceInfo serviceInfo = null;



  // eraikitzailea
  public DialogAdmin(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    zerbitzuID = title;
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try  {
      jbInit();
      add(panel1);
      pack();
      this.setLocation(frame.getLocation());
      show();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }



  // konponente grafikoak hasieratzen dituen metodoa
  void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    panelLabela.setLayout(flowLayout1);
    panel1.setBackground(Color.lightGray);
    labelTituloa.setText("Service Administration:");
    labelZerbitzu.setText(zerbitzuID);
    labelHost.setFont(new Font("Dialog", 2, 12));
    labelHost.setText("<host>");
    gridLayout1.setColumns(1);
    labelLocator.setText("LookupLocator:");
    labelGroups.setText("            Groups:");
    labelStorage.setText("Storage:");
    buttonLocatorDel.setLabel("-");
    textFieldStorage.setText("            ");
    textFieldGroups.setText("            ");
    textFieldLocator.setText("            ");
    buttonLocatorDel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonLocatorDel_actionPerformed(e);
      }
    });
    buttonLocatorAdd.setLabel("+");
    buttonLocatorAdd.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonLocatorAdd_actionPerformed(e);
      }
    });
    buttonGroupsDel.setLabel("-");
    buttonGroupsDel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonGroupsDel_actionPerformed(e);
      }
    });
    buttonGroupsAdd.setLabel("+");
    buttonGroupsAdd.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonGroupsAdd_actionPerformed(e);
      }
    });
    buttonStorage.setLabel("ChangeFile");
    listEntry.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        listEntry_mouseClicked(e);
      }
    });
    buttonStorage.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonStorage_actionPerformed(e);
      }
    });
    buttonServiceInfo.setLabel("ServiceInfo");
    buttonServiceInfo.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonServiceInfo_actionPerformed(e);
      }
    });
    button2.setLabel("Attri3");
    button2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        button2_actionPerformed(e);
      }
    });
    buttonService2.setLabel("Basic Service");
    buttonService2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonService2_actionPerformed(e);
      }
    });
    buttonDestroy.setLabel("DESTROY SERVICE");
    buttonDestroy.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonDestroy_actionPerformed(e);
      }
    });
    panelBotoiak.setLayout(gridLayout2);
    panelEntry.setLayout(flowLayout3);
    panelDestroy.setLayout(flowLayout2);
    labelEntry.setText("Entry (attributes):");
    gridLayout2.setRows(3);
    gridLayout2.setColumns(1);
    panelGroups.setLayout(flowLayout5);
    panelStorage.setLayout(flowLayout4);
    panelLocator.setLayout(flowLayout2);
    gridLayout1.setRows(4);
    panelControl.setLayout(gridLayout1);
    panel1.add(panelLabela, BorderLayout.NORTH);
    panelLabela.add(labelTituloa, null);
    panelLabela.add(labelZerbitzu, null);
    panelLabela.add(labelHost, null);
    panel1.add(panelControl, BorderLayout.CENTER);
    panelControl.add(panelLocator, null);
    panelLocator.add(labelLocator, null);
    panelLocator.add(listLocator, null);
    panelLocator.add(buttonLocatorDel, null);
    panelLocator.add(textFieldLocator, null);
    panelLocator.add(buttonLocatorAdd, null);
    panelControl.add(panelGroups, null);
    panelGroups.add(labelGroups, null);
    panelGroups.add(listTaldeak, null);
    panelGroups.add(buttonGroupsDel, null);
    panelGroups.add(textFieldGroups, null);
    panelGroups.add(buttonGroupsAdd, null);
    panelControl.add(panelStorage, null);
    panelStorage.add(labelStorage, null);
    panelStorage.add(textFieldStorage, null);
    panelStorage.add(buttonStorage, null);
    panelDestroy.add(buttonDestroy,null);
    panelControl.add(panelDestroy, null);
    panel1.add(panelEntry, BorderLayout.SOUTH);
    panelEntry.add(labelEntry, null);
    panelEntry.add(listEntry, null);
    panelEntry.add(panelBotoiak, null);
    panelBotoiak.add(buttonServiceInfo, null);
    panelBotoiak.add(buttonService2, null);
    panelBotoiak.add(button2, null);
  }

  // leihoa ixteko gertaera jasotzen duen metodoa
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel();
    }
    super.processWindowEvent(e);
  }

  // leihoa (dialog-a) ixten metodoa
  void cancel() {
    dispose();
  }

  // ButtonLocatorDel sakatzen denean exekutatzen den metodoa
  void buttonLocatorDel_actionPerformed(ActionEvent e) {
					LookupLocator[] taldea = new LookupLocator[1];
			if (joinAdministratzailea != null)
  		 if (!listLocator.getSelectedItem().equals("")) {
  				try {
  						taldea[0] = new LookupLocator(listLocator.getSelectedItem());
  				} catch (MalformedURLException mue) {
            System.err.println("<DialogAdmin> URLa sortzerakoan " + mue.getMessage());
            plookup.log.gehitu(zerbitzuID+  "<DialogAdmin> URLa sortzerakoan " + mue.getMessage());
          }
					try {
  						joinAdministratzailea.removeLookupLocators(taldea);
  						listLocator.delItem(listLocator.getSelectedIndex());
  						plookup.log.gehitu(zerbitzuID+"<DialogAdmin> LookupLocator ezabatua:"+taldea[0].toString());
					} catch (RemoteException rex) {
            System.err.println("<DialogAdmin> Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
            plookup.log.gehitu(zerbitzuID+"<DialogAdmin> delLocator - Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
          }
  			}
  					
  }

  // ButtonLocatorAdd sakatzen denean exekutatzen den metodoa
  void buttonLocatorAdd_actionPerformed(ActionEvent e) {
					LookupLocator[] taldea = new LookupLocator[1];
			if (joinAdministratzailea != null)
  					if (!textFieldLocator.getText().equals("")) {  		
  				try {
  						taldea[0] = new LookupLocator(textFieldLocator.getText());
  						} catch (MalformedURLException mue) {
            System.err.println("<DialogAdmin> URLa sortzerakoan " + mue.getMessage());
            plookup.log.gehitu(zerbitzuID+  "<DialogAdmin> URLa sortzerakoan " + mue.getMessage());
		          }
					try {
  						joinAdministratzailea.addLookupLocators(taldea);
  						listLocator.addItem(textFieldLocator.getText());
  						plookup.log.gehitu(zerbitzuID+"<DialogAdmin> LookupLocator gehitua:"+taldea[0].toString());
					} catch (RemoteException rex) {
            System.err.println("<DialogAdmin> Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
            plookup.log.gehitu(zerbitzuID+"<DialogAdmin> addLocator - Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
          }
        } 
  }

  // ButtonGroupsDel sakatzen denean exekutatzen den metodoa
  void buttonGroupsDel_actionPerformed(ActionEvent e) {
					String[] taldea = null;
			if (joinAdministratzailea != null)
  				try {
  					if (!listTaldeak.getSelectedItem().equals("")) {
  						taldea = new String[1];
  						taldea[0] =	listTaldeak.getSelectedItem();
							joinAdministratzailea.addLookupGroups(taldea);
							listTaldeak.delItem(listTaldeak.getSelectedIndex());
  						plookup.log.gehitu(zerbitzuID+"<DialogAdmin> Lookup Taldea ezabatua:"+taldea[0].toString());
  					}
  					
					} catch (RemoteException rex) {
            System.err.println("<DialogAdmin> Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
            plookup.log.gehitu(zerbitzuID+"<DialogAdmin> delGroup - Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
          } 
  }

  // ButtonGroupsAdd sakatzen denean exekutatzen den metodoa
  void buttonGroupsAdd_actionPerformed(ActionEvent e) {
					String[] taldea = null;
			if (joinAdministratzailea != null)
  				try {
  					if (!textFieldGroups.getText().equals("")) {
  						taldea = new String[1];
  						taldea[0] =	textFieldGroups.getText();
							joinAdministratzailea.addLookupGroups(taldea);
							listTaldeak.addItem(textFieldGroups.getText());
  						plookup.log.gehitu(zerbitzuID+"<DialogAdmin> Lookup Taldea gehitua:"+taldea[0].toString());
  					}
  					
					} catch (RemoteException rex) {
            System.err.println("<DialogAdmin> Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
            plookup.log.gehitu(zerbitzuID+"<DialogAdmin> addGroup - Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
          }      
  }

  // ButtonStorage sakatzen denean exekutatzen den metodoa
  void buttonStorage_actionPerformed(ActionEvent e) {
  		if (storageLocationAdmin != null)
  				try {
  					if (!textFieldStorage.getText().equals("")) {
							storageLocationAdmin.setStorageLocation(textFieldStorage.getText());
              plookup.log.gehitu(zerbitzuID+"<DialogAdmin> StorageLocationAdmin - SorageLocation-a aldatu da.");
  					}
  					
					} catch (Exception rex) {
            System.err.println("<DialogAdmin> Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
            plookup.log.gehitu(zerbitzuID+"<DialogAdmin> StorageLocationAdmin - Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
          }
  }

  // ButtonServiceInfo sakatzen denean exekutatzen den metodoa
  void buttonServiceInfo_actionPerformed(ActionEvent e) {
  				//try {
  					 serviceInfo = null;
  					si = (ServiceItem)plookup.jiniObjektuak.ateraJiniObjektua(zerbitzuID);
  					for (int i = 0; i <si.attributeSets.length;i++) {
  					if (si.attributeSets[i] instanceof ServiceInfo)
  						serviceInfo = (ServiceInfo)si.attributeSets[i];
  				  }
  				  
  				  	DialogServiceInfo dsi = new DialogServiceInfo(plookup.leihoNagusia,"ServiceInfo atributuak zehaztu",true,this);    
							dsi.setSize(400,300);
							dsi.label1.setText("Name:");dsi.textField1.setText(serviceInfo.name);
							dsi.label2.setText("Manufact.:");dsi.textField2.setText(serviceInfo.manufacturer);
							dsi.label3.setText("Vendor:");dsi.textField3.setText(serviceInfo.vendor);
							dsi.label4.setText("Version:");dsi.textField4.setText(serviceInfo.version);
							dsi.label5.setText("Model:");dsi.textField5.setText(serviceInfo.model);
							dsi.label6.setText("Ser. Number:");dsi.textField6.setText(serviceInfo.serialNumber);
							dsi.setLocation(plookup.leihoNagusia.getLocation());
							dsi.show();

					//} catch (RemoteException rex) {
          //  System.err.println("<DialogAdmin> Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
          //}
  }

  // ButtonServiceInfo sakatzen denean exekutatzen den metodoa
  void aldatuServiceInfo(ServiceInfo si) {
  				Entry[] e1 = new Entry[1];
  				Entry[] e2 = new Entry[1];
  				ServiceItem serviceItem = null;
  				Object o = ((ServiceItem)plookup.jiniObjektuak.ateraJiniObjektua(zerbitzuID)).service;
  				ServiceID ID =  ((ServiceItem)plookup.jiniObjektuak.ateraJiniObjektua(zerbitzuID)).serviceID;
  				
  				
  				try {
  						e1[0] = serviceInfo;
  						e2[0] = si;
						 joinAdministratzailea.modifyLookupAttributes(e1,e2);
						 plookup.jiniObjektuak.eguneratuJiniObjektua(zerbitzuID,new ServiceItem(ID,o,e2));
					} catch (RemoteException rex) {
            System.err.println("<DialogAdmin> Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
            plookup.log.gehitu(zerbitzuID+"<DialogAdmin> aldtuAtributuak-Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
          }
  }


  // Button2 sakatzen denean exekutatzen den metodoa
  void buttonService2_actionPerformed(ActionEvent e) {

  	/*			try {
  					
					} catch (RemoteException rex) {
            System.err.println("<DialogAdmin> Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
          }*/
  }

  // Button2 sakatzen denean exekutatzen den metodoa
  void button2_actionPerformed(ActionEvent e) {
  		/*		try {
  					
					} catch (RemoteException rex) {
            System.err.println("<DialogAdmin> Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
          }*/
  }

  // ButtonDestroy sakatzen denean exekutatzen den metodoa
  void buttonDestroy_actionPerformed(ActionEvent e) {
		try {
			if (zerbitzuSuntsitzailea != null)
			zerbitzuSuntsitzailea.destroy();
			plookup.listLookup.remove(zerbitzuID);
			plookup.pdokumentazioa.zerbitzuLista.remove(zerbitzuID);
			plookup.jiniObjektuak.ezabatuJiniObjektua(zerbitzuID);
      plookup.log.gehitu(zerbitzuID+"<DialogAdmin> Attempting to terminate service...");
		} catch (RemoteException rex) {
			System.out.println("<DialogAdmin> Suntsitu - Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());	
      plookup.log.gehitu(zerbitzuID+"<DialogAdmin> Suntsitu - Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
		}
  }
  
  // atributu listan klik egitean exekutatuko den metodoa
  void listEntry_mouseClicked(MouseEvent e) {
  }
}
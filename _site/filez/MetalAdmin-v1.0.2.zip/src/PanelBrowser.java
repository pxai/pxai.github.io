// Panel Browser: Jini Zerbitzuak Unicast moduan bilatzeko,
// hau da, zuzenean Host bat edo zerbitzu IDa baten bitartez
// bilatzen da.
// Panel Lookup-ean, multicast bilaketa egiten da.

package com.ebila.jini.JiniAdministrator;

//import gunea
import java.awt.*;
import java.awt.event.*;
import net.jini.lookup.entry.ServiceInfo;
import java.io.IOException;
// klasearen deklarazioa
public
class PanelBrowser
extends Panel {

  // atributuak
  BorderLayout borderLayout1 = new BorderLayout();
  Panel panelLabel = new Panel();
  FlowLayout flowLayout1 = new FlowLayout();
  Label labelBrowser = new Label();
  protected JiniObjektuak jiniObjektuak;
  Panel panel1 = new Panel();
  FlowLayout flowLayout2 = new FlowLayout();
  Button buttonBilatu = new Button();
  Button buttonGelditu = new Button();
  Button buttonReset = new Button();
  Panel panelErdikoa = new Panel();
  BorderLayout borderLayout2 = new BorderLayout();
  List listTopatutakoak = new List();
  Button buttonGehitu = new Button();
  Panel panelBrowser = new Panel();
  GridLayout gridLayout1 = new GridLayout();
  TextField textFieldHost = new TextField();
  TextField textFieldZerbitzu = new TextField();
  Label labelHost = new Label();
  Label labelID = new Label();
  List listAtributuak = new List();
  Label labelAtributuak = new Label();
  PanelLog plog;
  PanelDokumentazioa pdokumentazioa;
  PanelLookup plookup;
  ServiceInfo serviceInfo = null;
  Thread t = null;

  // eraikitzailea
  public PanelBrowser(JiniObjektuak jo,PanelLog plog,PanelDokumentazioa pdokumentazioa,PanelLookup plookup) {
    jiniObjektuak = jo;
    this.plog = plog;
    this.pdokumentazioa = pdokumentazioa;
    this.plookup = plookup;

    try  {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    panelLabel.setLayout(flowLayout1);
    this.setBackground(Color.lightGray);
    labelBrowser.setText("Panel Browser : searching using unicast mode.");
    buttonBilatu.setLabel("LookUp");
    buttonBilatu.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonBilatu_actionPerformed(e);
      }
    });
    buttonGelditu.setLabel("Stop");
    buttonGelditu.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonGelditu_actionPerformed(e);
      }
    });
    buttonGelditu.setEnabled(false);
    buttonReset.setLabel("Reset values");
    buttonReset.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonReset_actionPerformed(e);
      }
    });
    buttonGehitu.setLabel("ADD to list!!");
    buttonGehitu.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonGehitu_actionPerformed(e);
      }
    });
    buttonGehitu.setEnabled(false);
    gridLayout1.setColumns(2);
    gridLayout1.setRows(3);
    textFieldHost.setText("jini://localhost");
    labelAtributuak.setText("Set attributes (click on list):");
    textFieldZerbitzu.setText("<zerbitzu-id>");
    labelHost.setText("Search by URL or host name:");
    labelID.setText("Search by ServiceID:");
    listAtributuak.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        listAtributuak_mouseClicked(e);
      }
    });
    panelBrowser.setLayout(gridLayout1);
    panelErdikoa.setLayout(borderLayout2);
    panel1.setLayout(flowLayout2);
    this.add(panelLabel, BorderLayout.NORTH);
    panelLabel.add(labelBrowser, null);
    this.add(panel1, BorderLayout.SOUTH);
    panel1.add(buttonBilatu, null);
    panel1.add(buttonGelditu, null);
    panel1.add(buttonReset, null);
    panel1.add(buttonGehitu, null);
    this.add(panelErdikoa, BorderLayout.CENTER);
    panelErdikoa.add(listTopatutakoak, BorderLayout.SOUTH);
    panelErdikoa.add(panelBrowser, BorderLayout.CENTER);
    panelBrowser.add(labelHost, null);
    panelBrowser.add(textFieldHost, null);
    panelBrowser.add(labelID, null);
    panelBrowser.add(textFieldZerbitzu, null);
    panelBrowser.add(labelAtributuak, null);
    panelBrowser.add(listAtributuak, null);
  }

  // Bilatu botoia sakatzen denean exekutatuko den metodoa
  void buttonBilatu_actionPerformed(ActionEvent e) {
    buttonBilatu.setEnabled(false);
    buttonGelditu.setEnabled(true);
    String url = textFieldHost.getText();
    t = new Animazioa(labelBrowser);
    t.start();
    if (textFieldHost.getText().equals(""))
    	url = null;
    try {
    ZerbitzuInformazioa3 zi3 = new ZerbitzuInformazioa3(plookup.statusLabel,plog,plookup,pdokumentazioa,jiniObjektuak,url, listTopatutakoak);
    if (serviceInfo != null) 
    	zi3.attrTemplates[0] = serviceInfo; 
    
    if (url != null) 
    	zi3.findRegistrar(url);
	    buttonGelditu.setEnabled(false);
  	  buttonBilatu.setEnabled(true);
    	t.stop();
    	labelBrowser.setText("Panel Browser : searching using unicast mode.");     
         } catch (IOException ioex) {
    	System.err.println(ioex.getMessage());
    	plog.gehitu("<PanelBrowser> Errorea Lookup-k bilatzerakoan. Konprobatu Host izena.");	
    }
  }

  // Gelditu botoia sakatzen denean exekutatuko den metodoa
  void buttonGelditu_actionPerformed(ActionEvent e) {
    buttonGelditu.setEnabled(false);
    buttonBilatu.setEnabled(true);
    t.stop();
    labelBrowser.setText("Panel Browser : searching using unicast mode.");

  }

  // reset botoia sakatzen denean exekutatuko den metodoa
  void buttonReset_actionPerformed(ActionEvent e) {
    listAtributuak.clear();
    textFieldHost.setText("");
    textFieldZerbitzu.setText("");
  }
  // gehitu botoia sakatzen denean exekutatuko den metodoa
  // honen bitartez, topatutako zerbitzua gehituko da. 
  void buttonGehitu_actionPerformed(ActionEvent e) {

  }

  // xagua listaren gainean klikatzen denean exekutatuko den
  // metodoa. Honen bitartez, atributuak zehazteko Dialog-a
  // irekiko da.
  void listAtributuak_mouseClicked(MouseEvent e) {
		DialogServiceInfo dsi = new DialogServiceInfo(plookup.leihoNagusia,"set ServiceInfo attributes",true,this);    
		dsi.setSize(400,300);
		dsi.label1.setText("Name:");
		dsi.label2.setText("Manufacturer:");
		dsi.label3.setText("Vendor:");
		dsi.label4.setText("Version:");
		dsi.label5.setText("Model:");
		dsi.label6.setText("Ser. Number:");
		dsi.setLocation(plookup.leihoNagusia.getLocation());
		dsi.show();
  }
}
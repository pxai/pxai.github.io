
//Title:        A jini administrator...
//Version:      
//Copyright:    Copyright (c) 1998
//Author:       Pello Xabier Altadill Izura
//Company:      Pello X ltd.
//Description:  Karrera Amaierako Proiektua

package com.ebila.jini.JiniAdministrator;

import java.awt.*;
import java.awt.event.*;

public class DialogError extends Dialog {
  Panel panel1 = new Panel();
  BorderLayout borderLayout1 = new BorderLayout();
  Label labelMezu = new Label();
  Button buttonOk = new Button();
  Panel panelControls = new Panel();


  public DialogError(Frame frame, String title, String mezu, boolean modal) {
    super(frame, title, modal);
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    setLocation(frame.getLocation());
    labelMezu.setText(mezu);
    try  {
      jbInit();
      add(panel1);
      pack();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    hasieratu();
  }



  private void hasieratu () {
   setSize(200,90);
   show();
  }
  void jbInit() throws Exception {
    labelMezu.setAlignment(1);
    buttonOk.setLabel("OK");
    buttonOk.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonOk_actionPerformed(e);
      }
    });
    panel1.setLayout(borderLayout1);
    panel1.add(labelMezu, BorderLayout.CENTER);
    panel1.add(panelControls, BorderLayout.SOUTH);
    panelControls.add(buttonOk, null);
  }

  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel();
    }
    super.processWindowEvent(e);
  }

  void cancel() {
    dispose();
  }

  void buttonOk_actionPerformed(ActionEvent e) {
    dispose();
  }
}

 
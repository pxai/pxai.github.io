// Zerbitzu Informazioa2, zerbitzuInformazioaren luzapena
// besterik ez da.

package com.ebila.jini.JiniAdministrator;


import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceEvent;
import net.jini.core.lookup.ServiceItem;
import net.jini.core.event.RemoteEvent;
import net.jini.core.event.EventRegistration;
import net.jini.core.event.RemoteEventListener;
import net.jini.core.lease.Lease;
import com.sun.jini.lease.LeaseRenewalManager;
import net.jini.discovery.LookupDiscovery;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Hashtable;
import java.io.IOException;
import java.awt.Label;

public 
class ZerbitzuInformazioa2 
extends ZerbitzuInformazioa 
implements Runnable {

    protected Listener listener;
    protected LeaseRenewalManager mgr;
    protected Hashtable leases = new Hashtable();
    protected int transitions = 
	ServiceRegistrar.TRANSITION_MATCH_NOMATCH |
        ServiceRegistrar.TRANSITION_NOMATCH_MATCH |
        ServiceRegistrar.TRANSITION_MATCH_MATCH;
    
    class Listener extends UnicastRemoteObject 
        implements RemoteEventListener {
        
        public Listener() throws RemoteException {
        }
        
        public void notify(RemoteEvent ev) throws RemoteException {
            if (!(ev instanceof ServiceEvent)) {
                System.err.println("Unexpected event: " +
                                   ev.getClass().getName());
                return;
            }
            
            ServiceEvent serviceEvent = (ServiceEvent) ev;
            System.out.println("<zerbitzu informazioa2> Gertaera notifikazioa Lookup-etik!");
            switch (serviceEvent.getTransition()) {
            case ServiceRegistrar.TRANSITION_NOMATCH_MATCH:
                addService(serviceEvent.getServiceItem());
                break;
            case ServiceRegistrar.TRANSITION_MATCH_NOMATCH:
                removeService(serviceEvent.getServiceItem());
                break;
            case ServiceRegistrar.TRANSITION_MATCH_MATCH:
                serviceChanged(serviceEvent.getServiceItem());
                break;
            }
        }
    }
    
    public ZerbitzuInformazioa2(Label labelStatus, PanelLog plog, PanelLookup plookup, PanelDokumentazioa pdokumentazioa, JiniObjektuak jo) 
	throws IOException, RemoteException {
	  super(labelStatus,plog,plookup,pdokumentazioa,jo);
        mgr = new LeaseRenewalManager();
        listener = new Listener();
    }
    
    protected void removeService(ServiceItem item) {
        services.remove(item.serviceID);
        System.out.println("Zerbitzua ez dago eskuragarri: " + item.serviceID);
        ateraZerbitzuInformazioa(item);
    }
    
    protected void serviceChanged(ServiceItem item) {
        services.put(item.serviceID, item);
        System.out.println("Zerbitzua aldatu da: " + item.serviceID);
        ateraZerbitzuInformazioa(item);
    }
    
    // overrride addRegistrar and removeRegistrar to have them
    // ask for/terminate event solicitations whenever we find a 
    // lookup service.
    protected void addRegistrar(ServiceRegistrar reg) {
        try {
            super.addRegistrar(reg);
            
            EventRegistration er = reg.notify(tmpl, 
					      transitions, 
					      listener,
                                              null, 
					      10 * 60 * 1000);
            // do something with lease
            leases.put(reg.getServiceID(), er.getLease());
            mgr.renewFor(er.getLease(), Long.MAX_VALUE, null);
        } catch (RemoteException ex) {
            System.err.println("Can't solicit event: " +
                               ex.getMessage());
        }
    }
    protected void removeRegistrar(ServiceRegistrar reg) {
        try {
            super.removeRegistrar(reg);
            
            // terminate leases on this dude.
            Lease lease = (Lease) leases.get(reg.getServiceID());
        
            if (lease == null)
                return;
        
            leases.remove(reg.getServiceID());
	    // May raise unknown lease exception or
	    // remote exception. Should be ok to ignore
	    // here...
            mgr.cancel(lease);
        } catch (Exception ex) {
        }
    }
    
        // Haria, klase hau funtzionatzen mantentzeko
    public void run() {
        while (true) {
            try {
                Thread.sleep(Long.MAX_VALUE);
            } catch (InterruptedException ex) {
            }
        }
    }

    public void start () {
       if (martxan == 0)
       {
            martxan = 1;
            entzulea(ON);
            lstatus.setText("<zerbitzu informazioa>Bilaketa haria martxan...");
            plogs.gehitu("<zerbitzu informazioa>Bilaketa haria martxan...");
       }
       else
              lstatus.setText("Bilaketa haria dagoeneko martxan...");
    }


    public void stop () {
       if (martxan  != 0)
       {
          martxan = 0;
          entzulea(OFF);
          lstatus.setText("<zerbitzu informazioa>Bilaketa haria geldituta...");
          plogs.gehitu("<zerbitzu informazioa>Bilaketa haria geldituta");
       }
       else
          lstatus.setText("Bilaketa haria dagoeneko geldituta...");
    }

    // entzulea on/off
    // lookup bilatzea eteten bada, entzulea suntsitzen da
    // bestela martxan jartzen da.
    protected void entzulea (int agindua) {
      if (agindua == 1) {
          try {
          // Discovery egiteko klasea martxan jartzen dugu
          // Honen bitartez Lookup-ak bilatuko ditugu
            discoverer = new Discoverer();
            disco =
            new LookupDiscovery(LookupDiscovery.ALL_GROUPS);
            disco.addDiscoveryListener(discoverer);
          } catch (IOException ioex) {
            System.err.println("Errorea Discovery Listener bat sortzerakoan!: "+ioex.getMessage());
          }
      }
      else {
            disco.removeDiscoveryListener(discoverer);
      }
    }

    
}
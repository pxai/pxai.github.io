
//Title:        A jini administrator...
//Version:
//Copyright:    Copyright (c) 1998
//Author:       Pello Xabier Altadill Izura
//Company:      Pello X ltd.
//Description:  Karrera Amaierako Proiektua

package com.ebila.jini.JiniAdministrator;

import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.DataInputStream;

public class PanelLog extends Panel {
  BorderLayout borderLayout1 = new BorderLayout();
  Label labelPanelLog = new Label();
  TextArea textAreaPanelLog = new TextArea();
  Panel panel1 = new Panel();
  FlowLayout flowLayout1 = new FlowLayout();
  Button buttonLog = new Button();
  Button buttonLoad = new Button();
  Label statusLabel;

  public PanelLog(Label status) {
    try  {
      jbInit();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    statusLabel = status;
  }

  void jbInit() throws Exception {
    labelPanelLog.setAlignment(1);
    labelPanelLog.setText("This is log panel");
    buttonLog.setLabel("CLEAR");
    buttonLoad.setLabel("Previous log");
    buttonLoad.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonLoad_actionPerformed(e);
      }
    });
    buttonLog.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonLog_actionPerformed(e);
      }
    });
    panel1.setLayout(flowLayout1);
    this.setLayout(borderLayout1);
    this.add(labelPanelLog, BorderLayout.NORTH);
    this.add(textAreaPanelLog, BorderLayout.CENTER);
    this.add(panel1, BorderLayout.SOUTH);
    panel1.add(buttonLoad, null);
    panel1.add(buttonLog, null);
    textAreaPanelLog.setEditable(false);
  }
  public void gehitu (String mezuBerria) {
    Date gaur = new Date();
    textAreaPanelLog.append("<"+gaur.toString()+">-"+mezuBerria+"\n");
  }

  void buttonLog_actionPerformed(ActionEvent e) {
    textAreaPanelLog.setText("");
  }
  public void gordeLog () throws IOException {
    PrintWriter jal = new PrintWriter(new FileOutputStream("jini-admin.log"));
    jal.println(textAreaPanelLog.getText());
    jal.close();
  }

  public void irakurriLog () throws IOException {
    DataInputStream jal = new DataInputStream(new FileInputStream("jini-admin.log"));
    String temp = null;
      textAreaPanelLog.append("\nPrevious session log:");
    while (!((temp = jal.readLine()) == null))
      textAreaPanelLog.append("\n"+temp);
    jal.close();
  }

  void buttonLoad_actionPerformed(ActionEvent e) {
    try {
    irakurriLog(); } catch (IOException ioex) {
     System.err.println("Error reading log file:"+ioex.getMessage());
    }
  }
}


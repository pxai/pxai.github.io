// Klase honek Jini zerbitzuak bilatzen ditu (Lookup eta bestelako jini zerbitzuak)
// eta ServiceInfo atributua baldinbadute, erakusten da.

// JiniAdministrator paketearen barruan gaude
package com.ebila.jini.JiniAdministrator;


// Import gunea
import net.jini.discovery.LookupDiscovery;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.DiscoveryListener;
import net.jini.core.lookup.ServiceMatches;
import net.jini.core.lookup.ServiceItem;
import net.jini.core.lookup.ServiceTemplate;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.lookup.entry.ServiceInfo;
import net.jini.core.entry.Entry;
import java.util.Hashtable;
import java.util.Vector;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;
import java.io.IOException;
import java.awt.Label;

// klasearen deklarazioa
public 
class ZerbitzuInformazioa
implements Runnable {

    // atributuak
    protected Hashtable registrars = new Hashtable();
    protected Hashtable services = new Hashtable();
    protected ServiceTemplate tmpl;
    protected LookupDiscovery disco;
    protected Discoverer discoverer;
    JiniObjektuak jiniObjektuak;
    Label lstatus;
    PanelLog plogs;
    PanelLookup plookup;
    PanelDokumentazioa pdokumentazioa;
    protected static final int ON = 1;
    protected static final int OFF = 0;
    protected int martxan = 0;


    
  // Inner klasea LookUp-ak bilatzeko
    class Discoverer implements DiscoveryListener {
        public void discovered(DiscoveryEvent ev) {
            ServiceRegistrar[] newregs = ev.getRegistrars();
            for (int i=0 ; i<newregs.length ; i++) {
                addRegistrar(newregs[i]);
            }
        }
        public void discarded(DiscoveryEvent ev) {
            ServiceRegistrar[] newregs = ev.getRegistrars();
            for (int i=0 ; i<newregs.length ; i++) {
                removeRegistrar(newregs[i]);
            }
        }
    }

     // ZerbitzuInformazioa
    // Eraikitzailea
    public ZerbitzuInformazioa(Label labelStatus, PanelLog plog, PanelLookup plookup, PanelDokumentazioa pdokumentazioa, JiniObjektuak jo) throws IOException {
	if (System.getSecurityManager() == null) {
	    System.setSecurityManager(
		    new RMISecurityManager());
	}

        // Plantilla honekin bat datozen zerbitzu guztiak
        // topatuko dira: plantilla hutsa denez, topatzen ditugun Lookup-ak
        // zerbitzu guztiak itzuliko dizkugute.
        Entry[] attrTemplates = new Entry[1];
        attrTemplates[0] = new ServiceInfo(null, null, null, 
                                           null, null, null);
        tmpl = new ServiceTemplate(null, null, attrTemplates);
        
        // Interfazeko atributuak esleitzen dira...
        // honen bitartez, klase honek eragiten dituen mezuak
        // Panel Nagusian isladatu ahal izanen dira.
        LookupDiscovery disco = 
            new LookupDiscovery(LookupDiscovery.ALL_GROUPS);
        disco.addDiscoveryListener(new Discoverer());
	  this.jiniObjektuak = jo;
        this.lstatus = labelStatus;
        this.plogs = plog;
        this.plookup = plookup;
        this.pdokumentazioa = pdokumentazioa;
    }
    
    protected synchronized void addRegistrar(ServiceRegistrar reg) {
        if (registrars.contains(reg.getServiceID()))
            return;
            
        registrars.put(reg.getServiceID(), reg);
        findServices(reg);
    }
    protected synchronized void removeRegistrar(ServiceRegistrar reg) {
        if (!registrars.contains(reg.getServiceID()))
            return;
        
        registrars.remove(reg.getServiceID());
    }

    // lookup zerbitzu batean erregistraturik dauden
    // zerbitzu guztiak ateratzen ditu.    
    void findServices(ServiceRegistrar reg) {
        try {
            ServiceMatches matches = reg.lookup(tmpl, Integer.MAX_VALUE);
        
            for (int i=0 ; i<matches.totalMatches ; i++) {
                if (services.contains(matches.items[i].serviceID))
                    continue;
            
        
                addService(matches.items[i]);
            }
        } catch (RemoteException ex) {
            System.err.println("Ezin izan dut zerbitzurik topatu: " +
                               ex.getMessage());
        }
    }
    
    // zerbitzu berria topatu denean, topatua zegoen ala ez aztertzen
    // da eta prozesatzen da.
    protected void addService(ServiceItem item) {
        services.put(item.serviceID, item);
        lstatus.setText("<zerbitzu-info>Zerbitzu Berria topatu da! " + item.serviceID);
        plogs.gehitu("<zerbitzu-info>Zerbitzu Berria topatu da! " + item.serviceID);
        System.out.println("<zerbitzu-info>Zerbitzu Berria topatu da! " + item.serviceID);
        if (!jiniObjektuak.badago(""+item.serviceID)) {
        jiniObjektuak.sartuJiniObjektua(""+item.serviceID,item);
        ateraZerbitzuInformazioa(item);
        }
        else {
          lstatus.setText("Zerbitzua dagoeneko topatua... " + item.serviceID);
          plogs.gehitu("Zerbitzua dagoeneko topatua... " + item.serviceID);
          System.out.println("Zerbitzua dagoeneko topatua... " + item.serviceID);
        }
    }
    
    // Zerbitzuen Informazioa (ServiceInfo atributuko balioak)
    // inprimatzen dira
    protected void ateraZerbitzuInformazioa(ServiceItem item) {
        for (int i=0 ; i<item.attributeSets.length ; i++) {
            if (item.attributeSets[i] instanceof ServiceInfo) {
                ServiceInfo info = (ServiceInfo) item.attributeSets[i];
                pdokumentazioa.gehituZerbitzua(""+item.serviceID);
                plookup.gehituZerbitzua(""+item.serviceID);
            }
        }
    }
    
    // Haria, klase hau funtzionatzen mantentzeko
    public void run() {
        while (true) {
            try {
                Thread.sleep(Long.MAX_VALUE);
            } catch (InterruptedException ex) {
            }
        }
    }

    public void start () {
       if (martxan == 0)
       {
            martxan = 1;
            entzulea(ON);
            lstatus.setText("<zerbitzu informazioa>Bilaketa haria martxan...");
            plogs.gehitu("<zerbitzu informazioa>Bilaketa haria martxan...");
       }
       else
              lstatus.setText("Bilaketa haria dagoeneko martxan...");
    }


    public void stop () {
       if (martxan  != 0)
       {
          martxan = 0;
          entzulea(OFF);
          lstatus.setText("<zerbitzu informazioa>Bilaketa haria geldituta...");
          plogs.gehitu("<zerbitzu informazioa>Bilaketa haria geldituta");
       }
       else
          lstatus.setText("Bilaketa haria dagoeneko geldituta...");
    }

    // entzulea on/off
    // lookup bilatzea eteten bada, entzulea suntsitzen da
    // bestela martxan jartzen da.
    protected void entzulea (int agindua) {
      if (agindua == 1) {
          try {
          // Discovery egiteko klasea martxan jartzen dugu
          // Honen bitartez Lookup-ak bilatuko ditugu
            discoverer = new Discoverer();
            disco =
            new LookupDiscovery(LookupDiscovery.ALL_GROUPS);
            disco.addDiscoveryListener(discoverer);
          } catch (IOException ioex) {
            System.err.println("Errorea Discovery Listener bat sortzerakoan!: "+ioex.getMessage());
          }
      }
      else {
            disco.removeDiscoveryListener(discoverer);
      }
    }


    

}
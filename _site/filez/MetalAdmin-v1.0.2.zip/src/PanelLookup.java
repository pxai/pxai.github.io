
//Title:        A jini administrator...
//Version:
//Copyright:    Copyright (c) 1998
//Author:       Pello Xabier Altadill Izura
//Company:      Pello X ltd.
//Description:  Karrera Amaierako Proiektua

package com.ebila.jini.JiniAdministrator;

// import gunea
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

// Klasearen deklarazioa
public
class PanelLookup
extends Panel {

  // Atributuak
  JiniObjektuak jiniObjektuak;
  BorderLayout borderLayout1 = new BorderLayout();
  Label statusLabel;
  PanelLog log;
  PanelDokumentazioa pdokumentazioa;
  ZerbitzuInformazioa2 zi;
  Panel panelControls = new Panel();
  Button buttonLookup = new Button();
  List listLookup = new List();
  List listZerbitzuak = new List();
  Button buttonGelditu = new Button();
  Frame leihoNagusia;
  Thread t,tzi;
  Panel panelGoikoa = new Panel();
  BorderLayout borderLayout2 = new BorderLayout();
  Label label1 = new Label();
  Label labelZerbitzuak = new Label();
  Label labelAtributuak = new Label();
  Administrator administrator;

  // Eraikitzailea
  public PanelLookup(Label labelStatus, PanelLog plog, PanelDokumentazioa pdokumentazioa, JiniObjektuak jo, Frame leihoa) {
    try  {
      jbInit();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    jiniObjektuak = jo;
    statusLabel = labelStatus;
    log = plog;
    this.pdokumentazioa = pdokumentazioa;
    leihoNagusia = leihoa;
  }

  // Interfazea prestatzeko metodoa
  void jbInit() throws Exception {
    buttonLookup.setLabel("LOOKUP!!");
    listLookup.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        listLookup_itemStateChanged(e);
      }
    });
    listLookup.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        listLookup_mouseClicked(e);
      }
    });
    buttonGelditu.setLabel("Stop");
    label1.setAlignment(1);
    label1.setText("This is Lookup panel...");
    labelZerbitzuak.setText("Found Services ID");
    labelAtributuak.setAlignment(2);
    labelAtributuak.setText("Attributes");
    panelGoikoa.setLayout(borderLayout2);
    buttonGelditu.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonGelditu_actionPerformed(e);
      }
    });
    buttonGelditu.enable(false);
    buttonLookup.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonLookup_actionPerformed(e);
      }
    });
    this.setLayout(borderLayout1);
    this.add(panelControls, BorderLayout.SOUTH);
    panelControls.add(buttonLookup, null);
    panelControls.add(buttonGelditu, null);
    this.add(listLookup, BorderLayout.WEST);
    this.add(listZerbitzuak, BorderLayout.CENTER);
    this.add(panelGoikoa, BorderLayout.NORTH);
    panelGoikoa.add(label1, BorderLayout.NORTH);
    panelGoikoa.add(labelZerbitzuak, BorderLayout.CENTER);
    panelGoikoa.add(labelAtributuak, BorderLayout.EAST);
  }

  // atributuak erakusteko erabil daitekeen metodoa
  private void erakutsiAtributuak (String[] atributuak) {
    listZerbitzuak.clear();
    for (int i=0; i< atributuak.length; i++)
      listZerbitzuak.addItem(atributuak[i]);
  }

  // LookUp egiteko botoia sakatzen denean
  // bilaketa klasea martxan jartzen da: ZerbitzuInformazioa
  void buttonLookup_actionPerformed(ActionEvent e) {
    buttonGelditu.enable(true);
    buttonLookup.enable(false);
    log.gehitu("LookUp services finder thread started...");
    t = new Animazioa(statusLabel);
    t.start();
        try {
    zi = new ZerbitzuInformazioa2(statusLabel, log, this, pdokumentazioa, jiniObjektuak);
    //zi = new ZerbitzuInformazioa2();
    tzi = new Thread(zi);
    tzi.start();
    } catch (IOException ioex) {System.err.println("Error: "+ioex.getMessage());}
  }

  // topatutako zerbitzuak listan gehitzeko
  void gehituZerbitzua (String zerbitzu) {
     listLookup.addItem(zerbitzu);
  }

   // topatutako zerbitzuak listan gehitzeko
  void gehituZerbitzua (String zerbitzu, int zbki) {
     listLookup.addItem(zerbitzu, zbki);
  listLookup.addItem(zerbitzu);
  }

  // topatutako atributuak listan gehitzeko
  void gehituAtributuak (String atributu) {
     listZerbitzuak.addItem(atributu);
  }

  // Botoi hau sakatzerakoan, bilaketa eta animazio hariak
  // gelditzen dira.
  void buttonGelditu_actionPerformed(ActionEvent e) {
    buttonLookup.enable(true);
      buttonGelditu.enable(false);
      t.stop();
     tzi.interrupt();
  }

  // zerbitzuLista-ren gainean klik egiterakoan exekutatuko
  // den metodoa.
  void listLookup_itemStateChanged(ItemEvent e) {
     if (jiniObjektuak.badago(""+listLookup.getSelectedItem()))
        erakutsiAtributuak(jiniObjektuak.itzuliZerbitzuInformazioa(""+listLookup.getSelectedItem()));
  }

  // atributu listan klik egitean exekutatuko den metodoa
  void listLookup_mouseClicked(MouseEvent e) {
	if (e.getClickCount() == 2) {
	  administrator = new Administrator(jiniObjektuak.ateraJiniObjektua(""+listLookup.getSelectedItem()));
        if (administrator.isAdministrable())
	  administrator.esleituBalioak(new DialogAdmin(leihoNagusia,""+listLookup.getSelectedItem(),false),this);
	}
  }

}
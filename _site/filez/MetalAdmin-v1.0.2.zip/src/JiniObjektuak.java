
//Title:        A jini administrator...
//Version:
//Copyright:    Copyright (c) 1998
//Author:       Pello Xabier Altadill Izura
//Company:      Pello X ltd.
//Description:  Karrera Amaierako Proiektua


package com.ebila.jini.JiniAdministrator;

// import gunea
import net.jini.core.lookup.ServiceItem;
import net.jini.lookup.entry.ServiceInfo;
import java.util.Hashtable;
import java.util.Vector;
import java.io.DataInputStream;
import java.io.DataInput;
import java.io.IOException;
import java.io.Serializable;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

// Lookup-ak topatu dituen zerbitzu guztien informazioa
// gordetzeko eta manipulatzeko objektua
// Serializagarria da, beraz, nahi izanez gero objektuaren
// egoera gorde hal izanen dugu.
public
class JiniObjektuak
implements Serializable {

  // Hauxe da datu mota nagusia: Hastable bat,
  // hau da, bi objektu balio (Zerbitzu ID-a, eta Entry bektorea)
  // gordetzen dituen hash taula berezia.
  private static Hashtable JiniIngurunea;
  private static String Fitxategia = "jiniobjetuak.obj";

  public JiniObjektuak() {
    hasieratu();
  }

  public void hasieratu() {
   JiniIngurunea = new Hashtable();
  }


  // JiniObjektu bat gordetzeko metodoa
  public void sartuJiniObjektua (String id, Object o) {
    JiniIngurunea.put(id, o);
  }

  // JiniObjektu bat lortzeko metodoa
  public Object ateraJiniObjektua (String id) {
    return JiniIngurunea.get(id);
  }


  // JiniObjektu bat eguneratzeko metodoa
  public void eguneratuJiniObjektua (String id, Object o) {
    if (JiniIngurunea.containsKey(id))
        JiniIngurunea.remove(id);
        sartuJiniObjektua(id, o);
  }

  // JiniObjektu bat ezabatzeko metodoa
  public void ezabatuJiniObjektua (String id) {
        JiniIngurunea.remove(id);
  }

  // JiniObjektu bat gordeta daukagun ala ez esaten digun metodoa
  public boolean badago (String id) {
    return JiniIngurunea.containsKey(id);
  }

    // JiniObjektu guztiak inprimatzen dituen metodoa
  public String  inprimatu () {
      return (JiniIngurunea.toString());
  }

    // Zerbitzuen Informazioa (ServiceInfo atributuko balioak)
    // inprimatzen dira
    public String[] itzuliZerbitzuInformazioa(String id) {
        String[] emaitza;
        Vector bektorea = new Vector(0);
        ServiceItem item = (ServiceItem) ateraJiniObjektua(id);
        for (int i=0 ; i<item.attributeSets.length ; i++) {
            if (item.attributeSets[i] instanceof ServiceInfo) {
                ServiceInfo info = (ServiceInfo) item.attributeSets[i];
                bektorea.addElement("-Name: " + info.name);
                bektorea.addElement("    +Manufacturer: " + info.manufacturer);
                bektorea.addElement("    +Vendor: " + info.vendor);
                bektorea.addElement("    +Version: " + info.version);
                bektorea.addElement("    +Model: " + info.model);
                bektorea.addElement("    +Serial No: " + info.serialNumber);
            }
        }
        emaitza = new String[bektorea.size()];
        bektorea.copyInto(emaitza);
        return emaitza;
    }



  // JiniObjektuak objetuaren egoera gordetzen duen metodoa.
  public void checkpoint()
    {
        JiniObjektuak data = this;
         try {
        ObjectOutputStream out = new
            ObjectOutputStream(new FileOutputStream(Fitxategia));

        out.writeObject(data);
        out.flush();
        out.close();
         } catch (IOException ioex)
         {
            System.err.println("<JiniObjektuak> Errorea egoera gordetzerakoan: "+ioex.getMessage());
         }
        System.out.println("<JiniObjektuak> Zerbitzuaren egoera gorde da.");
    }


  // JiniObjektuak objetuaren egoera berreskuratzen duen metodoa.
    public JiniObjektuak berreskuratu() throws IOException {
        JiniObjektuak data = null;
        try {
        ObjectInputStream in = new ObjectInputStream(new FileInputStream(Fitxategia));
        data = (JiniObjektuak) in.readObject();

        } catch (Exception ex)
         {
            System.err.println("<JiniObjektuak> Errorea fitxategia irakurtzerakoan: "+ex.getMessage());
            return null;
         }
        if (data == null) {
            System.err.println("<JiniObjektuak> Ez dago daturik berreskuratzeko...");
        } else {
            System.out.println("<JiniObjektuak> Zerbitzuko objektua berreskuratu da. ");
        }
        return data;
    }


  public static void main(String[] args) throws IOException{
    JiniObjektuak jiniObjektuak = new JiniObjektuak();
    DataInput di = new DataInputStream(System.in);
    String lerroa = "";
    jiniObjektuak.invokedStandalone = true;

    System.out.println("Kaixo, sartu objektu bat:");
    lerroa =  di.readLine();
     jiniObjektuak.sartuJiniObjektua(lerroa,lerroa+" -lehena");
    System.out.println("Kaixo, sartu objektu bat:");
    lerroa =  di.readLine();
     jiniObjektuak.sartuJiniObjektua(lerroa,lerroa+" -bigarrena");
    while (true) {
    System.out.println("Kaixo, sartu objektu bat:");
    lerroa =  di.readLine();
     jiniObjektuak.sartuJiniObjektua(lerroa,lerroa+" -hirugarrena");
    System.out.println("Konprobatu objektua:");
    lerroa =  di.readLine();
      if (jiniObjektuak.badago(lerroa))
          System.out.println("objektua badago!!");
      else
          System.out.println("objektua ez dago!!");

          System.out.println("Taula osoa:");
       System.out.println(jiniObjektuak.inprimatu());
      }
  }

  private boolean invokedStandalone = false;
}
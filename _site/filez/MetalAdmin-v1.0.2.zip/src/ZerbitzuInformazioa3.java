// Klase honek Jini zerbitzuak bilatzen ditu (Lookup eta bestelako jini zerbitzuak)
// eta ServiceInfo atributua baldinbadute, erakusten da.

// JiniAdministrator paketearen barruan gaude
package com.ebila.jini.JiniAdministrator;


// Import gunea
import net.jini.discovery.LookupDiscovery;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.DiscoveryListener;
import net.jini.core.lookup.ServiceMatches;
import net.jini.core.lookup.ServiceItem;
import net.jini.core.lookup.ServiceTemplate;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.discovery.LookupLocator;
import net.jini.lookup.entry.ServiceInfo;
import net.jini.core.entry.Entry;
import java.util.Hashtable;
import java.util.Vector;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;
import java.io.IOException;
import java.awt.Label;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.awt.List;

// klasearen deklarazioa
public 
class ZerbitzuInformazioa3 
implements Runnable {

    // atributuak
    protected Hashtable registrars = new Hashtable();
    protected Hashtable services = new Hashtable();
    protected ServiceTemplate tmpl;
    protected LookupDiscovery disco;
    protected Discoverer discoverer;
    JiniObjektuak jiniObjektuak;
    Label lstatus;
    PanelLog plogs;
    PanelLookup plookup;
    PanelDokumentazioa pdokumentazioa;
    Entry[] attrTemplates = null;
    String url = null;
    List listTopatutakoak = null;
    protected static final int ON = 1;
    protected static final int OFF = 0;
    protected int martxan = 0;


    
  // Inner klasea LookUp-ak bilatzeko
    class Discoverer implements DiscoveryListener {
        public void discovered(DiscoveryEvent ev) {
            ServiceRegistrar[] newregs = ev.getRegistrars();
            for (int i=0 ; i<newregs.length ; i++) {
                addRegistrar(newregs[i]);
            }
        }
        public void discarded(DiscoveryEvent ev) {
            ServiceRegistrar[] newregs = ev.getRegistrars();
            for (int i=0 ; i<newregs.length ; i++) {
                removeRegistrar(newregs[i]);
            }
        }
    }

     // ZerbitzuInformazioa3
    // Eraikitzailea
    public ZerbitzuInformazioa3(Label labelStatus, PanelLog plog, PanelLookup plookup, PanelDokumentazioa pdokumentazioa, JiniObjektuak jo, String url, List listTopatutakoak) throws IOException {
	if (System.getSecurityManager() == null) {
	    System.setSecurityManager(
		    new RMISecurityManager());
	}

        this.url = url;
				this.listTopatutakoak = listTopatutakoak;
        // Plantilla honekin bat datozen zerbitzu guztiak
        // topatuko dira: plantilla hutsa denez, topatzen ditugun Lookup-ak
        // zerbitzu guztiak itzuliko dizkugute.
        attrTemplates = new Entry[1];
        attrTemplates[0] = new ServiceInfo(null, null, null, 
                                           null, null, null);
        tmpl = new ServiceTemplate(null, null, attrTemplates);
        
        // Interfazeko atributuak esleitzen dira...
        // honen bitartez, klase honek eragiten dituen mezuak
        // Panel Nagusian isladatu ahal izanen dira.
        if (url == null) {
        LookupDiscovery disco = 
            new LookupDiscovery(LookupDiscovery.ALL_GROUPS);
        disco.addDiscoveryListener(new Discoverer());
        }
	      this.jiniObjektuak = jo;
        this.lstatus = labelStatus;
        this.plogs = plog;
        this.plookup = plookup;
        this.pdokumentazioa = pdokumentazioa;
    }
    

       // honen bitartez, zerbitzu bat zuzenean topatzen da
       public void findRegistrar(String url) {
        LookupLocator loc = null;	
        ServiceRegistrar sr = null;
        try {
        loc = new LookupLocator(url);
        } catch (MalformedURLException mue) {
        	System.err.println("<panel-browser> URL-a gaizki dago.");
        	return;	
        }
        System.out.println("<panel-browser> Bilatzen Host: " + loc.getHost()+" Portua: " + loc.getPort());
				plogs.gehitu("<panel-browser> Bilatzen Host: " + loc.getHost()+" Portua: " + loc.getPort());
        try {
        sr = loc.getRegistrar();
        listTopatutakoak.addItem("Lookup zerbitzua: "+loc.getHost()+" makinan, "+loc.getPort()+ " portuan");
        } catch (Exception e) {
        	System.err.println("<panel-browser> Errorea Lookup proxy ekartzerakoan.\n Ez da Lookup zerbitzurik topatu.");        	
        }
        findServices(sr);
    }

    
    protected synchronized void addRegistrar(ServiceRegistrar reg) {
        if (registrars.contains(reg.getServiceID()))
            return;
            
        registrars.put(reg.getServiceID(), reg);
        findServices(reg);
    }
    protected synchronized void removeRegistrar(ServiceRegistrar reg) {
        if (!registrars.contains(reg.getServiceID()))
            return;
        
        registrars.remove(reg.getServiceID());
    }

    // lookup zerbitzu batean erregistraturik dauden
    // zerbitzu guztiak ateratzen ditu.    
    void findServices(ServiceRegistrar reg) {
        try {
            ServiceMatches matches = reg.lookup(tmpl, Integer.MAX_VALUE);
        
            for (int i=0 ; i<matches.totalMatches ; i++) {
                if (services.contains(matches.items[i].serviceID))
                    continue;
								listTopatutakoak.addItem(matches.items[i].serviceID.toString());								            
        				new DialogBrowserJini(plookup.leihoNagusia,matches.items[i].serviceID.toString(),true,"Bat datorren zerbitzua. Gehitu?",this,matches.items[i]);
            }
								listTopatutakoak.addItem("<ez dago besterik>");								            
        } catch (RemoteException ex) {
            System.err.println("Ezin izan dut zerbitzurik topatu: " +
                               ex.getMessage());
        }
    }
    
    // zerbitzu berria topatu denean, topatua zegoen ala ez aztertzen
    // da eta prozesatzen da.
    public void addService(ServiceItem item) {
        services.put(item.serviceID, item);
        lstatus.setText("<panelbrowser>Zerbitzu Berria topatu da! " + item.serviceID);
        plogs.gehitu("<panelbrowser>Zerbitzu Berria topatu da! " + item.serviceID);
        System.out.println("<panelbrowser>Zerbitzu Berria topatu da! " + item.serviceID);
        if (!jiniObjektuak.badago(""+item.serviceID)) {
        jiniObjektuak.sartuJiniObjektua(""+item.serviceID,item);
        ateraZerbitzuInformazioa3(item);
        }
        else {
          lstatus.setText("<panelbrowser>Zerbitzua dagoeneko topatua... " + item.serviceID);
          plogs.gehitu("<panelbrowser>Zerbitzua dagoeneko topatua... " + item.serviceID);
          System.out.println("<panelbrowser>Zerbitzua dagoeneko topatua... " + item.serviceID);
        }
    }
    
    // Zerbitzuen Informazioa (ServiceInfo atributuko balioak)
    // inprimatzen dira
    protected void ateraZerbitzuInformazioa3(ServiceItem item) {
        for (int i=0 ; i<item.attributeSets.length ; i++) {
            if (item.attributeSets[i] instanceof ServiceInfo) {
                ServiceInfo info = (ServiceInfo) item.attributeSets[i];
                pdokumentazioa.gehituZerbitzua(""+item.serviceID);
                plookup.gehituZerbitzua(""+item.serviceID);
            }
        }
    }
    
    // Haria, klase hau funtzionatzen mantentzeko
    public void run() {
        while (true) {
            try {
                Thread.sleep(Long.MAX_VALUE);
            } catch (InterruptedException ex) {
            }
        }
    }

    public void start () {
       if (martxan == 0)
       {
            martxan = 1;
            entzulea(ON);
            lstatus.setText("<panel browser>Bilaketa haria martxan...");
            plogs.gehitu("<panel browser>Bilaketa haria martxan...");
       }
       else
              lstatus.setText("<panel browser>Bilaketa haria dagoeneko martxan...");
    }


    public void stop () {
       if (martxan  != 0)
       {
          martxan = 0;
          entzulea(OFF);
          lstatus.setText("<panel browser>Bilaketa haria geldituta...");
          plogs.gehitu("<panel browser>Bilaketa haria geldituta");
       }
       else
          lstatus.setText("<panel browser>Bilaketa haria dagoeneko geldituta...");
    }

    // entzulea on/off
    // lookup bilatzea eteten bada, entzulea suntsitzen da
    // bestela martxan jartzen da.
    protected void entzulea (int agindua) {
      if (agindua == 1) {
          try {
          // Discovery egiteko klasea martxan jartzen dugu
          // Honen bitartez Lookup-ak bilatuko ditugu
            discoverer = new Discoverer();
            disco =
            new LookupDiscovery(LookupDiscovery.ALL_GROUPS);
            disco.addDiscoveryListener(discoverer);
          } catch (IOException ioex) {
            System.err.println("<panel browser>Errorea Discovery Listener bat sortzerakoan!: "+ioex.getMessage());
          }
      }
      else {
            disco.removeDiscoveryListener(discoverer);
      }
    }


    

}
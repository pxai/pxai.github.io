
//Title:        A jini administrator...
//Version:
//Copyright:    Copyright (c) 1998
//Author:       Pello Xabier Altadill Izura
//Company:      Pello X ltd.
//Description:  Karrera Amaierako Proiektua

package com.ebila.jini.JiniAdministrator;

import java.awt.*;
import java.awt.event.*;

public class DialogJini extends Dialog {
  boolean erantzuna = false;
  String mezua ="";
  Panel panel1 = new Panel();
  BorderLayout borderLayout1 = new BorderLayout();
  Panel panelControls = new Panel();
  Button buttonOk = new Button("OK");
  Button buttonCancel = new Button("Cancel");
  Label labelMezua = new Label();
  JiniAdministrator frameJatorri;


  public DialogJini(Frame frame, String title, boolean modal,String mezu) {
    super(frame, title, false);
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try  {
      jbInit();
      add(panel1);
      pack();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    frameJatorri = (JiniAdministrator)frame;
    mezua = mezu;
    labelMezua.setText(mezua);
    this.setSize(250,100);
    this.setLocation(frame.getLocation());
    this.show();
  }


  public DialogJini(Frame frame) {
    this(frame, "", true,"");
  }


  public DialogJini(Frame frame, boolean modal) {
    this(frame, "", modal,"");
  }


  public DialogJini(Frame frame, String title) {
    this(frame, title, true,"");
  }

  void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    buttonOk.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonOk_actionPerformed(e);
      }
    });
    buttonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonCancel_actionPerformed(e);
      }
    });
    panelControls.setBackground(Color.lightGray);
    labelMezua.setBackground(Color.lightGray);
    labelMezua.setAlignment(1);
    labelMezua.setText("Are you sure?");
    panel1.add(panelControls, BorderLayout.SOUTH);
    panelControls.add(buttonOk, null);
    panelControls.add(buttonCancel, null);
    panel1.add(labelMezua, BorderLayout.CENTER);
  }

  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel();
    }
    super.processWindowEvent(e);
  }

  void cancel() {
    dispose();
  }

  void buttonOk_actionPerformed(ActionEvent e) {
    erantzuna = true;
    dispose();
    frameJatorri.atera();
  }

  void buttonCancel_actionPerformed(ActionEvent e) {
    erantzuna = false;
    dispose();
  }
}

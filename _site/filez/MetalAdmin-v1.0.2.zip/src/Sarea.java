package com.ebila.jini.JiniAdministrator;

//import gunea
import java.io.IOException;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.DataInputStream;
import java.util.Hashtable;
import java.net.*;
import java.awt.List;

// Klasearen deklarazioa
public
class Sarea
extends Thread {

        // Atributuak
        protected Socket socket = null;
        protected DatagramSocket datagramSocket = null;
        protected DatagramPacket datagramPacket = null;
        protected InetAddress helbidea = null;
        protected byte[] buffer = new byte[128];
        protected int portuak;
        protected String host;
        protected FileWriter fw;
        protected List listSatan;
        private static final String fitxategiSarrera ="files/services";
        protected Hashtable portuEsanahia= new Hashtable();

    // eraikitzailea
    public Sarea (String host, List listSatan) {
      this.host = host;
      this.listSatan = listSatan;
      hasieratu();
    }

    // run
    public void run () {
     System.out.println("Network-Thread> HOST: "+host);
     listSatan.addItem("Network-Thread> HOST: "+host+ " results will be saved in 'files/scanresults.txt' too.");

      sareaAztertu();        
    }

 

    // hasieratu
    private void hasieratu () {
     try {
         kargatuFitxategia();
				 listSatan.clear();
         fw = new FileWriter("scanresults.txt");
        } catch (IOException e) {
            System.err.println("Errorea fitxategia irekitzerakoan: "+e.getMessage());
        }
    }

    // kargatuFitxategia
    private void kargatuFitxategia() {

          String hitza = "";
          DataInputStream di;
       try {
          di = new DataInputStream(new FileInputStream(fitxategiSarrera));

        while (!((hitza = di.readLine()) == null) ) {
                portuEsanahia.put(hitza,di.readLine());
        }
                System.out.println("Network-Thread>Port meaning file loaded.");
        di.close();
        } catch (IOException e) {
            System.err.println("Errorea fitxategia irekitzerakoan: "+e.getMessage());
        }

    }

    // TCP konexioa probatu
    private boolean TCPkonexioaProbatu (int portua) {
     try {
      socket = new Socket(host, portua);
      socket.close();
      return true;
        } catch (IOException e) {
            return false;
        }
    }

    // UDP konexioa probatu
    private boolean UDPkonexioaProbatu (int portua) {
     try {
      String hitza = "PortScannerv1.0";
      helbidea = InetAddress.getByName(host);
      buffer = hitza.getBytes();
      datagramSocket = new DatagramSocket(portua);
      datagramPacket = new DatagramPacket(buffer,buffer.length, helbidea,portua);
      //datagramSocket.connect(helbidea,portua);   //jdk1.2
      //datagramSocket.disconnect(); //jdk1.2
      datagramSocket.send(datagramPacket);
      datagramSocket.close();
      return true;
        } catch (IOException e) {
            return false;
        }
    }

    private void sareaAztertu () {
        for (int i=0;i<1026;i++)  {
                if (TCPkonexioaProbatu(i)) {
                gordeLerroa(host+" machine has "+i+ " port opened");
                listSatan.addItem(host+" machine has "+i+ " TCP port opened: "+portuEsanahia.get(new Integer(i)));
                }
              /*  if (UDPkonexioaProbatu(i)) {
                gordeLerroa(host+" makinan "+i+ " portua irekia.");
                System.out.println("\n"+host+" makinan "+i+ " UDP portua irekia.");
                } */
         }

     try {
        fw.close();
        } catch (IOException e) {
            System.err.println("Errorea lerroa gordetzerakoan: "+e.getMessage());
        }
    }

    //emaitza fitxategian lerroa gordetzen duen metodoa
    private void gordeLerroa (String lerroa) {
     try {
        fw.write(lerroa+"\n");
        } catch (IOException e) {
            System.err.println("Errorea lerroa gordetzerakoan: "+e.getMessage());
        }
    }


}

//Title:        A jini administrator...
//Version:      
//Copyright:    Copyright (c) 1998
//Author:       Pello Xabier Altadill Izura
//Company:      Pello X ltd.
//Description:  Karrera Amaierako Proiektua


package com.ebila.jini.JiniAdministrator;
import java.awt.Label;

public class Animazioa extends Thread {
  Label labela;
  public Animazioa() {
  }
  public Animazioa(Label l) {
    labela =l;
  }

  public void run () {
   String s[] = {"Searching","Searching >","Searching >>",
                  "Searching >>>","Searching >>>>","Searching >>>>>",
                  "Searching >>>>>>","Searching >>>>>>>","Searching >>>>>>>>",
                  "Searching >>>>>>>>>","Searching >>>>>>>>>>","Searching >>>>>>>>>>>",
                  "Searching >>>>>>>>>>>>","Searching >>>>>>>>>>>>>","Searching >>>>>>>>>>>>>>",
                  "Searching >>>>>>>>>>>>>>>","Searching >>>>>>>>>>>>>>>>","Searching >>>>>>>>>>>>>>>>>"};
   while (true)
      for (int i=0;i <18;i++)    {
        labela.setText(s[i]);
        try {
        Thread.sleep(100); } catch (InterruptedException iex) {
          System.err.println("Errorea animazioan"+iex.getMessage());
          }
        }
  }

  public static void main(String[] args) {
    Animazioa animazioa = new Animazioa();
    animazioa.invokedStandalone = true;
  }
  private boolean invokedStandalone = false;
} 
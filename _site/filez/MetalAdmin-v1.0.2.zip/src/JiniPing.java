// JiniPing: host eta portua emanda,
// makina batean Jini Lookup zerbitzua
// dagoen ala ez esaten digu.

package com.ebila.jini.JiniAdministrator;

// look ma, no discovery.
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.discovery.LookupLocator;
import java.net.Socket;
import java.net.UnknownHostException;
import java.rmi.MarshalledObject;
import java.io.*;
import java.awt.List;
import java.awt.Label;
import java.util.Vector;


public class JiniPing {
    public static final int protoVersion = 1;
    private int port = 4160;
    private String host = "";
    private List listExekuzio = null;
    private Label labelExekuzio = null;
    private long hasiera = 0;
    
    // eraikitzailea
    public JiniPing() {
    }
    
    // parametrodun eraikitzailea
    public JiniPing(String host, int port, List listExekuzio, Label labelExekuzio) {
    	this.host = host;
    	this.port = port;
    	this.listExekuzio = listExekuzio;
    	this.labelExekuzio = labelExekuzio;
    	listExekuzio.clear();
    	listExekuzio.addItem("jiniping to "+host+" machine, to "+port+".");
    	labelExekuzio.setText("Executing Jjniping to "+host+" machine, to "+port+".");
    	hasieratu();
    }

		
    public ServiceRegistrar getRegistrar() 
    throws ClassNotFoundException {
        Socket sock = null;
				ServiceRegistrar reg = null;
				try {
         sock = new Socket(host, port);
         } catch (UnknownHostException uhe) {
		     	System.err.println("<JiniPing> Error with hostname: "+uhe.getMessage());
        	System.err.println("<JiniPing> Lookup not found at "+host+ ".");	
			   	listExekuzio.addItem("<JiniPing> Lookup not found at "+host+ ".");
    			labelExekuzio.setText("Error - exit status-a not 0.");
       		return null;
         } catch (IOException ioex) {
         	System.err.println("<JiniPing> Error opening socket: "+ioex.getMessage());
        	System.err.println("<JiniPing> Lookup not found at "+host+ ".");	
		    	listExekuzio.addItem("<JiniPing> Error opening socket: Lookup not found at "+host+ ".");
    			labelExekuzio.setText("Error - exit status-a not 0. ");
					return null;
         }
				ObjectInputStream in = null;
        MarshalledObject mobj = null;
        
        // bidali eskaera
        try {
        DataOutputStream out = new DataOutputStream(sock.getOutputStream());
        out.writeInt(protoVersion);
        out.flush();
        } catch (IOException ioex1) {
         	System.err.println("<JiniPing> Error responding "+ioex1.getMessage());
         	listExekuzio.addItem("<JiniPing> Error responding. ");
    			labelExekuzio.setText("Error - exit status not 0.");
					return null;
         }

        
        // Erantzuna jaso....
				try {
        in = new ObjectInputStream(sock.getInputStream());
        mobj = (MarshalledObject) in.readObject();
        } catch (IOException ioex2) {
         	System.err.println("<JiniPing> Error responding: "+ioex2.getMessage());
         	listExekuzio.addItem("<JiniPing> Error responding.");
    			labelExekuzio.setText("Error - exit status not 0.");
					return null;
        }
        
        listExekuzio.addItem("Serialized proxy received as response from "+host+" at "+port+" port.");
        System.out.println("<JiniPing> Serialized proxy received as response from "+host+" at "+port+" port.");
        return null;
    }
    
    private void hasieratu() {
        hasiera = System.currentTimeMillis();
      
        ServiceRegistrar reg;
        
        try {
            reg = getRegistrar();
            listExekuzio.addItem("    Elapsed Time: "+(System.currentTimeMillis()-hasiera)+" ms.");            
        
        } catch (Exception ex) {
            System.err.println("<JiniPing> Error receiving proxy object from lookup: " +ex.getMessage());
            listExekuzio.addItem("<JiniPing> no response.");
     			labelExekuzio.setText("Error - exit status not 0.");
                          
        }
    }
}
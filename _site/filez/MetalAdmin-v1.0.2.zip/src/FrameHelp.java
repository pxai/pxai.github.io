
//Title:        A jini administrator...
//Version:
//Copyright:    Copyright (c) 1998
//Author:       Pello Xabier Altadill Izura
//Company:      Pello X ltd.
//Description:  Karrera Amaierako Proiektua

package com.ebila.jini.JiniAdministrator;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.DataInputStream;


// Klasea
public
class FrameHelp
extends Frame {

  // Atributuak
  List listGaiak = new List();
  TextArea textAreaLaguntza = new TextArea();
  Panel panelControls = new Panel();
  Button buttonExit = new Button();
  private static String jiniAdmin = "Jini Administrator v1.0 \n\n" +
  																				"Jini inguruneak monitorizatzeko eta bere zerbitzuak\n"+
  																				"administratzeko programa da hau. Lan hau errezteko zenbait\n"+
  																				"panel ezberdin aurkezten ditu:\n"+
  																				"(1) Lookup zerbitzuak eta bertan dauden Jini zerbitzuak\n"+
  																				"		 topatzeko panela. Hauek topatzerakoan, bere atributuak\n"+
  																				"		 azter ditzakegu, eta administragarriak badira, administratu.\n"+
  																				"(2) Browser-a: ezaguna den Lookup bat (bere host-a) topatzeko \n"+
  																				"		 ta zerbitzu konkretuak topatzeko (atributuen arabera) panela.\n"+
  																				"(3) Dokumentazio panela: hau bakarrik erabilgarria izanen da \n" +
  																				"		 zerbitzuek 'dokumentazio' atributu-ren bat ekartzen badute;\n"+
  																				"		 atributu hori ez da estandarra Jini-n, gehigarria da nolabait\n"+
  																				"		 (atributu propioak definitzea zilegi da Jini-n). Hau pentsatua\n" +
  																				"		 dago Jini zerbitzuek bere APIa erakusteko, eta programazioa \n" +
  																				"		 errazteko: programazioa On-line moduan bidera dezake honek.\n" +
  																				"(4) Sarea: honek TCP/IP sare ingurunea aztertzeko aukera ematen du:\n"+
  																				"		 * ping\n"+
  																				"		 * trace route\n"+
  																				"		 * netstat\n"+
  																				"		 * jini ping\n"+
  																				"		 * urruneko makinen TCP wrapper bat,(portu erreserbatuen eskaneoa).\n"+
  																				"(5) Log: hemen, Jini Adminstrator-en exekuzioan zehar gertaturiko\n"+
  																				"		 ebento esanguratsuenak erregistratzen dira, eta fitxategi batean\n"+
  																				"		 gordetzen dira (azkeneko egoera ikusteko aukera ematen du).\n\n"+
  																				"Jini Administrator-ek Thread edo exekuzio hariak darabil nonnahi:\n"+
  																				"sarea aztertzen duenean ez da blokeaturik geratzen, eta gauza bat \n"+
  																				"baino gehiago egiteko erabil daiteke; momentu guztitan hari horiek\n"+
  																				"gelditu edo berrabiatu daitezke.";
  																				
	private final static String lookup = "Lookup\n"+
																			 "*Jini Lookup zerbitzua ezinbestekoa da; Lookup beste zerbitzu bat da\n"+
																			 " azken finean, baino funtzio garrantzitsuenarekin: Jini Zerbitzuak\n"+
																			 " erregistratzea, zerbitzu gordekin bat osatuz.\n"+
																			 "*Jini komunitate batean parte hartzeko egin beharreko lehenbizkoa\n"+
																			 " lookup zerbitzu bat topatzea da: zerbitzarien kasuan bere existentzia\n"+
																			 " ezagutzera emateko, eta bezeroen kasuan honek bilatzen duen zerbitzua\n"+
																			 " topatu ahal izateko. \n"+
																			 "*Gainera atributuen araberako bilaketak egin daitezke (bezeroentzat),\n"+
																			 " zerbitzu konkretuak bilatu ahal izateko.";
	private final static String discovery = "Discovery\n"+
																					"Lookup zerbitzu bat topatzeko prozesua Discovery protokoloaren\n"+
																					"bitartez bideratzen da. Modu ezberdinetan egin daiteke zerbitzuen\n"+
																					"topaketa:\n"+
																					"*Multicast modua: UDP paketeen bitartez, ingurune guztian Lookup\n"+
																					" zerbitzuak bilatzen dira.\n"+
																					"*Unicast modua: Lookup zerbitzuaren kokapena ezaguna denean\n"+
																					" zuzenean goaz bertara TCP erabiliz.";																					
	private final static String join = "Join\n"+
																		 "Lookup zerbitzu batean erregistratzeko prozesuari Join deritzo.\n"+
																		 "Behin lookup-a topatu dela bertan 'alta' eman behar da. Horretarako,\n"+
																		 "zerbitzuak atributuak pasa, berarekin elkaeragiteko objektu bat eta\n"+
																		 "Lease denbora bat (erregistrapen denboraren iraupen proposamena) pasako\n"+
																		 "dira.";
	private final static String log = "Log Panela\n"+
																		"Imagina daitekeen moduan, panel honetan exekuzioan zehar suertaturiko\n"+
																		"gertaerarik esanguratsuenak erregistratzen dira: Lookup eta bestelako\n"+
																		"zerbitzuen topaketa, atributuen aldaketak, e.a...\n"+
																		"Bi ekintza burutu daitezke panel honetan:\n"+
																		"(1) Aurreko exekuzioko log-a ikusi.\n"+
																		"(2) Log-ren edukina ezabatu.\n";
  private final static String author = "Jini Administrator v1.0.2\n"+
  																		 "1999-2000\n"+
  																		 "Pello Xabier Altadill Izura\n"+
  																		 "http://jini.ebila.com\n";

  // Frame Help
  // Eraikitzailea
  public
  FrameHelp(Frame gurasoa) {
    this.setLocation(gurasoa.getLocation());
    try  {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    hasieratu();
  }


  // hasieratu
  // Interfazea hasieratzeaz arduratzen den funtzioa,
  // jbinit-ekin batera
  private void hasieratu () {
    listGaiak.addItem("Jini Administrator");
    listGaiak.addItem("Lookup ?");
    listGaiak.addItem("Discovery ?");
    listGaiak.addItem("Join ?");
    listGaiak.addItem("Log text ");
    listGaiak.addItem("Author");
    textAreaLaguntza.setEditable(false);
    this.setSize(600,200);
    this.show();
  }

  private void jbInit() throws Exception {
    this.setBackground(Color.lightGray);
    this.setTitle("Help");
    listGaiak.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        listGaiak_itemStateChanged(e);
      }
    });
    textAreaLaguntza.setBackground(Color.white);
    buttonExit.setLabel("Close");
    buttonExit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonExit_actionPerformed(e);
      }
    });
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
    this.add(listGaiak, BorderLayout.WEST);
    this.add(textAreaLaguntza, BorderLayout.CENTER);
    this.add(panelControls, BorderLayout.SOUTH);
    panelControls.add(buttonExit, null);
  }

  // kargatuLaguntza
  // Laguntzaren edukina testu arean kargatzen du
  // laguntza testua fitxategi batetik kargatzen saiatzen da.
  private void kargatuLaguntza (int indizea)  throws IOException {
    DataInputStream lag = new DataInputStream(new FileInputStream(indizea+".hlp"));
    String temp = null;
      textAreaLaguntza.setText("");
    while (!((temp = lag.readLine()) == null))
      textAreaLaguntza.append("\n"+temp);
    lag.close();
  }

  // kargatuLaguntza
  // Laguntzaren edukina testu arean kargatzen du
  // kasu honetan. laguntza testua aldagi batzuetatik kargatzen du.
  private void kargatuLaguntzaString (int indizea) {    
    	textAreaLaguntza.setText("");  		
			switch (indizea) {
    		case 0 :	textAreaLaguntza.setText(jiniAdmin);break;
    		case 1 :	textAreaLaguntza.setText(lookup);break;
    		case 2 :	textAreaLaguntza.setText(discovery);break;
    		case 3 :	textAreaLaguntza.setText(join);break;
    		case 4 :	textAreaLaguntza.setText(log);break;
    		case 5 :	textAreaLaguntza.setText(author);break;
    	default : break;
    }
  }
  
  void this_windowClosing(WindowEvent e) {
    dispose();
  }

  void buttonExit_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void listGaiak_itemStateChanged(ItemEvent e) {
      try {
     kargatuLaguntzaString(listGaiak.getSelectedIndex());
     } catch (Exception ex) {
      System.err.println("FrameHelp> Errorea: "+ex.getMessage());
      new DialogError(this,"Error!!�","Error, file not found: "+ex.getMessage(),true);
    }
}

}

       

//Title:        A jini administrator...
//Version:
//Copyright:    Copyright (c) 1998
//Author:       Pello Xabier Altadill Izura
//Company:      Pello X ltd.
//Description:  Karrera Amaierako Proiektua

// paketearen izena
package com.ebila.jini.JiniAdministrator;

// import-ak
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;

// JiniAdministrator klasea
public
class JiniAdministrator
extends Frame
implements Runnable{

  // Atributuak
  JiniObjektuak jo = new JiniObjektuak();
  BorderLayout borderLayout1 = new BorderLayout();
  Panel panelControls = new Panel();
  FlowLayout flowLayout1 = new FlowLayout();
  Button buttonDiscovery = new Button();
  Button buttonDoc = new Button();
  Button buttonExit = new Button();
  Button buttonLog = new Button();
  Label labelStatus = new Label();
  PanelLog plog = new PanelLog(labelStatus);
  PanelDokumentazioa pdokumentazioa = new PanelDokumentazioa(jo);
  PanelLookup plookup = new PanelLookup(labelStatus, plog, pdokumentazioa, jo,this);
  PanelBrowser pbrowser = new PanelBrowser(jo, plog, pdokumentazioa, plookup);
  PanelSarea psarea = new PanelSarea();
  Panel currentPanel= new Panel();

  Button buttonLaguntza = new Button();
  Button buttonBrowser = new Button();
  Button buttonSarea = new Button();
  
  // Run
  public
  void run () {
    try  {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
        hasieratu();
  }

  // Jini Administrator
  // Funtzio Eraikitzailea
  public
  JiniAdministrator() {
  }

  // Hasieratu
  // Interfazea hasieratzeaz arduratzen den funtzioa,
  // jbinit-ekin batera
  private
  void hasieratu () {
   plog.gehitu("Jini(tm) Administrator v1.0.2 started...");
   this.setSize(600,400);
   this.setLocation(200,200);
   this.show();
  }

  // Leiho nagusian Panel-ak elkaraldatzen dituen metodoa da hauxe.
  public void swapPanels (Panel berria, Panel zaharra) {
      System.gc();
      borderLayout1.removeLayoutComponent(zaharra);
      zaharra.setVisible(false);
      berria.setVisible(true);
      this.add(berria,borderLayout1.CENTER);
      this.setSize(this.getSize());
      this.setLocation(this.getLocation());
      this.show();
      currentPanel = berria;
  }

  // Metodo Nagusia
  // Objektuaren instantzi bt sortu eta bere haria
  // martxan jartzen da.
  public static void main(String[] args) {
    JiniAdministrator jiniAdministrator1 = new JiniAdministrator();
    new Thread(jiniAdministrator1).start();
  }

  private void jbInit() throws Exception {
    String hostIzena = "";
    
    this.setLayout(borderLayout1);
    this.setBackground(Color.lightGray);
    this.setTitle("METAL ADMIN Jini Administrator v1.0.2 - "+ hostIzena);
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
    buttonDiscovery.setLabel("Look Up");
    buttonDiscovery.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonDiscovery_actionPerformed(e);
      }
    });
    buttonDoc.setLabel("Documentation");
    buttonDoc.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonDoc_actionPerformed(e);
      }
    });
    buttonExit.setLabel("Exit");
    buttonLog.setLabel("Log");
    labelStatus.setForeground(Color.white);
    labelStatus.setBackground(Color.black);
    labelStatus.setText("Jini(tm) Administrator v1.0.2 started...");
    buttonLaguntza.setLabel("?");
    buttonSarea.setLabel("Network");
    buttonSarea.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonSarea_actionPerformed(e);
      }
    });
    buttonLaguntza.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonLaguntza_actionPerformed(e);
      }
    });
    buttonLog.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonLog_actionPerformed(e);
      }
    });
    buttonExit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonExit_actionPerformed(e);
      }
    });
    panelControls.setLayout(flowLayout1);
    this.add(panelControls, BorderLayout.NORTH);
    panelControls.add(buttonDiscovery, null);
    panelControls.add(buttonBrowser, null);
    panelControls.add(buttonDoc, null);
    panelControls.add(buttonSarea, null);
    panelControls.add(buttonLog, null);
    panelControls.add(buttonExit, null);
    panelControls.add(buttonLaguntza, null);
    this.add(labelStatus, BorderLayout.SOUTH);
    buttonBrowser.setLabel("Browser");
    buttonBrowser.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonBrowser_actionPerformed(e);
      }
    });

  }

  void buttonExit_actionPerformed(ActionEvent e) {
    new DialogJini(this,"Exit",true,"Are you sure?").show();
  }

  void this_windowClosing(WindowEvent e) {
    new DialogJini(this,"Exit",true,"Are you sure?").show();
  }
  void atera () {
    this.dispose();
    System.out.println("Thank you for using MetalAdmin for Jini(tm) !");
    plog.gehitu("Leaving Jini(tm) Administrator v1.0.2");
    plog.gehitu("Dumping found service data:\n"+jo.inprimatu());
    try {
    plog.gordeLog(); } catch (IOException ioex) {
      System.err.println("Errorea log gordetzerakoan:"+ioex.getMessage());
    }
    System.exit(0);
  }

  void buttonDiscovery_actionPerformed(ActionEvent e) {
    labelStatus.setText("Lookup panel - Lookup and other services finder");
    swapPanels(plookup,currentPanel);
  }

  // log botoia sakatzen denean exekutatzen den metodoa
  void buttonLog_actionPerformed(ActionEvent e) {
    labelStatus.setText("Log panel - Every event is registered here");
    swapPanels(plog,currentPanel);
  }

  // laguntza botoia sakatzen denenan exekutatzen den metodoa
  void buttonLaguntza_actionPerformed(ActionEvent e) {
    new FrameHelp(this);
  }

  // Dokumentazio botoia sakatzen denean exekutatuko den
  // metodoa. Kasu honentan dokumentazio panelera
  // eramango gaitu.
  void buttonDoc_actionPerformed(ActionEvent e) {
    labelStatus.setText("Documentation panel - for Services that implement Documentation attributes");
    swapPanels(pdokumentazioa,currentPanel);
  }

  // browser botoia sakatzen denean exekutatuko den metodoa
  // BrowserPanel-a agertuko da.
  void buttonBrowser_actionPerformed(ActionEvent e) {
    labelStatus.setText("Browser panel - Service finder in Unicast mode");
    swapPanels(pbrowser,currentPanel);

  }

  // sarea botoia sakatzen denean exekutatuko den metodoa
  // SareaPanel-a agertuko da.
  void buttonSarea_actionPerformed(ActionEvent e) {
    labelStatus.setText("Network panel - IP network enviroment analizer");
    swapPanels(psarea,currentPanel);
  }
}
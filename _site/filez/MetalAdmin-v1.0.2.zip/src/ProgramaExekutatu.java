package com.ebila.jini.JiniAdministrator;

//import gunea
import java.awt.List;
import java.awt.Label;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;

// Klasearen deklarazioa
public
class ProgramaExekutatu
extends Thread {

    // atributuak
    private String agindua;
    private List lista;
    private Label labela;

  // eraikitzailea
  public ProgramaExekutatu() {
  }

  // eraikitzailea argumentuekin
  public ProgramaExekutatu(String agindua, List lista, Label labela) {
    this.agindua = agindua;
    this.lista = lista;
    this.labela = labela;
  }

  public void run () {
    exekuzioaHasi();
  }

  // programa exekutatzen duen metodoa
  public void exekuzioaHasi () {
      InputStream is;
      BufferedReader br = null;
      String lerroak;
      Process proc = null;
      labela.setText("Exekutatzen "+agindua);
    try {
      proc = Runtime.getRuntime().exec(agindua);
      is = proc.getInputStream();
      br = new BufferedReader(new InputStreamReader(is));
      lista.clear();
       while ((lerroak = br.readLine()) != null)
            if (!lerroak.equals(""))
            lista.addItem(lerroak);
            

    } catch (IOException ioex) {
        System.err.println("<Programa-exekutatu>Errorea " +agindua+ " exekutatzerakoan."+ioex.getMessage());
        labela.setText("<Programa-exekutatu>Errorea " +agindua+ " exekutatzerakoan."+ioex.getMessage());
    }

    try {
      proc.waitFor();
    } catch (InterruptedException iex) {
        System.err.println("<Programa-exekutatu>Errorea " +agindua+ " ixterakoan."+iex.getMessage());
        labela.setText("<Programa-exekutatu>Errorea " +agindua+ " ixterakoan."+iex.getMessage());
    }
    if (proc.exitValue() != 0)
            labela.setText("exit-status 0-ren ezberdina izan da!");
    else labela.setText("exit-status: 0 izan da.");
    try {
    br.close();
    } catch (IOException ioex2) {
        System.err.println("<Programa-exekutatu>Errorea " +agindua+ " aginduaren irteera ixterakoan."+ioex2.getMessage());
        labela.setText("<Programa-exekutatu>Errorea " +agindua+ " aginduaren irteera ixterakoan."+ioex2.getMessage());
    }
  }


}
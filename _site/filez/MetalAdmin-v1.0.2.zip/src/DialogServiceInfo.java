
// ServiceInfo motako atributuak
// manipulatzeko metodoa.

package com.ebila.jini.JiniAdministrator;

// import gunea
import java.awt.*;
import java.awt.event.*;
import net.jini.lookup.entry.ServiceInfo;
import java.rmi.RemoteException;

// klasearen deklarazioa
public class DialogServiceInfo extends Dialog {

 // atributuak
  Panel panel1 = new Panel();
  BorderLayout borderLayout1 = new BorderLayout();
  Panel panelControl = new Panel();
  FlowLayout flowLayout1 = new FlowLayout();
  Button buttonSave = new Button();
  Button buttonKantzel = new Button();
  Panel panelZentru = new Panel();
  GridLayout gridLayout1 = new GridLayout();
  Label labelAtributuak = new Label();
  Label label1 = new Label();
  Label label2 = new Label();
  Label label3 = new Label();
  Label label4 = new Label();
  Label label5 = new Label();
  Label label6 = new Label();
  TextField textField1 = new TextField();
  TextField textField2 = new TextField();
  TextField textField3 = new TextField();
  TextField textField4 = new TextField();
  TextField textField5 = new TextField();
  TextField textField6 = new TextField();
  PanelBrowser pb = null;
  DialogAdmin da = null;

  // eraikitzailea
  public DialogServiceInfo(Frame frame, String title, boolean modal, PanelBrowser pb) {
    super(frame, title, modal);
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    this.pb = pb;
    try  {
      jbInit();
      add(panel1);
      pack();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  // eraikitzailea
  public DialogServiceInfo(Frame frame, String title, boolean modal, DialogAdmin da) {
    super(frame, title, modal);
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    this.da = da;
    try  {
      jbInit();
      add(panel1);
      pack();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }
  


 // hasieratzailea
  void jbInit() throws Exception {
    buttonKantzel.setLabel("Cancel");
    gridLayout1.setRows(6);
    gridLayout1.setHgap(5);
    gridLayout1.setColumns(2);
    gridLayout1.setVgap(5);
    labelAtributuak.setText("Change attr.");
    label1.setText("label1");
    label2.setText("label2");
    label3.setText("label3");
    label4.setText("label4");
    label5.setText("label5");
    label6.setText("label6");
    panelZentru.setLayout(gridLayout1);
    buttonKantzel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonKantzel_actionPerformed(e);
      }
    });
    panel1.setLayout(borderLayout1);
    panelControl.setLayout(flowLayout1);
    buttonSave.setLabel("Save");
    buttonSave.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonSave_actionPerformed(e);
      }
    });
    panel1.add(panelControl, BorderLayout.SOUTH);
    panelControl.add(buttonSave, null);
    panelControl.add(buttonKantzel, null);
    panel1.add(panelZentru, BorderLayout.CENTER);
    panelZentru.add(label1, null);
    panelZentru.add(textField1, null);
    panelZentru.add(label2, null);
    panelZentru.add(textField2, null);
    panelZentru.add(label3, null);
    panelZentru.add(textField3, null);
    panelZentru.add(label4, null);
    panelZentru.add(textField4, null);
    panelZentru.add(label5, null);
    panelZentru.add(textField5, null);
    panelZentru.add(label6, null);
    panelZentru.add(textField6, null);
    panel1.add(labelAtributuak, BorderLayout.NORTH);
  }

  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel();
    }
    super.processWindowEvent(e);
  }

  void cancel() {
    dispose();
  }

  // buttonSave sakatzen denean exekutatuko den metodoa
  void buttonSave_actionPerformed(ActionEvent e) {
		String attr1,attr2,attr3,attr4,attr5,attr6;

		if ((attr1 = textField1.getText()).equals(""))
			attr1 = null;
		if ((attr2 = textField2.getText()).equals(""))
			attr2 = null;
		if ((attr3 = textField3.getText()).equals(""))
			attr3 = null;
		if ((attr4 = textField4.getText()).equals(""))
			attr4 = null;
		if ((attr5 = textField5.getText()).equals(""))
			attr5 = null;
		if ((attr6 = textField6.getText()).equals(""))
			attr6 = null;
if (pb != null) {
  			pb.listAtributuak.clear();
				pb.listAtributuak.addItem("Name: "+attr1);
				pb.listAtributuak.addItem("Manufact.: "+attr2);
				pb.listAtributuak.addItem("Vendor: "+attr3);
				pb.listAtributuak.addItem("Version: "+attr4);
				pb.listAtributuak.addItem("Model: "+attr5);
				pb.listAtributuak.addItem("Ser. Number: "+attr6);

				pb.serviceInfo = new ServiceInfo(attr1,attr2,attr3,attr4,attr5,attr6);
			}
else 	{	
				da.aldatuServiceInfo(new ServiceInfo(attr1,attr2,attr3,attr4,attr5,attr6));
				}

				cancel();

  }

  // buttonKantzel sakatzen denean exekutatuko den metodoa
  void buttonKantzel_actionPerformed(ActionEvent e) {
		cancel();
  }
}

           
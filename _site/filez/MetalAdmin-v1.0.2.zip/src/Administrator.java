// Administrator.java
// zerbitzu baten administrazioa burutzeko

package com.ebila.jini.JiniAdministrator;

// import gunea
import net.jini.discovery.DiscoveryListener;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.LookupDiscovery;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceTemplate;
import net.jini.core.lookup.ServiceItem;
import net.jini.core.lookup.ServiceMatches;
import net.jini.core.discovery.LookupLocator;
import net.jini.core.entry.Entry;
import net.jini.admin.Administrable;
import net.jini.admin.JoinAdmin;
import net.jini.lookup.entry.ServiceInfo;
import com.sun.jini.admin.DestroyAdmin;
import com.sun.jini.admin.StorageLocationAdmin;
import java.util.Vector;
import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;
import java.net.MalformedURLException;


// Klasearen deklarazioa
public 
class Administrator 
implements Runnable {

	// atributuak
    private ServiceTemplate template;
    private LookupDiscovery disco;
    private DestroyAdmin zerbitzuSuntsitzailea = null;
    private JoinAdmin joinAdministratzailea = null;
    private StorageLocationAdmin storageLocationAdmin = null;
    private ServiceItem zerbitzuItem;
    private Object objetua;
    private        String[] s1;
    private        String[] taldea;
    private        Entry[] e1;
    private        LookupLocator[] l1;
    private DialogAdmin dialogAdmin;
    private PanelLookup plookup;


    // eraikitzailea
    public Administrator(Object zerbitzuItem)  {
	this.zerbitzuItem = (ServiceItem)zerbitzuItem;
    }

    public void esleituBalioak(DialogAdmin dialogAdmin, PanelLookup plookup)  {
      this.dialogAdmin = dialogAdmin;
      this.plookup = plookup;
			dialogAdmin.plookup = plookup;
			dialogAdmin.joinAdministratzailea = joinAdministratzailea;
			dialogAdmin.zerbitzuSuntsitzailea = zerbitzuSuntsitzailea;
						if (zerbitzuSuntsitzailea != null) 
						plookup.log.gehitu(zerbitzuItem.serviceID+" zerbitzuaren DestroyAdmin objektua lortu da");
					  else
            plookup.log.gehitu(zerbitzuItem.serviceID+ " Zerbitzuaren suntsiketa ez da administragarria.");

						if (joinAdministratzailea != null) 
						plookup.log.gehitu(zerbitzuItem.serviceID+" zerbitzuaren JoinAdmin objektua lortu da");
						else
            plookup.log.gehitu(zerbitzuItem.serviceID+ " Zerbitzuaren Join-a ez da administragarria.");

						if (storageLocationAdmin != null) 
						plookup.log.gehitu(zerbitzuItem.serviceID+" zerbitzuaren StorageLocationAdmin objektua lortu da");
						else
            plookup.log.gehitu(zerbitzuItem.serviceID+ " Zerbitzuaren Egoera gordetzeko Gunea-a ez da administragarria.");

						ateraDatuak();
    }

    // zerbitzuItem-a administragarria denentz esaten digun metodoa
    // administragarria bada, administrazio objektuak ekarriko dira.
    public boolean isAdministrable () {
	      try {
            //administratzailea =  (XAdmin)((Administrable)zerbitzuItem.service).getAdmin();
            joinAdministratzailea =  (JoinAdmin)((Administrable)zerbitzuItem.service).getAdmin();
            } catch (RemoteException rex1) {
            System.err.println("<administrator>Errorea administrazio objektua ekartzerakoan " + rex1.getMessage());
            System.err.println("<administrator>"+zerbitzuItem.serviceID+ " Zerbitzuaren Join-a ez da administragarria.");
						}
        try {
            zerbitzuSuntsitzailea =  (DestroyAdmin)((Administrable)zerbitzuItem.service).getAdmin();
            } catch (RemoteException rex2) {
            System.err.println("<administrator>Errorea administrazio objektua ekartzerakoan " + rex2.getMessage());
            System.err.println("<administrator>"+zerbitzuItem.serviceID+ " Zerbitzuaren suntsiketa ez da administragarria.");
						}
        try {
            storageLocationAdmin =  (StorageLocationAdmin)((Administrable)zerbitzuItem.service).getAdmin();
            } catch (RemoteException rex2) {
            System.err.println("<administrator>Errorea administrazio objektua ekartzerakoan " + rex2.getMessage());
            System.err.println("<administrator>"+zerbitzuItem.serviceID+ " Zerbitzuaren suntsiketa ez da administragarria.");
						}
						if (joinAdministratzailea == null && zerbitzuSuntsitzailea == null && storageLocationAdmin == null)
						return false;
	return true;
    }

 
   // zerbitzuak dituen administrazio datu guztiak dialogAdmin eta
   // irteera estandarretik erakusten ditugu.
   public void ateraDatuak () {
            try {
            	if (joinAdministratzailea != null) {
            s1 = joinAdministratzailea.getLookupGroups();
            e1 = joinAdministratzailea.getLookupAttributes();
            l1 = joinAdministratzailea.getLookupLocators();   
            }
         inprimatu();
            } catch (RemoteException rex) {
            System.err.println("<administrator> Errorea urrutiko objektuari deia egiterakoan: " + rex.getMessage());
          }

   }

/*	// administrazio objektuekin probak egiten dira...
    public void probakEgin() throws MalformedURLException {
           LookupLocator[] l2 = new LookupLocator[1];
           String[] s2 = new String[1];
	 	  Entry[] entriBat = new Entry[1];
              Entry[] entriBi = new Entry[1];
		  entriBat[0] = new ServiceInfo("X Zerbitzu Generikoa",
						    "PelloX GeNeRiC Systems ltd.",
						    "PelloX Mikorsystemak ltd.",
						    "v3.0",
						    "X model, xxx",
						    "000-000-x");
		  entriBi[0] = new ServiceInfo("X Zerbitzu Generikoa??",
						    "EZ, aldatu baitut!!",
						    "Entry honen atributuak",
						    "Aldatu ditut",
						    "KAGON SOS",
						    "Lortu diat");
            try {
            s1 = joinAdministratzailea.getLookupGroups();
            e1 = joinAdministratzailea.getLookupAttributes();
            l1 = joinAdministratzailea.getLookupLocators();
            inprimatu();

              l2[0] = new LookupLocator("jini://satan00/");

               //s2[0] = "";
            //joinAdministratzailea.addLookupGroups(taldea);
            //joinAdministratzailea.setLookupLocators(l2);
            //joinAdministratzailea.removeLookupLocators(l2);
            //joinAdministratzailea.setLookupGroups(s2);
            // joinAdministratzailea.removeLookupGroups(s2);
            //joinAdministratzailea.addLookupAttributes(entriBi);
            joinAdministratzailea.modifyLookupAttributes(entriBi,entriBat);

                

            s1 = joinAdministratzailea.getLookupGroups();
            e1 = joinAdministratzailea.getLookupAttributes();
            l1 = joinAdministratzailea.getLookupLocators();
            inprimatu();
            } catch (RemoteException ex2) {
            System.err.println("<bezeroa> Errorea urrutiko objektuari deia egiterakoan: " + ex2.getMessage());
          }
    }

 */
    public void inprimatu () {
     int i;
     for (i = 0;i < e1.length;i++)
            dialogAdmin.listEntry.addItem(e1[i].toString());
     for (i = 0;i < l1.length;i++)
            dialogAdmin.listLocator.addItem(l1[i].toString());
     for (i = 0;i < s1.length;i++)
     				if (s1[i].equals(""))
            dialogAdmin.listTaldeak.addItem("public");
     				else 	
            dialogAdmin.listTaldeak.addItem(s1[i]);
			try {
     dialogAdmin.textFieldStorage.setText(storageLocationAdmin.getStorageLocation());
       } catch (RemoteException ex2) {
            System.err.println("<bezeroa> Errorea urrutiko objektuari deia egiterakoan: " + ex2.getMessage());
          }

    }

    // Hari honek ez du ezer ere ez egiten
    // discovery egiten den bitartean JVMtik ez ateratzeko.
    public void run() {
        while (true) {
            try {
                Thread.sleep(1000000);
            } catch (InterruptedException ex) {
            }
        }
    }
    

}

//Title:        A jini administrator...
//Version:      
//Copyright:    Copyright (c) 1998
//Author:       Pello Xabier Altadill Izura
//Company:      Pello X ltd.
//Description:  Karrera Amaierako Proiektua

package com.ebila.jini.JiniAdministrator;

// import gunea
import java.awt.*;
import java.awt.event.*;
import net.jini.core.lookup.ServiceItem;


// Klasearen deklarazioa
public
class PanelDokumentazioa
extends Panel {

  // atributuak
  BorderLayout borderLayout1 = new BorderLayout();
  List zerbitzuLista = new List();
  Panel panelLista = new Panel();
  BorderLayout borderLayout2 = new BorderLayout();
  Label labelList = new Label();
  Panel panelTextArea = new Panel();
  TextArea textAreaDokumentazioa = new TextArea();
  BorderLayout borderLayout3 = new BorderLayout();
  Label labelTextArea = new Label();
  JiniObjektuak jo;
  Jinidoc jinidoc = null;

  // eraikitzailea
  public PanelDokumentazioa(JiniObjektuak jo) {
    this.jo = jo;
    try  {
      jbInit();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  // ingurune grafikoa hasieratzen duen metodoa
  void jbInit() throws Exception {
    textAreaDokumentazioa.setEditable(false);
    labelTextArea.setAlignment(2);
    labelTextArea.setText("Service Documentation");
    this.setLayout(borderLayout1);
    labelList.setText("Services");
    panelTextArea.setLayout(borderLayout3);
    textAreaDokumentazioa.setFont(new Font("TimesRoman", 0, 10));
    textAreaDokumentazioa.setText("<Service Documentation>");
    textAreaDokumentazioa.setBackground(Color.lightGray);
    panelLista.setLayout(borderLayout2);
    this.add(panelLista, BorderLayout.WEST);
    panelLista.add(zerbitzuLista, BorderLayout.CENTER);
    panelLista.add(labelList, BorderLayout.NORTH);
    this.add(panelTextArea, BorderLayout.CENTER);
    panelTextArea.add(textAreaDokumentazioa, BorderLayout.CENTER);
    panelTextArea.add(labelTextArea, BorderLayout.NORTH);
    zerbitzuLista.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        zerbitzuLista_itemStateChanged(e);
      }
    });


  }

  // topatutako zerbitzuak listan gehitzeko
  public void gehituZerbitzua (String elementua) {
   zerbitzuLista.addItem(elementua);
  }

  // topatutako zerbitzuak listan gehitzeko
  void gehituZerbitzua (String zerbitzu, int zbki) {
     zerbitzuLista.addItem(zerbitzu, zbki);
  }

  // dokumentazio panelean idazteko
  void gehituTestua (String testua) {
     textAreaDokumentazioa.appendText(testua);
  }

// topatutako zerbitzuak listan gehitzeko
  void ateraInformazioa (boolean badauka) {
  	 textAreaDokumentazioa.setText("");
  	 if (badauka) {
  	 	gehituTestua("Zerbitzuaren dokumentazioa:\n\n");
  	 	gehituTestua("Atributuak:\n");
  	 	for (int i=0 ; i<jinidoc.atributuak.size(); i++) {
  	 							gehituTestua(i+".- ");
									gehituTestua((String)jinidoc.atributuak.elementAt(i));
  	 							gehituTestua("\n");
       }
  	 	gehituTestua("Metodoak:\n");
  	 	for (int j=0 ; j<jinidoc.metodoak.size(); j++) {
  	 							gehituTestua(j+".- ");
  	 							gehituTestua((String)jinidoc.metodoak.elementAt(j));
  	 							gehituTestua("\n");
       }
		} else 
  	 	gehituTestua("This service has no JiniDoc attributes.\n");				

  }

  // zerbitzuLista-ren gainean klik egiterakoan exekutatuko
  // den metodoa.
  void zerbitzuLista_itemStateChanged(ItemEvent e) {
  	boolean badauka = false;
  	ServiceItem item = (ServiceItem)jo.ateraJiniObjektua(""+zerbitzuLista.getSelectedItem());
  	   for (int i=0 ; i<item.attributeSets.length ; i++) {
            if (item.attributeSets[i] instanceof Jinidoc) {
                jinidoc = (Jinidoc) item.attributeSets[i];
  	 	gehituTestua("It has JiniDoc!!\n");	                 
  	 	badauka = true;
                }
       }
			ateraInformazioa(badauka);
  }


}
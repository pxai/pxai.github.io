

package com.ebila.jini.JiniAdministrator;

// import gunea
import java.awt.*;
import java.awt.event.*;
import java.util.StringTokenizer;



// klasearen deklarazioa
public
class PanelSarea
extends Panel {
  BorderLayout borderLayout1 = new BorderLayout();
  Panel panelGoikoa = new Panel();
  Label labelTituloa = new Label();
  Panel panelSatan = new Panel();
  Panel panel1 = new Panel();
  BorderLayout borderLayout2 = new BorderLayout();
  TextField textFieldHost = new TextField();
  Label labelSatan = new Label();
  List listSatan = new List();
  Button buttonSatan = new Button();
  Panel panelErdikoa = new Panel();
  BorderLayout borderLayout3 = new BorderLayout();
  Panel panelBotoiak = new Panel();
  FlowLayout flowLayout1 = new FlowLayout();
  TextField textFieldIp = new TextField();
  Button buttonPing = new Button();
  Button buttonTrace = new Button();
  Button buttonNetstat = new Button();
  Label labelHost = new Label();
  Button buttonJiniPing = new Button();
  Button buttonStop = new Button();
  protected ProgramaExekutatu exekuzioHaria = null;
  protected Sarea satanHaria = null;
  List listExekutatu = new List();
  Label labelExekuzioa = new Label();

  public PanelSarea() {
    try  {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    this.setBackground(Color.lightGray);
    labelTituloa.setText("Panel Network:");
    labelSatan.setText("Host IName:");
    textFieldHost.setText("host.domain.com");
    buttonSatan.setLabel("Port scanner");
    textFieldIp.setText("<host>");
    buttonPing.setLabel("Ping");
    buttonPing.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonPing_actionPerformed(e);
      }
    });
    buttonTrace.setLabel("TraceRoute");
    buttonTrace.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonTrace_actionPerformed(e);
      }
    });
    labelHost.setText("Host:");
    buttonJiniPing.setLabel("JiniPing");
    buttonJiniPing.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonJiniPing_actionPerformed(e);
      }
    });
    buttonStop.setLabel("Stop");
    listExekutatu.setForeground(new Color(0, 183, 0));
    listExekutatu.setFont(new Font("TimesRoman", 1, 12));
    listExekutatu.setBackground(Color.black);
    labelExekuzioa.setText("Execution stat");
    buttonStop.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonStop_actionPerformed(e);
      }
    });
    buttonNetstat.setLabel("NetStat");
    buttonNetstat.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonNetstat_actionPerformed(e);
      }
    });
     buttonSatan.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonSatan_actionPerformed(e);
      }
    });
    panelBotoiak.setLayout(flowLayout1);
    panelErdikoa.setLayout(borderLayout3);
    panelSatan.setLayout(borderLayout2);
    this.add(panelGoikoa, BorderLayout.NORTH);
    panelGoikoa.add(labelTituloa, null);
    this.add(panelSatan, BorderLayout.SOUTH);
    panelSatan.add(panel1, BorderLayout.CENTER);
    panel1.add(labelSatan, null);
    panel1.add(textFieldHost, null);
    panel1.add(buttonSatan, null);
    panelSatan.add(listSatan, BorderLayout.SOUTH);
    this.add(panelErdikoa, BorderLayout.CENTER);
    panelErdikoa.add(panelBotoiak, BorderLayout.NORTH);
    panelBotoiak.add(labelHost, null);
    panelBotoiak.add(textFieldIp, null);
    panelBotoiak.add(buttonPing, null);
    panelBotoiak.add(buttonTrace, null);
    panelBotoiak.add(buttonJiniPing, null);
    panelBotoiak.add(buttonNetstat,null);
    panelBotoiak.add(buttonStop, null);
    panelErdikoa.add(listExekutatu, BorderLayout.CENTER);
    panelErdikoa.add(labelExekuzioa, BorderLayout.SOUTH);
  }

  void buttonPing_actionPerformed(ActionEvent e) {
	if (exekuzioHaria != null)
		exekuzioHaria.stop();
        exekuzioHaria = new ProgramaExekutatu("ping "+textFieldIp.getText(),listExekutatu,labelExekuzioa);
	   exekuzioHaria.start();
  }

  // Trace botoia sakatzen denean exekutatzen den metodoa
  void buttonTrace_actionPerformed(ActionEvent e) {
	if (exekuzioHaria != null)
		exekuzioHaria.stop();
         exekuzioHaria = new ProgramaExekutatu("tracert "+textFieldIp.getText(),listExekutatu,labelExekuzioa);
	   exekuzioHaria.start();

  }

// Trace botoia sakatzen denean exekutatzen den metodoa
  void buttonNetstat_actionPerformed(ActionEvent e) {
	if (exekuzioHaria != null)
		exekuzioHaria.stop();
         exekuzioHaria = new ProgramaExekutatu("netstat "+textFieldIp.getText(),listExekutatu,labelExekuzioa);
	   exekuzioHaria.start();

  }

  // Ping botoia sakatzen denean exekutatzen den metodoa
  void buttonJiniPing_actionPerformed(ActionEvent e) {
  	int port = 4160;
  	String host = "";
  	StringTokenizer st = null;
  	try {
  	st = new StringTokenizer(textFieldIp.getText(),":");
  	host = st.nextToken();
  	port = Integer.parseInt(st.nextToken());
    } catch (Exception ex) {
    	listExekutatu.addItem("Sintax Error: "+ textFieldIp.getText());	
    	listExekutatu.addItem("To execute Jiniping insert in texfield-> host:port");
    	return;	
    }
	if (exekuzioHaria != null)
		exekuzioHaria.stop();
         JiniPing jp = new JiniPing(host,port,listExekutatu,labelExekuzioa);
  }

 // Satan botoia sakatzen denean exekutatzen den metodoa
  void buttonSatan_actionPerformed(ActionEvent e) {
		if (buttonSatan.getLabel().equals("Port scanner"))  {
			if (satanHaria != null) 
					satanHaria.stop();
     	satanHaria = new Sarea(textFieldHost.getText(),listSatan);
	   	satanHaria.start();
	   	buttonSatan.setLabel("Stop");
	   }
	  else {
	  	satanHaria.stop();
	  	listSatan.addItem("Execution stopped");
	  	buttonSatan.setLabel("SATAN!!!");
	  }

  }

  // Stop botoia sakatzen denean exekutatzen den metodoa
  void buttonStop_actionPerformed(ActionEvent e) {
	if (exekuzioHaria != null) {
	exekuzioHaria.stop();
	   labelExekuzioa.setText("Execution stopped");
	}
  }
} 
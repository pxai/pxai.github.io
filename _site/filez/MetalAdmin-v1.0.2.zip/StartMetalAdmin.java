

import com.ebila.jini.JiniAdministrator.JiniAdministrator;

public 
class StartMetalAdmin	{

public static void main (String args[])	{
	System.out.println("StartMetalAdmin> Starting Jini Administrator v1.0.2...");
	JiniAdministrator ja = new JiniAdministrator();	
	new Thread(ja).start();
}
}
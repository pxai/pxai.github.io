package info.pello.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SerONoSerGameActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game);
        Button botonmenu = (Button) findViewById(R.id.botonmenu);
       botonmenu.setOnClickListener(new View.OnClickListener() {
    	    public void onClick(View view) {
    	    	Intent miIntent = new Intent(SerONoSerGameActivity.this, SerONoSerMenuActivity.class);
    	    	startActivity(miIntent);
    	    	SerONoSerGameActivity.this.finish();
    	    }
    	});
    }
}
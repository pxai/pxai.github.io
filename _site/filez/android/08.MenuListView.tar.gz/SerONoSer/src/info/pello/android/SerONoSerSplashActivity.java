package info.pello.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class SerONoSerSplashActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);
       // iniciar.setOnClickListener(this);
        Button botonmenu = (Button) findViewById(R.id.botonmenu);
        //ImageView imagen = (ImageView) findViewById(R.id.LogoInstituto);
        TextView logo1 = (TextView) findViewById(R.id.titulo);
        Animation animacionFundido = AnimationUtils.loadAnimation(this, R.anim.fundido);
        logo1.startAnimation(animacionFundido);

        Animation vueltas = AnimationUtils.loadAnimation(this, R.anim.animacion);
        LayoutAnimationController controller =
            new LayoutAnimationController(vueltas);

        ImageView logo = (ImageView) findViewById(R.id.LogoInstituto);
        logo.startAnimation(vueltas);
        
        botonmenu.setOnClickListener(new View.OnClickListener() {
    	    public void onClick(View view) {
    	    	Intent miIntent = new Intent(SerONoSerSplashActivity.this, SerONoSerMenuActivity.class);
    	    	startActivity(miIntent);
    	    	SerONoSerSplashActivity.this.finish();
    	    }
    	});
        
        animacionFundido.setAnimationListener(new AnimationListener() {
            public void onAnimationEnd(Animation animation) {
                startActivity(new Intent(SerONoSerSplashActivity.this,
                		SerONoSerMenuActivity.class));
                SerONoSerSplashActivity.this.finish();
            }

			@Override
			public void onAnimationRepeat(Animation arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onAnimationStart(Animation arg0) {
				// TODO Auto-generated method stub
				
			}
        });


    }
    

}
package info.pello.android;

import java.io.IOException;
import java.util.Vector;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
/*
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;*/
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class RedesActivity extends Activity {
	
	private EditText etUrl;
	private EditText etLogin;
	private EditText etPassword;
	
	private TextView tvResultado;
	private TextView tvResultadoPost;
	private WebView webview;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        etUrl = (EditText) findViewById(R.id.etUrl);
        etLogin = (EditText) findViewById(R.id.etLogin);
        etPassword = (EditText) findViewById(R.id.etPassword);
        
        tvResultado = (TextView) findViewById(R.id.tvResultado);
        tvResultadoPost = (TextView) findViewById(R.id.tvResultadoPost);

        // Definimos el webview
        webview = (WebView) findViewById(R.id.webview);
        // Con esto conseguimos que no se salga del WebView
        webview.setWebViewClient(new WebViewClient());
    }
    
      
    /*
     * consultarWebView
     * Hace una petición a la web y carga el resultado
     * @param View v
     */
    public void consultarWebView (View v) {
    	String url = etUrl.getText().toString();
    	
    	if (url.equals("")) {
    		tvResultado.setText("Cargando google");
    		webview.loadUrl("http://www.google.com");
    	} else {
    		tvResultado.setText("Cargando " + url);
    		webview.loadUrl(url);
    	}
    }
    
    /*
     * consultar
     * Hace una petición a la web
     * Todo a mano con httpclient
     * @param View v
     */
    public void consultar (View v) {
    	String url = etUrl.getText().toString();
    	HttpGet peticion = new HttpGet(url);
		HttpClient cliente = new DefaultHttpClient();
		
    	try {
			ResponseHandler<String> respuesta = new BasicResponseHandler();
			String cuerpoRespuesta = cliente.execute(peticion,respuesta);

			if (cuerpoRespuesta != null && cuerpoRespuesta.length() > 0) {
				tvResultado.setText("OK\n: " + cuerpoRespuesta);
			} else {
				tvResultado.setText("Error\n"+cuerpoRespuesta);
			}

		} catch (ClientProtocolException e) {
			tvResultado.setText("Unexpected ClientProtocolException" + e);
		} catch (IOException e) {
			tvResultado.setText("Unexpected IOException" + e);
		}

    }
    
    /*
     * postear
     * Envía una petición a la web.. con POST pasando parametros
     * @param View v
     */
    public void postear (View v) {
    	String url = etUrl.getText().toString();
    	String login = etLogin.getText().toString();
    	String password = etPassword.getText().toString();
    	
    	HttpPost peticion = null;
		HttpClient cliente = null;
		
		Vector<NameValuePair> parametros = new Vector<NameValuePair>();
		ResponseHandler<String> respuesta = new BasicResponseHandler();
		
    	try {
    		parametros.add(new BasicNameValuePair("login", login));
    		parametros.add(new BasicNameValuePair("password", password));
    		
    		url +=  "?" + URLEncodedUtils.format(parametros, null);

    		peticion = new HttpPost(url);
			cliente = new DefaultHttpClient();
    		
			String cuerpoRespuesta = cliente.execute(peticion,respuesta);
	    	

			
			if (cuerpoRespuesta != null && cuerpoRespuesta.length() > 0) {
				tvResultado.setText("OK\n: " + cuerpoRespuesta);
			} else {
				tvResultado.setText("Inesperado: \n"+cuerpoRespuesta);
			}

		} catch (ClientProtocolException e) {
			tvResultado.setText("Unexpected ClientProtocolException" + e);
		} catch (IOException e) {
			tvResultado.setText("Unexpected IOException" + e);
		}  	
    }

}
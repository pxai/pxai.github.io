package info.pello.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class SerONoSerSplashActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);
       // iniciar.setOnClickListener(this);
        Button botonmenu = (Button) findViewById(R.id.botonmenu);
       botonmenu.setOnClickListener(new View.OnClickListener() {
    	    public void onClick(View view) {
    	    	Intent miIntent = new Intent(SerONoSerSplashActivity.this, SerONoSerMenuActivity.class);
    	    	startActivity(miIntent);
    	    	SerONoSerSplashActivity.this.finish();
    	    }
    	});

    }
    

}
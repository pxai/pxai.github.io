package info.pello.android;

import android.app.Activity;
import android.graphics.drawable.BitmapDrawable;
//import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TextView;

public class DroidResourcesActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        // Recurso de Android
       // String confirm = Resources.getSystem().getString(android.R.string.ok);
        // res/values/dimens.xml
        // float thumbnailDim = getResources().getDimension(R.dimen.thumbDim);
        // res/values/colors.xml
        // int textColor = getResources().getColor(R.color.app_text_color);
        // En im�genes debe coincidir el fichero: logo.png con el id
        //BitmapDrawable logoBitmap = (BitmapDrawable)getResources().getDrawable(R.drawable.logo);

        // Por si necesito acceder a todo un Layout como el main.xml
        // LayoutInflater inflater = getLayoutInflater();
        // View layout = inflater.inflate(R.layout.main, null);
        
        // Accediendo a un control:
        TextView txt = (TextView)findViewById(R.id.textViewHello);
        
        // Acceder a un fichero llamado res/xml/fichero.xml
        // XmlResourceParser defaultDataConfig = getResources().getXml(R.xml.fichero);
        
        // Acceder a un fichero de texto: res/raw/fichero1.txt
        // InputStream iFile = getResources().openRawResource(R.raw.fichero1);
        
        // Recursos que No queremos que se compilen: van a assets
        // Accedemos a ellos con AssetManager
    }
}
package info.pello.android;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

public class FormularioPreferenciasActivity extends Activity {
	
	public static final String PREF_NOMBRE = "Nombre";
	public static final String PREF_EMAIL = "Email";
	public static final String PREF_PASSWORD = "Password";
	public static final String PREF_DESCRIPCION = "Descripcion";
	public static final String PREF_NACIMIENTO = "Nacimiento";
	public static final String PREF_GENERO = "Genero";
	public static final String PREF_ESTUDIOS = "Estudios";
	private static final String PREFERENCIAS = "Preferencias";
	public static SharedPreferences preferencias;

	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        preferencias = getSharedPreferences(PREFERENCIAS, Context.MODE_PRIVATE);

        cargarPreferencias();
        
        // Spinner para el género
        final Spinner sGenero = (Spinner) findViewById(R.id.sGenero);
        
        ArrayAdapter<?> adapter = ArrayAdapter.createFromResource(this,
                R.array.generos, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item);
        
        sGenero.setAdapter(adapter);

        // Listener para la lista
        sGenero.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
        	        @Override
        	        public void onItemSelected(AdapterView<?> parent, View itemSelected,
        	            int selectedItemPosition, long selectedId) {
        	            // TODO: Save item index (selectedItemPosition) as Gender setting
        	        }

					@Override
					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
						
					}
        	    });

        final Button btnOk = (Button) findViewById(R.id.btnOk);
        
        btnOk.setOnClickListener(new View.OnClickListener() {
    	    public void onClick(View view) {
    	    	salvarPreferencias();
    	    	// Tomamos la caja de texto
    	    	EditText resultado = (EditText) findViewById(R.id.txtvResultado);
    	    	resultado.setText("Ok, datos guardados");
    	    }
    	});

    }
    
    
    private void cargarPreferencias () {
    	EditText etNombre = (EditText) findViewById(R.id.etNombre);
    		if (preferencias.contains(PREF_NOMBRE)) {
    		    etNombre.setText(preferencias.getString(PREF_NOMBRE, ""));
    		}
    		
        	EditText etEmail = (EditText) findViewById(R.id.etEmail);
    		if (preferencias.contains(PREF_EMAIL)) {
    		    etEmail.setText(preferencias.getString(PREF_EMAIL, ""));
    		}

        	EditText etDescripcion = (EditText) findViewById(R.id.etDescripcion);
    		if (preferencias.contains(PREF_DESCRIPCION)) {
    			etDescripcion.setText(preferencias.getString(PREF_DESCRIPCION, ""));
    		}

        	DatePicker dpNacimiento = (DatePicker) findViewById(R.id.dpNacimiento);
    		if (preferencias.contains(PREF_NACIMIENTO)) {
    			String[] st = preferencias.getString(PREF_NACIMIENTO, "").split("-");
    			etDescripcion.setText(preferencias.getString(PREF_NACIMIENTO, ""));
    			if (preferencias.getString(PREF_NACIMIENTO, "").length() > 0)
    				dpNacimiento.updateDate(Integer.parseInt(st[0]),Integer.parseInt(st[1]),Integer.parseInt(st[2]));    			
    		}
    }
    
    /**
     * salvarPreferencias
     * Guarda las preferencias
     */
    private void salvarPreferencias() {

    	Editor editor = preferencias.edit();

    	// Tomamos la caja de texto
    	EditText etNombre = (EditText) findViewById(R.id.etNombre);
    	// Sacamos el string
    	String strNombre = etNombre.getText().toString();
    	// y Lo guardamos en preferencias
        editor.putString(PREF_NOMBRE, strNombre);

    	// Tomamos la caja de texto
    	EditText etEmail = (EditText) findViewById(R.id.etEmail);
    	// Sacamos el string
    	String strEmail = etEmail.getText().toString();
    	// y Lo guardamos en preferencias
        editor.putString(PREF_EMAIL, strEmail);

    	// Tomamos la caja de texto
    	EditText etDescripcion = (EditText) findViewById(R.id.etDescripcion);
    	// Sacamos el string
    	String strDescripcion = etDescripcion.getText().toString();
    	// y Lo guardamos en preferencias
        editor.putString(PREF_DESCRIPCION, strDescripcion);

    	// Tomamos la caja de texto
    	DatePicker dpNacimiento = (DatePicker) findViewById(R.id.dpNacimiento);
    	// Sacamos el string
    	String strNacimiento = dpNacimiento.getYear()+"-"+dpNacimiento.getMonth()+"-"+dpNacimiento.getDayOfMonth();
    	// y Lo guardamos en preferencias
        editor.putString(PREF_NACIMIENTO, strNacimiento);

        // Y commit de los cambios
        editor.commit();

    }
    
    @Override
    protected void onDestroy() {
        Log.d("debug", "SHARED PREFERENCES");
        Log.d("debug", "El nombr es: "
            + preferencias.getString(PREF_NOMBRE, "está vacío"));
        
        /*
        Log.d(DEBUG_TAG, "Nacimiento"
            + DateFormat.format("MMMM dd, yyyy", preferencias.getLong(
                    PREF_NACIMIENTO, 0)));*/
        super.onDestroy();
      }

}
/**
 * SaveActualizacionLeccionMecanoAction.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */
 
 
package pxai.taglib;


import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

import pxai.comun.Log;
import pxai.comun.Propiedades;



/**
 * SesionTag.java
 *
 * 
 * Comprueba si la sesion esta iniciada o no.
 *
 * @author Pello Xabier Altadill Izura
 * @version v1.2 Fecha: 2002/01/25 02:10:00 
 */

public class SesionTag extends TagSupport {

 


    /**
     * El atributo action, opcional , se refiere a la accion a realizar:
     *
     */
    private String action = null;
    
   

	/*************** METODOS JAVABEAN ************************/



    /**
     * Devuelve el atributo ds
     * @return action
     */
    public String getAction() {
		return (this.action);
    }


    /**
	 * Establece el atributo ds
     * @param String  action
     */
    public void setAction(String action) {
		this.action = action;
    }

    /**
    * checkSession
    * Comprueba que la sesion esta iniciada
    * @return boolean true/false
    */
	private boolean checkSession () {
		HttpSession sesion = null;
		String sesionId = "";
		
		try {

		sesion = pageContext.getSession();

		// Primera comprobacion: tenemos
	  	if (sesion.getAttribute("idSesion")!=null) 
			  sesionId = (String)sesion.getAttribute("idSesion");			 
		 else 
	 		return false;

		// Segunda comprobacion		
	 	if(sesionId.equals(sesion.getId()) )
	 	//Si el ID  es el mismo que teniamos guardado Y
	 	//ademas se conserva el objeto de sesion
	 		return true;
	 	else 
	 		return false;
	 		
		} catch (Exception e) {
			e.printStackTrace(System.err);
			Log.write("<SesionTag>Error al comprobar sesion: " + e.getMessage() + "</SesionTag>");
			return false;
		}
	}

	/**
	* logOut
	* termina la sesion y borra los datos almacenados en sesion.
	* 
	*/
	private void logOut () {
		HttpSession sesion = null;
		try {
			sesion = pageContext.getSession();
			sesion.removeAttribute("idSesion");	 		
			sesion.removeAttribute("login");	 		

			Log.write("<SesionTag>Sesion cerrada</SesionTag>");
		} catch (Exception e) {
			Log.write("<SesionTag>Error al cerrar sesion "+ e.getMessage()+"</SesionTag>");
		}	
	}
	
    /**
     * Escribe el principio de la etiqueta
     * @return int
     * @exception JspException  si ocurre una excepcion JSP
     */
    public int doStartTag() throws JspException {
		StringBuffer results = new StringBuffer("");
		String sTemp = "";
		String sTemp2 = "";
		HttpSession session = null;
		String usuario = "";
		String urlinicio = (Propiedades.getPropiedad("urlinicio") != null)?(Propiedades.getPropiedad("urlinicio").trim()):"editIndexMecano.do?action=logout";
				
		try {		
			// Se toma el stream de salida
			JspWriter writer = pageContext.getOut();
		
			// Si nos han pasado al atributo action con valor 'check' o vacio
			// comprobamos que la sesion esta activa y la pagina del usuario es valida
			if (this.getAction() == null || this.getAction().trim().compareTo("") == 0 ||  this.getAction().trim().toLowerCase().compareTo("check") == 0) {
				if (!checkSession()) { // Sesion incorrecta!
					Log.write("<SesionTag/>Sesion incorrecta!!");
				    writer.print(results.toString());
					pageContext.forward(urlinicio);
				}				
					return (EVAL_BODY_INCLUDE);
			}
			
			// Si nos han pasado al atributo action con valor 'admin'
			// devolvemos el nombre de usuario
			session = pageContext.getSession();
			if (session != null && this.getAction() != null && this.getAction().trim().toLowerCase().compareTo("admin") == 0) {
					usuario = (session.getAttribute("login") != null)?(""+session.getAttribute("login")):"";
					if (!usuario.equals("admin")) {
						Log.write("<SesionTag/>Error: acceso solo para administradores");
					    writer.print(results.toString());
						pageContext.forward(urlinicio);						
					}
					return (EVAL_BODY_INCLUDE);
			}

			// Si nos han pasado al atributo action con valor 'logout'
			if (pageContext.getSession() != null && this.getAction() != null && this.getAction().trim().toLowerCase().compareTo("logout") == 0) {
				this.logOut();
			}
			
		} catch (IOException ioe) {
			Log.write("<SesionTag/>Error io al comprobar sesion: " + ioe.getMessage());
		}
		 catch (Exception e) {
		 	e.printStackTrace(System.err);
			Log.write("<SesionTag/>Error al comprobar sesion: " + e.getMessage());
		}
		// Evalua el body de la
		return (EVAL_BODY_INCLUDE);

	}



    /**
     * Escribe el cierre del TAG
     *
     * @return int
     * @exception JspException si ocurre una excepcion JSP
     */
    public int doEndTag() throws JspException {

		// Imprime el elemento de cierre.		
		JspWriter writer = pageContext.getOut();
		
		
			try {
			    writer.print("");
			} catch (IOException e) {
			    throw new JspException(e.toString());
			}

		return (EVAL_PAGE);

    }


    /**
     * Release cualquier recurso adquirido
     */
    public void release() {
        super.release();
    }


}

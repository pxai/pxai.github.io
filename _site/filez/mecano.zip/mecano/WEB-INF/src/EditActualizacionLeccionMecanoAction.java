/**
 * EditActualizacionLeccionMecanoAction.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */

package pxai.struts.mecano.action;


import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Locale;
import java.util.Vector;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;
import org.apache.struts.util.PropertyUtils;
import pxai.struts.mecano.bean.LeccionMecanoBean;
import pxai.struts.mecano.form.ActualizacionLeccionMecanoForm;

/**
 * EditActualizacionLeccionMecanoAction.java
 * Maneja las peticiones enviadas por el browser 
 * @author   <a href="pello.altadill@terra.com">Pello Xabier Altadill Izura</a>
 * @version 1.0 , date 13/2/02
*/
public final class EditActualizacionLeccionMecanoAction extends Action {



	/**
	* Procesa la peticion HTTP (request) especificada y genera su correspondiente
	* respuesta HTTP (response) (o lo redirige a otro componente web que podria crear).
	* Devuelve una instancia code>ActionForward</code> que describe a DONDE y COMO
	* se redirige el control, o sino, si la respuesta se ha completado se devolveria
	* <code>null</code>
	*
	* @param mapping El mapeo utilizado para seleccionar esta instancia
	* @param request El request que estamos procesando
	* @param actionForm La instancia ActionForm que estamos utilizando (si la hay)
	* @param response La respuesta HTTP que creamos.
	*
	* @exception IOException en caso de error de entrada/salida (i/o)
	* @exception ServletException en caso de error de servlet
	*/
	public ActionForward perform(ActionMapping mapping,
						ActionForm form,
						HttpServletRequest request,
						HttpServletResponse response)
						throws IOException, ServletException {

		// Extrae los atributos que se necesitan
		Locale locale = getLocale(request);
		MessageResources messages = getResources();
		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		ActionErrors errors = null;
		LeccionMecanoBean leccionBean = null;
		Vector resultadoBusqueda = null;
						
		try {
		
		if (action == null)
			action = "Create";

		// Guarda el log segun el nivel de Debug.
		if (servlet.getDebug() >= 1)
			servlet.log("EditXAction:  Procesando action " + action);

		/************************************ *******************************************/
		// Logica de negocio (opcional, segun necesidades de la aplicacion)
		
		if (request.getParameter("codleccion") != null && request.getParameter("codleccion").toString().trim().compareTo("") != 0 ) {
			leccionBean = new LeccionMecanoBean(new Integer(request.getParameter("codleccion")),null,null,null,null);

			// utilizamos la misma llamada que en la busqueda.
			leccionBean = leccionBean.detalle();	
			
			// Asignamos al formulario para que se refleje en la pagina.
			if (leccionBean != null) {
				((ActualizacionLeccionMecanoForm)form).setCodleccion(leccionBean.getCodleccion());
				((ActualizacionLeccionMecanoForm)form).setNombre(leccionBean.getNombre());
				((ActualizacionLeccionMecanoForm)form).setDescripcion(leccionBean.getDescripcion());
				((ActualizacionLeccionMecanoForm)form).setTextoleccion(leccionBean.getTextoleccion());
				((ActualizacionLeccionMecanoForm)form).setMaxerrores(leccionBean.getMaxerrores());
				
			} else {
			}
		}
		/************************************ *******************************************/
		// Redirige el control en caso de exito a la pagina espcificada en struts-config.xml

		// Guarda el log segun el nivel de Debug.
		if (servlet.getDebug() >= 1)
			servlet.log(" Redirigiendo a pagina 'success'");

		return (mapping.findForward("success"));

		} catch (Exception e) {
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			errors = new ActionErrors();
			errors.add("action",new ActionError("action.perform.carga.error"));
			saveErrors(request,errors);
			return (mapping.findForward("failure"));
		}
	}

}
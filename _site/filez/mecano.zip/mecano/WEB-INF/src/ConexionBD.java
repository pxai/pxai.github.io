/**
 * ConexionBD.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */
 
package pxai.comun;

import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.DataSource;
import javax.naming.Context;
import javax.naming.InitialContext;
import java.sql.DriverManager;

/**
 * Ofrece los m�todos necesarios para obtener una conexi�n a la BD
 *
 * Bean abstracto de la aplicacion Mecano
 *
 * @author   <a href="pello.altadill@terra.com">Pello Xabier Altadill Izura</a>
 * @version 1.0 , date 13/2/02
*/
public class ConexionBD  {	
	/**
	* @field Propiedad autoCommit
	*/
	private boolean autoCommit=false;
	
	/**
	* Devuelve una conexi�n con la base de datos.
	*
	* @param sNombreDs Nombre del Data Source del que se 
	* quiere obtener una conexi�n
	* @return Connection istancia de conexion a la base de datos
	*/
	public Connection getConexion(String sNombreDs) {
		// Declaracion de variables
		Context 	ctxContexto;		// Contexto de conexi�n
		DataSource 	dtsDataSource;		// Conexi�n jndi
		Connection 	conConexion;		// Conexi�n con la base de datos    

		// Inicializaciones del contexto	
		ctxContexto = null;

		// Obtiene la conexi�n								
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			//ctxContexto = new InitialContext();
			//dtsDataSource = (DataSource) ctxContexto.lookup ("java:comp/env/jdbc/" + sNombreDs);
			//conConexion = dtsDataSource.getConnection();
			conConexion = DriverManager.getConnection( "jdbc:odbc:mecano","", "");
			
			Log.write("<ConexionBD/>Conectado a BD, DS: "+sNombreDs);
		}catch (Exception e) {
			e.printStackTrace();
			conConexion = null;			
			Log.write("<ConexionBD/>No se pudo conectar a DS "+sNombreDs+ " error: "+e.getMessage());

		}finally {		
			// Si el contexto es distinto de null lo cierra
			if ( ctxContexto != null ){
				try	{
					ctxContexto.close();
				}catch( Exception e ){					
					e.printStackTrace();
				
				}
			}
		}
				
		// Devuelve la conexi�n obtenida		
		return conConexion;
	}	
	
	
	/**
	* Cierra una conexi�n con la base de datos.
	*
	* @param Connection Conexi�n a cerrar.
	*/	
	public void close(Connection conConexion) {	
	
		String catalog = getCatalog(conConexion);
		try {
			conConexion.close();
			Log.write("<ConexionBD/>Conexion a BD "+catalog+" cerrada.");
		} catch (SQLException e) {
			e.printStackTrace();			
			Log.write("<ConexionBD/>No se pudo CERRAR conexion, error: "+e.getMessage());
		}
	}

	/**
	* Realiza un rollback
	*
	* @param Connection Conexi�n sobre la que se hace rollback.
	*/	
	public void rollBack(Connection conConexion) {
		try 
		{
			conConexion.rollback();
			Log.write("<ConexionBD/>RollBack de operacion");			
		} catch (SQLException e) {
			e.printStackTrace();
			Log.write("<ConexionBD/>Error en rollback: "+e.getMessage());			
		}
	}
	
	/**
	* Realiza un commit
	*
	* @param Connection Conexi�n sobre la que se hace commit.
	*/
	public void commit(Connection conConexion) {
		try {
			conConexion.commit();				
		} catch (SQLException e) {
			e.printStackTrace();	
			Log.write("<ConexionBD/>Error en commit: "+e.getMessage());
		}
	}
	
	/**
	* Establece el valor de la propiedad
	*
	* @param boolean Valor a asignar a la propiedad.
	*/
	public void setCommit(Connection conConexion, boolean autoCommit) {
		try {
			conConexion.setAutoCommit(autoCommit);
		} catch (SQLException e) {
			e.printStackTrace();	
			Log.write("<ConexionBD/>Error al poner AutoCommit a : "+autoCommit+" "+e.getMessage());
		}
	}	
	
	/**
	* Retorna el nombre de catalogo
	* 
	* @param  Connection Conexi�n sobre la que se obtiene el catalogo.
	* @return String Nombre del catalogo y null en caso de error.
	*/
	private String getCatalog (Connection con) {
		try {
			return con.getCatalog();
		} catch (SQLException e) {
			e.printStackTrace();	
			Log.write("<ConexionBD/>Error en getCatalog: "+e.getMessage());
			return null;
		}
	}
	
}
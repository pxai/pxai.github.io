/**
 * EditPrincipalMecanoAction.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */

package pxai.struts.mecano.action;


import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Locale;
import java.util.Vector;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;
import org.apache.struts.util.PropertyUtils;
import pxai.struts.mecano.form.PrincipalMecanoForm;
import pxai.struts.mecano.bean.UsuarioMecanoBean;
import pxai.struts.mecano.bean.LeccionMecanoBean;
import pxai.comun.Log;


/**
 * EditPrincipalMecanoAction.java
 * Maneja las peticiones enviadas por el browser 
 * @author   <a href="pello.altadill@terra.com">Pello Xabier Altadill Izura</a>
 * @version 1.0 , date 13/2/02
*/
public final class EditPrincipalMecanoAction extends Action {



	/**
	* Procesa la peticion HTTP (request) especificada y genera su correspondiente
	* respuesta HTTP (response) (o lo redirige a otro componente web que podria crear).
	* Devuelve una instancia code>ActionForward</code> que describe a DONDE y COMO
	* se redirige el control, o sino, si la respuesta se ha completado se devolveria
	* <code>null</code>
	*
	* @param mapping El mapeo utilizado para seleccionar esta instancia
	* @param request El request que estamos procesando
	* @param actionForm La instancia ActionForm que estamos utilizando (si la hay)
	* @param response La respuesta HTTP que creamos.
	*
	* @exception IOException en caso de error de entrada/salida (i/o)
	* @exception ServletException en caso de error de servlet
	*/
	public ActionForward perform(ActionMapping mapping,
						ActionForm theForm,
						HttpServletRequest request,
						HttpServletResponse response)
						throws IOException, ServletException {

		// Extrae los atributos que se necesitan
		Locale locale = getLocale(request);
		MessageResources messages = getResources();
		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		ActionErrors errors = null;
		PrincipalMecanoForm form = null;		
		LeccionMecanoBean leccionBean = null;
		int leccion = 0;
		String login = "";
		String password = "";
				
		try {
				
		if (action == null)
			action = "Create";


		// Si volvemos a la pagina, tras haber abierto sesion, no hay que 
		// meterse en logica de negocio
		if (action.trim().equals("return")) {
				if (session.getAttribute("login") != null && session.getAttribute("login").toString().equals("admin"))
				// Si el usuario es admin, se redirige a su pagina especial
					return (mapping.findForward("successadmin"));			
		}
		
		// Si venimos de la pagina mecano.jsp, directamente tratamos de cargar
		// la siguiente leccion
		if (action.trim().equals("mecano")) {
			login = (String)session.getAttribute("login");;
		} else {
			// cast del form generico al especifico
			form = (PrincipalMecanoForm)theForm;				
			login = form.getLogin();
			password = form.getPassword();
		}
					
			/********************** LLAMADA A LOGICA DE NEGOCIO *****************************/

	
			//Instancia el bean de l�gica de negocio				
	  		UsuarioMecanoBean usuarioBean = new UsuarioMecanoBean(login,password,"");
			
			//Invoca al proceso de alta y recoge el valor de vuelta
			if (action.trim().equals("mecano")) {
				usuarioBean = usuarioBean.detalle();
			} else {
				errors = usuarioBean.valida();
			}
			
			if (!form.getLogin().equals("admin") && errors == null ) {
				leccion = (usuarioBean.getLeccion() != null)?(usuarioBean.getLeccion().intValue()):0;
				leccion++;
				leccionBean = new LeccionMecanoBean(new Integer(leccion));
				Log.write("leccionBean: " +leccionBean);
				// recuperamos detalle de Leccion, pero si hay error nos vamos.
				if (( leccionBean = leccionBean.detalle() ) == null) 
					return (mapping.findForward("failure"));					
				else
					request.setAttribute("leccion",leccionBean);
			}
			
			/********************** FIN de LOGICA DE NEGOCIO **********************/
			Log.write("Errores: " +errors);
			// En caso de ser el login incial, tirara por aqui.
			if (errors==null ) {//Se ejecut� correctamente
				request.setAttribute("usuario",usuarioBean);
				// Guardamos valor de login en sesion
				session.setAttribute("idSesion",session.getId());
				session.setAttribute("login",form.getLogin());
				// Si el usuario es admin, se redirige a su pagina especial
				if (form.getLogin().equals("admin"))
					return (mapping.findForward("successadmin"));
				else
					return (mapping.findForward("success"));
			} else { //Hubo errores
				saveErrors(request,errors);
				return (mapping.findForward("failure"));
			}	

		} catch (Exception e) {
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			errors = new ActionErrors();
			errors.add("action",new ActionError("action.principal.error"));
			saveErrors(request,errors);
			return (mapping.findForward("failure"));
		}
	}

}
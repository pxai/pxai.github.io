/**
 * UsuarioMecanoBean.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */

package pxai.struts.mecano.bean;

import java.util.Date;
import java.util.Vector;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import pxai.comun.Log;
import pxai.comun.Data;
import pxai.comun.DataService;

/**
 * UsuarioMecanoBean.java
 *
 * Entidad Usuario
 *
 * Implementa la l�gica de negocio para el proceso X
 * @author   <a href="pello.altadill@terra.com">Pello Xabier Altadill Izura</a>
 * @version 1.0 , date 13/2/02
*/
public class UsuarioMecanoBean  {

	
	/**
	* @field login : login de usuario
	*/
	private String login = null;
	
	/**
	* @field password : login de usuario
	*/
	private String password = null;

	/**
	* @field nombre : nombre de usuario
	*/
	private String nombre = null;

	/**
	* @field fechaingreso : fechaingreso de usuario
	*/
	private String fechaingreso = null;

	/**
	* @field ultimaleccion : ultimaleccion de usuario
	*/
	private Integer leccion = null;

	/**
	* @field velocidadmedia : velocidadmedia de usuario
	*/
	private Float velocidadmedia = null;
	
	/**
	* @field mediaerrores : mediaerrores de usuario
	*/
	private Float mediaerrores = null;
	
	/**
	* constructor
	*/
	public UsuarioMecanoBean() {}
	
	/**
	* constructor
	*/	
	public UsuarioMecanoBean (String login, String password, String nombre) {
		this.login = login;
		this.password = password;
		this.nombre = nombre;
	}
	
	/**
	* constructor
	*/
	public UsuarioMecanoBean(String login, String password, String nombre, 
				String fechaingreso, Integer ultimaleccion, Float velocidadmedia, 
				Float mediaerrores) {
		this.login = login;
		this.password = password;
		this.nombre = nombre;
		this.fechaingreso = fechaingreso;
		this.leccion = ultimaleccion;
		this.velocidadmedia = velocidadmedia;
		this.mediaerrores = mediaerrores;
	}
	
	/****************** Metodos Bean *********************/
	public void setLogin(String login) {
		this.login = login; 
	}

	public void setPassword(String password) {
		this.password = password; 
	}

	public void setNombre(String nombre) {
		this.nombre = nombre; 
	}

	public void setFechaingreso(String fechaingreso) {
		this.fechaingreso = fechaingreso; 
	}

	public void setLeccion(Integer ultimaleccion) {
		this.leccion = ultimaleccion; 
	}

	public void setVelocidadmedia(Float velocidadmedia) {
		this.velocidadmedia = velocidadmedia; 
	}

	public void setMediaerrores(Float mediaerrores) {
		this.mediaerrores = mediaerrores; 
	}
	public String getLogin() {
		return (this.login); 
	}

	public String getPassword() {
		return (this.password); 
	}

	public String getNombre() {
		return (this.nombre); 
	}

	public String getFechaingreso() {
		return (this.fechaingreso); 
	}

	public Integer getLeccion() {
		return (this.leccion); 
	}

	public Float getVelocidadmedia() {
		return (this.velocidadmedia); 
	}

	public Float getMediaerrores() {
		return (this.mediaerrores); 
	}
	/****************** Fin Metodos Bean *********************/

	/**
	* toString
	* @return String
	*/
	public String toString() {
		String ret = null;
		ret = "login = " + login + "\n";
		ret += "password = " + password + "\n";
		ret += "nombre = " + nombre + "\n";
		ret += "fechaingreso = " + fechaingreso + "\n";
		ret += "leccion = " + leccion + "\n";
		ret += "velocidadmedia = " + velocidadmedia + "\n";
		ret += "mediaerrores = " + mediaerrores + "\n";
		return ret;
	}	
	
	/**
	* alta
	* @return ActionErrors
	*/
	public ActionErrors alta () {

		//Instancia un objrcto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		DataService dataservice = null;
		Data data = null;
		String fecha = new Date().toString();
		
		try	{
			// Conectamos con la BBDD
			dataservice = new DataService("DataSourceMecano");
			data = new Data();
			
			// Una primera consulta para comprobar si existe
			if ((theActionErrors = dataservice.getData("SelectUsuarioCount",new Object[]{login},data)) != null) {
				dataservice.close();
				return theActionErrors;
			}
			
			// Si el usuario existe, no se puede dar el alta
			if (data.getValue("total") != null && !data.getValue("total").toString().equals("0")) {
				dataservice.close();
				theActionErrors = new ActionErrors();
				theActionErrors.add("bean",new ActionError("alta.usuarioreplicado.error"));
				return theActionErrors;
			}
			
			// Si no, adelante con el alta
			theActionErrors = dataservice.setData("InsertUsuario",new Object[]{login,password,nombre,fecha,new Integer(0),new Float(0),new Float(0)});
			
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("alta.usuario.error"));
			Log.write("<UsuarioMecanoBean/>"+e.getMessage());
		} finally {
			// cerramos la conexion en cualquier caso.
				dataservice.close();
		}

			return theActionErrors;
	}
	
	/**
	* valida
	* @return ActionErrors
	*/
	public ActionErrors valida () {

		//Instancia un objrcto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		DataService dataservice = null;
		Data data = null;
		String fecha = new Date().toString();
		
		try	{
			// Conectamos con la BBDD
			dataservice = new DataService("DataSourceMecano");
			data = new Data();
			
			// Una primera consulta para comprobar si existe
			if ((theActionErrors = dataservice.getData("SelectUsuario",new Object[]{login},data)) != null) {
				dataservice.close();
				return theActionErrors;
			}		
			
			
			if (data.getRecordCount() == 1 && data.getValue("password").toString().trim().equals(password)) {
				this.setNombre(data.getValue("nombre").toString());
				this.setFechaingreso(data.getValue("fechaingreso").toString());
				this.setLeccion(new Integer(data.getValue("leccion").toString()));
				this.setMediaerrores(new Float(data.getValue("mediaerrores").toString()));
				this.setVelocidadmedia(new Float(data.getValue("velocidadmedia").toString()));
			} else {
				dataservice.close();
				theActionErrors = new ActionErrors();
				theActionErrors.add("bean",new ActionError("valida.loginincorrecto.error"));
				return theActionErrors;
			}
					
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("valida.usuario.error"));
			Log.write("<UsuarioMecanoBean/>"+e.getMessage());
		} finally {
				dataservice.close();
			// cerramos la conexion en cualquier caso.
		}

			return theActionErrors;
	}

	/**
	* busqueda
	* @return ActionErrors
	*/
	public Vector busqueda () {

		//Instancia un objrcto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		DataService dataservice = null;
		Data data = null;
		String fecha = new Date().toString();
		Vector resultado = new Vector();
		Vector vTemp = null;
		
		try	{
			// Conectamos con la BBDD
			dataservice = new DataService("DataSourceMecano");
			data = new Data();
			
			// Una primera consulta para comprobar si existe
			if ((theActionErrors = dataservice.getData("SelectUsuarioBusqueda","CamposUsuarioBusqueda",new String[]{"LIKE","LIKE","LIKE","=","=","=","="},new Object[]{login,nombre,fechaingreso,leccion,velocidadmedia,mediaerrores},data)) != null) {
				dataservice.close();
				return resultado;
			}		

			// Retornamos el resultado
			return data.data2Entity("pxai.struts.mecano.bean.UsuarioMecanoBean",new String[]{"login","password","nombre","fechaingreso","leccion","velocidadmedia","mediaerrores"});			
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("busqueda.usuario.error"));
			Log.write("<LeccionMecanoBean/>"+e.getMessage());
		} finally {
				dataservice.close();
			// cerramos la conexion en cualquier caso.
		}

			return resultado;
	}
	
	/**
	* update
	* @return ActionErrors
	*/
	public ActionErrors update () {

		//Instancia un objeto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		DataService dataservice = null;
		
		try	{
			// Conectamos con la BBDD
			dataservice = new DataService("DataSourceMecano");
			
			//parametros para el UPDATE
			Object[] obj = new Object[]{password,nombre,leccion,mediaerrores,velocidadmedia,login};
			
			// Sentencia de modificacion
			if ((theActionErrors = dataservice.setData("UpdateUsuario",obj)) != null) {
				dataservice.close();
				return theActionErrors;
			}
										
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("update.usuario.error"));
			Log.write("<UsuarioMecanoBean/>"+e.getMessage());
		} finally {
				dataservice.close();
			// cerramos la conexion en cualquier caso.
		}

			return theActionErrors;
	}

	/**
	* updateAVG
	* actualiza los campos de medias
	* @return ActionErrors
	*/
	public ActionErrors updateAVG () {

		//Instancia un objeto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		DataService dataservice = null;
		
		try	{
			// Conectamos con la BBDD
			dataservice = new DataService("DataSourceMecano");
			
			//parametros para el UPDATE
			Object[] obj = new Object[]{leccion,mediaerrores,velocidadmedia,login};
			
			// Sentencia de modificacion
			if ((theActionErrors = dataservice.setData("UpdateUsuarioAvg",obj)) != null) {
				dataservice.close();
				return theActionErrors;
			}
										
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("updateavg.usuario.error"));
			Log.write("<UsuarioMecanoBean/>"+e.getMessage());
		} finally {
				dataservice.close();
			// cerramos la conexion en cualquier caso.
		}

			return theActionErrors;
	}
	
	/**
	* busqueda
	* @return UsuarioMecanoBean
	*/
	public UsuarioMecanoBean detalle () {

		//Instancia un objrcto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		DataService dataservice = null;
		Data data = null;
		Vector vTemp = null;
		UsuarioMecanoBean result = null;
		
		try	{
			// Conectamos con la BBDD
			dataservice = new DataService("DataSourceMecano");
			data = new Data();
			
			// Una primera consulta para comprobar si existe
			if ((theActionErrors = dataservice.getData("SelectUsuario",new Object[]{login},data)) != null) {
				dataservice.close();
				return result;
			}		

			// Retornamos el resultado
			vTemp = data.data2Entity("pxai.struts.mecano.bean.UsuarioMecanoBean",new String[]{"login","password","nombre","fechaingreso","leccion","velocidadmedia","mediaerrores"});			
			result = (UsuarioMecanoBean)vTemp.firstElement();
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("detalle.usuario.error"));
			Log.write("<UsuarioMecanoBean/>"+e.getMessage());
		} finally {
				dataservice.close();
			// cerramos la conexion en cualquier caso.
		}

			return result;
	}

		
}	// Fin class
/**
 * LeccionMecanoBean.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */

package pxai.struts.mecano.bean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletException;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import java.util.Date;
import java.util.Vector;
import pxai.comun.Log;
import pxai.comun.Data;
import pxai.comun.DataService;



/**
 * LeccionMecanoBean.java
 *
 * Entidad Leccion
 *
 * Implementa la l�gica de negocio para el proceso X
 * @author   <a href="pello.altadill@terra.com">Pello Xabier Altadill Izura</a>
 * @version 1.0 , date 13/2/02
*/
public class LeccionMecanoBean  {

	/**
	* @field codleccion : codleccion de leccion
	*/
	private Integer codleccion = null;
	
	/**
	* @field nombre : nombre de leccion
	*/
	private String nombre = null;

	/**
	* @field descripcion : descripcion de leccion
	*/
	private String descripcion = null;

	/**
	* @field textoleccion : textoleccion de leccion
	*/
	private String textoleccion = null;


	/**
	* @field maxerrores : maxerrores de leccion
	*/
	private Integer maxerrores = null;



	/**
	* constructor
	*/
	public LeccionMecanoBean() { 
	}

	/**
	* constructor
	*/
	public LeccionMecanoBean(Integer codleccion) { 
		this.codleccion = codleccion;
	}
	
	/**
	* constructor
	*/
	public LeccionMecanoBean(Integer codleccion, String nombre, 
				String descripcion, String textoleccion, Integer maxerrores) {
		this.codleccion = codleccion;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.textoleccion = textoleccion;
		this.maxerrores = maxerrores;
	}


	/****************** Metodos Bean *********************/	
	public void setCodleccion(Integer codleccion) {
		this.codleccion = codleccion; 
	}

	public void setNombre(String nombre) {
		this.nombre = nombre; 
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion; 
	}

	public void setTextoleccion(String textoleccion) {
		this.textoleccion = textoleccion; 
	}

	public void setMaxerrores(Integer maxerrores) {
		this.maxerrores = maxerrores; 
	}
	public Integer getCodleccion() {
		return (this.codleccion); 
	}

	public String getNombre() {
		return (this.nombre); 
	}

	public String getDescripcion() {
		return (this.descripcion); 
	}

	public String getTextoleccion() {
		return (this.textoleccion); 
	}

	public Integer getMaxerrores() {
		return (this.maxerrores); 
	}
	/****************** Fin Metodos Bean *********************/

	
	/**
	* toString
	* @return String
	*/
	public String toString() {
		String ret = null;
		ret = "codleccion = " + codleccion + "\n";
		ret += "nombre = " + nombre + "\n";
		ret += "descripcion = " + descripcion + "\n";
		ret += "textoleccion = " + textoleccion + "\n";
		ret += "maxerrores = " + maxerrores + "\n";
		return ret;
	}	

	
	/**
	* alta
	* @return ActionErrors
	*/
	public ActionErrors alta () {

		//Instancia un objrcto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		DataService dataservice = null;
		Data data = null;
		String fecha = new Date().toString();
		
		try	{
			// Conectamos con la BBDD
			dataservice = new DataService("DataSourceMecano");
			data = new Data();
			
			//Inicio de transaccion
			dataservice.setCommit(false);
			
			// Una primera consulta para comprobar si existe
			if ((theActionErrors = dataservice.getData("SelectLastLeccion",null,data)) != null) {
				dataservice.close();
				return theActionErrors;
			}
			
			
			int leccion = (data.getValue("maxleccion") != null)?(new Integer(data.getValue("maxleccion").toString()).intValue() + 1):1;
			codleccion = new Integer(leccion);
			// Si no, adelante con el alta
			theActionErrors = dataservice.setData("InsertLeccion",new Object[]{codleccion,nombre,descripcion,textoleccion,maxerrores});
			
			if (theActionErrors != null) {// en caso de error
				dataservice.rollback();
				dataservice.close();
				throw new Exception("Error al dar de alta una leccion");
			} else {
				// fin de transaccion
				dataservice.commit();
				dataservice.setCommit(true);
				dataservice.close();
				
			}
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("alta.leccion.error"));
			Log.write("<LeccionMecanoBean/>"+e.getMessage());
		} finally {
			// cerramos la conexion en cualquier caso.
				dataservice.close();
		}

			return theActionErrors;
	}
	
	/**
	* busqueda
	* @return ActionErrors
	*/
	public Vector busqueda () {

		//Instancia un objrcto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		DataService dataservice = null;
		Data data = null;
		String fecha = new Date().toString();
		Vector resultado = new Vector();
		Vector vTemp = null;
		
		try	{
			// Conectamos con la BBDD
			dataservice = new DataService("DataSourceMecano");
			data = new Data();
			
			// Una primera consulta para comprobar si existe
			if ((theActionErrors = dataservice.getData("SelectLeccionBusqueda","CamposLeccionBusqueda",new String[]{"=","LIKE","LIKE","LIKE","="},new Object[]{codleccion,nombre,descripcion,textoleccion,maxerrores},data)) != null) {
				dataservice.close();
				return resultado;
			}		

			// Retornamos el resultado
			return data.data2Entity("pxai.struts.mecano.bean.LeccionMecanoBean",new String[]{"codleccion","nombre","descripcion","textoleccion","maxerrores"});			
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("alta.usuario.error"));
			Log.write("<LeccionMecanoBean/>"+e.getMessage());
		} finally {
				dataservice.close();
			// cerramos la conexion en cualquier caso.
		}

			return resultado;
	}

	/**
	* busqueda
	* @return LeccionMecanoBean
	*/
	public LeccionMecanoBean detalle () {

		//Instancia un objrcto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		DataService dataservice = null;
		Data data = null;
		Vector vTemp = null;
		LeccionMecanoBean result = null;
		
		try	{
			// Conectamos con la BBDD
			dataservice = new DataService("DataSourceMecano");
			data = new Data();
			
			// Una primera consulta para comprobar si existe
			if ((theActionErrors = dataservice.getData("SelectLeccion",new Object[]{codleccion},data)) != null) {
				dataservice.close();
				return result;
			}		

			// Retornamos el resultado
			vTemp = data.data2Entity("pxai.struts.mecano.bean.LeccionMecanoBean",new String[]{"codleccion","nombre","descripcion","textoleccion","maxerrores"});			
			result = (LeccionMecanoBean)vTemp.firstElement();
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("detalle.leccion.error"));
			Log.write("<LeccionMecanoBean/>"+e.getMessage());
		} finally {
				dataservice.close();
			// cerramos la conexion en cualquier caso.
		}

			return result;
	}

	
	/**
	* valida
	* @return ActionErrors
	*/
	public ActionErrors update () {

		//Instancia un objeto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		DataService dataservice = null;
		
		try	{
			// Conectamos con la BBDD
			dataservice = new DataService("DataSourceMecano");
			
			// Sentencia de modificacion
			if ((theActionErrors = dataservice.setData("UpdateLeccion",new Object[]{nombre,descripcion,textoleccion,maxerrores,codleccion})) != null) {
				dataservice.close();
				return theActionErrors;
			}		
								
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("update.leccion.error"));
			Log.write("<LeccionMecanoBean/>"+e.getMessage());
		} finally {
				dataservice.close();
			// cerramos la conexion en cualquier caso.
		}

			return theActionErrors;
	}
		
}	// Fin class
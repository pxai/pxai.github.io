/**
 * XForm.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */

package pxai.struts.mecano.form;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import java.sql.Date;

/**
 * ActualizacionLeccionMecanoForm
 * 
 * Implementa el formulario que se muestra en html 
 * @author   <a href="pello.altadill@terra.com">Pello Xabier Altadill Izura</a>
 * @version 1.0 , date 13/2/02
*/
public final class ActualizacionLeccionMecanoForm extends ActionForm  {


	/**
	* @field Mantenimiento de la accion que estamos procesando (Create or Edit).
	* atributo IMPRESCINDIBLE para STRUS
	*/
    private String action = "Create";
    
    /**
    * @field coddleccion
    */
    private Integer codleccion = null;
    
	/**
	* @field nombre
	*/
    private String nombre = null;
    
	/**
	* @field descripcion
	*/
    private String descripcion = null;
    
	/**
	* @field textoleccion
	*/
    private String textoleccion = null;
    
	/**
	* @field maximoerrores
	*/
    private Integer maxerrores = null;





	/*********************** METODOS DE BEAN **********************************/

	/**
	* Devuelve la accion.
	*
	* @return String la accion
	*/
    public String getAction() {

		return (this.action);
    }


	/**
	* Establece la accion
	*
	* @param action La nueva accion
	*/
    public void setAction(String action) {

        this.action = action;
    }

	public void setNombre(String nombre) {
		this.nombre = nombre.trim(); 
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion.trim(); 
	}

	public void setTextoleccion(String textoleccion) {
		this.textoleccion = textoleccion.trim(); 
	}

	public void setMaxerrores(Integer maxerrores) {
		this.maxerrores = maxerrores; 
	}
	public String getNombre() {
		return (this.nombre); 
	}

	public String getDescripcion() {
		return (this.descripcion); 
	}

	public String getTextoleccion() {
		return (this.textoleccion); 
	}

	public Integer getMaxerrores() {
		return (this.maxerrores); 
	}
	
	public void setCodleccion(Integer codleccion) {
		this.codleccion = codleccion; 
	}
	
	public Integer getCodleccion() {
		return (this.codleccion); 
	}
	/*********************** FIN METODOS DE BEAN *****************************/

	/**
	* Resetea todas las propiedades a sus valores por defecto.
	*
	* @param mapping El mapping utilizado por la instancia.
	* @param request El servlet request que estamos procesando.
	*/
    public void reset(ActionMapping mapping, HttpServletRequest request) {

        this.action = "Create";


    }


	/**
	* Valida las propiedades asignadas desde el HTTP request
	* y devuelve un objeto <code>ActionErrors</code> que encapsula cualquier
	* validaci�n de error que haya sido encontrada. Si no se han encontrado errores
	* , devuelve <code>null</code> o un objeto <code>ActionErrors</code> sin mensajes
	* de error grabados.
	*
	* @param mapping El mapping utilizado por la instancia.
	* @param request El servlet request que estamos procesando.
	*/
	public ActionErrors validate(ActionMapping mapping,
	                       HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();

		return errors;

	}


	public String toString() {
		String ret = null;
		ret = "action = " + action + "\n";
		ret += "codleccion = " + codleccion + "\n";
		ret += "nombre = " + nombre + "\n";
		ret += "descripcion = " + descripcion + "\n";
		ret += "textoleccion = " + textoleccion + "\n";
		ret += "maxerrores = " + maxerrores + "\n";
		return ret;
	}

	




}//class
/**
 * XForm.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */

package pxai.struts.mecano.form;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import java.sql.Date;


/**
 * BusquedaAlumnoMecanoForm
 * 
 * Implementa el formulario que se muestra en html 
 * @author   <a href="pello.altadill@terra.com">Pello Xabier Altadill Izura</a>
 * @version 1.0 , date 13/2/02
*/
public final class BusquedaAlumnoMecanoForm extends ActionForm  {

	/**
	* @field Mantenimiento de la accion que estamos procesando (Create or Edit).
	* atributo IMPRESCINDIBLE para STRUS
	*/
    private String action = "Create";

	/**
	* @field login
	*/
    private String login = null;
    

	/**
	* @field login
	*/
    private String nombre = null;
    
   	/**
	* @field fechaingreso
	*/
    private String fechaingreso = null;
   
    /**
	* @field leccion
	*/
    private Integer leccion = null;
     
   	/**
	* @field velocidadmedia
	*/
    private Float velocidadmedia = null;
    
   	/**
	* @field mediaerrores
	*/
    private Float mediaerrores = null;





	/**
	* Resetea todas las propiedades a sus valores por defecto.
	*
	* @param mapping El mapping utilizado por la instancia.
	* @param request El servlet request que estamos procesando.
	*/
    public void reset(ActionMapping mapping, HttpServletRequest request) {

        this.action = "Create";


    }


	/**
	* Valida las propiedades asignadas desde el HTTP request
	* y devuelve un objeto <code>ActionErrors</code> que encapsula cualquier
	* validaci�n de error que haya sido encontrada. Si no se han encontrado errores
	* , devuelve <code>null</code> o un objeto <code>ActionErrors</code> sin mensajes
	* de error grabados.
	*
	* @param mapping El mapping utilizado por la instancia.
	* @param request El servlet request que estamos procesando.
	*/
	public ActionErrors validate(ActionMapping mapping,
	                       HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();

		return errors;

	}

	/*********************** METODOS DE BEAN **********************************/
	/**
	* Devuelve la accion.
	*
	* @return String la accion
	*/
    public String getAction() {

		return (this.action);
    }


	/**
	* Establece la accion
	*
	* @param action La nueva accion
	*/
    public void setAction(String action) {

        this.action = action;
    }	

	public void setLogin(String login) {
		this.login = (login.trim().compareTo("") == 0)?"":login.trim(); 
	}


	public void setNombre(String nombre) {
		this.nombre = (nombre.trim().compareTo("") == 0)?"":nombre.trim(); 
	}
	public String getLogin() {
		return (this.login); 
	}


	public String getNombre() {
		return (this.nombre); 
	}

	
	public void setFechaingreso(String fechaingreso) {
		this.fechaingreso = (fechaingreso.trim().compareTo("") == 0)?"":fechaingreso.trim();
	}

	public void setVelocidadmedia(Float velocidadmedia) {
		this.velocidadmedia = velocidadmedia; 
	}

	public void setMediaerrores(Float mediaerrores) {
		this.mediaerrores = mediaerrores; 
	}
	public String getFechaingreso() {
		return (this.fechaingreso); 
	}

	public Float getVelocidadmedia() {
		return (this.velocidadmedia); 
	}

	public Float getMediaerrores() {
		return (this.mediaerrores); 
	}
	
	public void setLeccion(Integer leccion) {
		this.leccion = leccion; 
	}
	
	public Integer getLeccion() {
		return (this.leccion); 
	}
	

	public String toString() {
		String ret = null;
		ret = "action = " + action + "\n";
		ret += "login = " + login + "\n";
		ret += "nombre = " + nombre + "\n";
		ret += "fechaingreso = " + fechaingreso + "\n";
		ret += "leccion = " + leccion + "\n";
		ret += "velocidadmedia = " + velocidadmedia + "\n";
		ret += "mediaerrores = " + mediaerrores + "\n";
		return ret;
	}


}//class
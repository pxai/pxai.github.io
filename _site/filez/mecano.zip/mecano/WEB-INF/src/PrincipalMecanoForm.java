/**
 * PrincipalMecanoForm.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */

package pxai.struts.mecano.form;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import java.sql.Date;

/**
 * PrincipalMecanoForm
 * 
 * Implementa el formulario que se muestra en html 
 * @author   <a href="pello.altadill@terra.com">Pello Xabier Altadill Izura</a>
 * @version 1.0 , date 13/2/02
*/
public final class PrincipalMecanoForm extends ActionForm  {


	/**
	* @field Mantenimiento de la accion que estamos procesando (Create or Edit).
	* atributo IMPRESCINDIBLE para STRUS
	*/
    private String action = "Create";

	/**
	* @field login
	*/
    private String login = null;
    
	/**
	* @field password
	*/
    private String password = null;

	/**
	* Devuelve la accion.
	*
	* @return String la accion
	*/
    public String getAction() {

		return (this.action);
    }


	/**
	* Establece la accion
	*
	* @param action La nueva accion
	*/
    public void setAction(String action) {

        this.action = action;
    }


	/**
	* Resetea todas las propiedades a sus valores por defecto.
	*
	* @param mapping El mapping utilizado por la instancia.
	* @param request El servlet request que estamos procesando.
	*/
    public void reset(ActionMapping mapping, HttpServletRequest request) {

        this.action = "Create";


    }


	/**
	* Valida las propiedades asignadas desde el HTTP request
	* y devuelve un objeto <code>ActionErrors</code> que encapsula cualquier
	* validaci�n de error que haya sido encontrada. Si no se han encontrado errores
	* , devuelve <code>null</code> o un objeto <code>ActionErrors</code> sin mensajes
	* de error grabados.
	*
	* @param mapping El mapping utilizado por la instancia.
	* @param request El servlet request que estamos procesando.
	*/
	public ActionErrors validate(ActionMapping mapping,
	                       HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();

		return errors;

	}

	
	public void setLogin(String login) {
		this.login = login; 
	}

	public void setPassword(String password) {
		this.password = password; 
	}


	public String getLogin() {
		return (this.login); 
	}

	public String getPassword() {
		return (this.password); 
	}



	public String toString() {
		String ret = null;
		ret = "action = " + action + "\n";
		ret += "login = " + login + "\n";
		ret += "password = " + password + "\n";
		return ret;
	}

}//class
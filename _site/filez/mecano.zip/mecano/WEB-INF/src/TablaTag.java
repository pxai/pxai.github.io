/**
 * SaveActualizacionLeccionMecanoAction.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */
 
 
package pxai.taglib;


import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;
import org.apache.struts.action.ActionErrors;

import pxai.comun.Log;
import pxai.comun.Data;
import pxai.comun.DataService;



/**
 * TablaTag.java
 *
 * 
 * Tag que realiza una consulta y crea una tabla con el resultado
 *
 * @author Pello Xabier Altadill Izura
 * @version v1.2 Fecha: 2002/01/25 02:10:00 
 */

public class TablaTag extends TagSupport {

 


	/**
	* @field datasource
	* Orgien de datos
	*/    
    private String datasource = null;
    
	/**
	* @field queryname
	* Nombre de la query que se encuentra en el fichero de SQL
	*/    
    private String queryname = null;
    
	/**
	* @field fields
	* Campos a mostrar, en orden, separados por ,
	*/    
    private String fields = null;

	/**
	* @field css
	* Estilo a aplicar a la tabla
	*/    
    private String css = null;
   

	/**
	* @field limite
	* Numero de filas a mostrar
	*/    
    private String limite = null;
    
	/*************** METODOS JAVABEAN ************************/
	
	public void setDatasource(String datasource) {
		this.datasource = datasource; 
	}

	public void setQueryname(String queryname) {
		this.queryname = queryname; 
	}

	public void setFields(String fields) {
		this.fields = fields; 
	}

	public void setCss(String css) {
		this.css = css; 
	}
	public String getDatasource() {
		return (this.datasource); 
	}

	public String getQueryname() {
		return (this.queryname); 
	}

	public String getFields() {
		return (this.fields); 
	}

	public String getCss() {
		return (this.css); 
	}
	
	public void setLimite(String limite) {
		this.limite = limite; 
	}
	public String getLimite() {
		return (this.limite); 
	}

	
	/*************** FIN METODOS JAVABEAN ************************/


	
    /**
     * Escribe el principio de la etiqueta
     * @return int
     * @exception JspException  si ocurre una excepcion JSP
     */
    public int doStartTag() throws JspException {
		StringBuffer tabla = new StringBuffer("");

		DataService dataservice = null;
		Data data = new Data();
		ActionErrors errors = null;
		StringTokenizer st = null;
		int limite = 0;
		Vector campos = new Vector();
		
		try {		
			limite = (getLimite() == null)?-1:(new Integer(getLimite()).intValue());
			// Se toma el stream de salida
			JspWriter writer = pageContext.getOut();
				
			// Instancia del acceso a datos
			dataservice = new DataService(getDatasource());
			// consulta
			errors  = dataservice.getData(getQueryname(),null,data);
			
			// si hay errores, terminamos
			if (errors != null) {
				throw new Exception("Se produjo un error en la consulta.");		
			}
			
			// se toman los campos a mostrar
			st = new StringTokenizer(getFields(),",");	
			
			// Pegamos la cabecera
			tabla.append("<TABLE CLASS=\""+getCss()+"\"><TR>");
			while(st.hasMoreElements()) {
				campos.add(st.nextToken());
				tabla.append("<TH>"+campos.lastElement().toString()+"</TH>");
			}
			tabla.append("</TR>");

			// Pegamos los datos
			while(data.hasMoreElements()) {
				tabla.append("<TR>");
			 	for (int i= 0 ;i < campos.size(); i++) {
					tabla.append("<TD>"+data.getValue(campos.elementAt(i).toString())+"</TD>");
				}
				tabla.append("</TR>");
				data.next();
			}
			tabla.append("</TR>");
			
			tabla.append("</TABLE>");		
			
			//et voila, escribimos el resultado	
			writer.print(tabla.toString());

		} catch (IOException ioe) {
			Log.write("<TablaTag/>Error io al comprobar sesion: " + ioe.getMessage());
		}
		 catch (Exception e) {
		 	e.printStackTrace(System.err);
			Log.write("<TablaTag/>Error general, compruebe nombres de campos y su orden: " + e.getMessage());
		} finally {
			dataservice.close();
		}
		// Evalua el body de la
		return (EVAL_BODY_INCLUDE);

	}



    /**
     * Escribe el cierre del TAG
     *
     * @return int
     * @exception JspException si ocurre una excepcion JSP
     */
    public int doEndTag() throws JspException {

		// Imprime el elemento de cierre.		
		JspWriter writer = pageContext.getOut();
		
		
			try {
			    writer.print("");
			} catch (IOException e) {
			    throw new JspException(e.toString());
			}

		return (EVAL_PAGE);

    }


    /**
     * Release cualquier recurso adquirido
     */
    public void release() {
        super.release();
    }


	public String toString() {
		String ret = null;
		ret = "datasource = " + datasource + "\n";
		ret += "queryname = " + queryname + "\n";
		ret += "fields = " + fields + "\n";
		ret += "css = " + css + "\n";
		ret += "limite = " + limite + "\n";
		return ret;
	}


}

/**
 * Log.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */
 
package pxai.comun;

import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.StringTokenizer;


/**
 * Log de la aplicacion
 * Guarda cada mensaje en formato XML
 * para facilitar su posterior analisis automatizado
 * @author   <a href="pello.altadill@terra.com">Pello Xabier Altadill Izura</a>
 * @version 1.0 , date 13/2/02
 */
public class Log {

	private static String logfile = "mecano.log.xml";


	/**
	* write
	* Metodo que escribe el log en el fichero que se haya especificado
	* en el properties
	* @param String msg el mensaje de log
	*/
  public static boolean write (String msg) {
		
  
      PrintWriter pw = null;
      String message =  "<Log date=\"" + new Date().toString() +"\">"+msg+"</Log>";
	 	
      try {
      	// Escribimos (append) en el fichero log
        pw = new PrintWriter(new FileOutputStream(logfile, true));
        pw.println(message);
        pw.close();
      } catch (IOException ioe) {
        System.err.println("Error al escrbir en log: "+ioe.getMessage());
        return false;
      }
	return true;
    

  }


  
}//end class
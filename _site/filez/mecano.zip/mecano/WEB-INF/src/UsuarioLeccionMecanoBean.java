/**
 * UsuarioLeccionMecanoBean.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */

package pxai.struts.mecano.bean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletException;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import pxai.struts.mecano.form.MecanoMecanoForm;
import pxai.comun.Data;
import pxai.comun.DataService;
import pxai.comun.Log;



/**
 * UsuarioLeccionMecanoBean.java
 *
 * Entidad UsuarioLeccion
 *
 * @author   <a href="pello.altadill@terra.com">Pello Xabier Altadill Izura</a>
 * @version 1.0 , date 13/2/02
*/
public class UsuarioLeccionMecanoBean  {

	/**
	* @field login : login de usuario
	*/
	private String login = null;
		
	/**
	* @field codleccion : codleccion de usuario
	*/
	private Integer codleccion = null;
	
	/**
	* @field flagaprobado : flagaprobado de leccion
	*/
	private Boolean flagaprobado = null;
	
	/**
	* @field errores : errores de leccion
	*/
	private Integer errores = null;	
	
	/**
	* @field velocidad : velocidad de usuario
	*/
	private Float velocidad = null;	
	
	/**
	* @field mediaerrores : mediaerrores de usuario
	*/
	private Float mediaerrores = null;
	
	/**
	* constructor
	*/
	public UsuarioLeccionMecanoBean() {
	}	
		
	/**
	* constructor
	*/
	public UsuarioLeccionMecanoBean(String login, Integer codleccion) {
		this.login = login;
		this.codleccion = codleccion;
	}	


	/**
	* constructor
	*/
	public UsuarioLeccionMecanoBean(String login, Integer codleccion, 
				Boolean flagaprobado, Integer errores, Float velocidad) {
		this.login = login;
		this.codleccion = codleccion;
		this.flagaprobado = flagaprobado;
		this.errores = errores;
		this.velocidad = velocidad;
	}
	
	/****************** Metodos Bean *********************/	
	public void setLogin(String login) {
		this.login = login; 
	}

	public void setCodleccion(Integer codleccion) {
		this.codleccion = codleccion; 
	}

	public void setFlagaprobado(Boolean flagaprobado) {
		this.flagaprobado = flagaprobado; 
	}

	public void setErrores(Integer errores) {
		this.errores = errores; 
	}

	public void setVelocidad(Float velocidad) {
		this.velocidad = velocidad; 
	}
	public String getLogin() {
		return (this.login); 
	}

	public Integer getCodleccion() {
		return (this.codleccion); 
	}

	public Boolean getFlagaprobado() {
		return (this.flagaprobado); 
	}

	public Integer getErrores() {
		return (this.errores); 
	}

	public Float getVelocidad() {
		return (this.velocidad); 
	}
	
	public void setMediaerrores(Float mediaerrores) {
		this.mediaerrores = mediaerrores; 
	}
	public Float getMediaerrores() {
		return (this.mediaerrores); 
	}
	
	/****************** Fin Metodos Bean *********************/


	public String toString() {
		String ret = null;
		ret = "login = " + login + "\n";
		ret += "codleccion = " + codleccion + "\n";
		ret += "flagaprobado = " + flagaprobado + "\n";
		ret += "errores = " + errores + "\n";
		ret += "velocidad = " + velocidad + "\n";
		ret += "mediaerrores = " + mediaerrores + "\n";
		return ret;
	}
		

	/**
	* insert
	* @return ActionErrors
	*/
	public ActionErrors insert () {

		//Instancia un objrcto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		DataService dataservice = null;
		Data data = null;
		
		
		try	{
			// Conectamos con la BBDD
			dataservice = new DataService("DataSourceMecano");

			// Adelante con el alta
			theActionErrors = dataservice.setData("InsertUsuarioLeccion",new Object[]{login,codleccion,flagaprobado,errores,velocidad});
			
			if (theActionErrors != null) {
				theActionErrors = new ActionErrors();
				theActionErrors.add("bean",new ActionError("alta.usuarioleccion.error"));
				return theActionErrors;					
			}
			
			// Una vez insertados los ultimos datos, calculamos!
			theActionErrors = this.avg();

			if (theActionErrors != null) {
				theActionErrors = new ActionErrors();
				theActionErrors.add("bean",new ActionError("avg.usuarioleccion.error"));
				return theActionErrors;					
			}
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("alta.usuarioleccion.error"));
			Log.write("<UsuarioLeccionMecanoBean/>"+e.getMessage());
		} finally {
			// cerramos la conexion en cualquier caso.
				dataservice.close();
		}

			return theActionErrors;
	}
	
	/**
	* avg
	* calcula medias de un usuario, recorriendo su historial
	* @return ActionErrors
	*/
	private ActionErrors avg () {

		//Instancia un objrcto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		DataService dataservice = null;
		Data data = null;
		Float velocidadmedia = new Float(0.0);
		Float mediaerrores = new Float(0.0);
		
		try	{
			// Conectamos con la BBDD
			dataservice = new DataService("DataSourceMecano");

			data = new Data();
			
			// Adelante con el alta
			theActionErrors = dataservice.getData("AvgUsuarioLeccion",new Object[]{login,codleccion},data);
			
			velocidadmedia = (data.getValue("velocidadmedia") == null)?(velocidadmedia):(new Float(data.getValue("velocidadmedia").toString()));
			mediaerrores = (data.getValue("mediaerrores") == null)?(velocidadmedia):(new Float(data.getValue("mediaerrores").toString()));

			this.setVelocidad(velocidadmedia);
			this.setMediaerrores(mediaerrores);
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("avg.usuarioleccion.error"));
			Log.write("<UsuarioLeccionMecanoBean/>"+e.getMessage());
		} finally {
			// cerramos la conexion en cualquier caso.
				dataservice.close();
		}

			return theActionErrors;
	}

	



}	// Fin class
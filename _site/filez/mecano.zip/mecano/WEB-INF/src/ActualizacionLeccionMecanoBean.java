/**
 * XBean.java
 *
 * Aplicacion Mecano. Ense�anza de mecanografia por lecciones
 * para entorno web, multiusuario.
 * Aplicacion web desarrollada segun el paradigam MVC
 * con Struts (http://jakarta.apache.org/struts)
 *
 * Libre distribucion  (ver licencia: license.txt)
 *
 * Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
 * Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
 *
 */

package pxai.struts.mecano.bean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletException;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import pxai.struts.mecano.form.ActualizacionLeccionMecanoForm;



/**
 * ActualizacionLeccionMecanoBean
 * Implementa la l�gica de negocio para el proceso X
 * @author   <a href="pello.altadill@terra.com">Pello Xabier Altadill Izura</a>
 * @version 1.0 , date 13/2/02
*/
public class ActualizacionLeccionMecanoBean {

	
	/**
	* @field Constante que identifica el estado libre en la tabla de estados
	*/
	private static final Integer _ESTADO = new Integer(1);


	
	/**
	* logicaDeNegocio
	*
	* @param formulario con los datos a guardar
	*
	* @return null si no hay errores o ActionErrors con los 
	* errores capturados en caso de error.
	*/
	public synchronized ActionErrors logicaDeNegocior (ActionForm theActionForm) {
					
		//Instancia un objrcto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;

		try	{
	

				return theActionErrors;			
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("bean",new ActionError("carga.error"));
			return theActionErrors;
		}
		
	}	//Logica de Negocio
	
	
		
}	// Fin class
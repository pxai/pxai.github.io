
import java.util.Vector;


public class Proba {
	
	private String nombre = null;
	private Integer valor = null;
	private Float flotante = null;

	public Proba () {
	}


	public static void main (String args[])	 {
		Proba p = new Proba();	
		Vector v = new Vector();
		Object o = null;
		int i = 0;

		System.out.println("Vamos alla!");
		
		o = new Proba();
		((Proba)o).setNombre("pepe");
		((Proba)o).setValor(new Integer(23));
		((Proba)o).setFlotante(new Float(34.6));

		v.addElement(o);

		p.setNombre("pepe2");
		p.setValor(new Integer(232));
		p.setFlotante(new Float(34.62));

		for (i = 0;i<v.size();i++)
			System.out.println(i+"> "+v.elementAt(i));
		
		v.addElement(p);
		
			
		for (i = 0;i<v.size();i++)
			System.out.println(i+"> "+v.elementAt(i));

		o = new Proba();

		((Proba)o).setNombre("pepe_cambio?");
		((Proba)o).setValor(new Integer(24));
		((Proba)o).setFlotante(new Float(34.8));
		
		for (i = 0;i<v.size();i++)
			System.out.println(i+"> "+v.elementAt(i));
		
		
		System.out.println("Vamos alla!");
	}	

	
	public void setNombre(String nombre) {
		this.nombre = nombre; 
	}

	public void setValor(Integer valor) {
		this.valor = valor; 
	}

	public void setFlotante(Float flotante) {
		this.flotante = flotante; 
	}
	public String getNombre() {
		return (this.nombre); 
	}

	public Integer getValor() {
		return (this.valor); 
	}

	public Float getFlotante() {
		return (this.flotante); 
	}

	public String toString() {
		String ret = null;
		ret = "nombre = " + nombre + "\n";
		ret += "valor = " + valor + "\n";
		ret += "flotante = " + flotante + "\n";
		return ret;
	}
}
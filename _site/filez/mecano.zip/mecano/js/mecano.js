/**
 * FICHERO Mecano.js
 * CREACION 04/04/2002
 * AUTOR Pello Xabier Altadill Izura
 * Descripcion fichero de funciones Javascript para la aplicacion
 *			  de mecano.
 * Version 1.0
*/


/**
* variables
*/
var texto = "";
var arrayleccion = 0;
var tiempo_inicio = 0;
var tiempo_final = 0;
var tiempo_total = 0;
var tiempo_total_sec = 0;
var errores = 0;
var indice = 0;
var finalizado = 0;
mensajesError = ["CAGADA!!","IDIOTA!!","MAL!!!","NOOOO!!","INUTIL!!","IMBECIL!!","GILIPOLLAS!","MANAZAS!!","ANORMAL!!!","MANGARRAN!!","JULAY!"];

/**
* inicio
* Funcion que se ejecuta al cargar la pagina
*/
function inicio(textoleccion) {
	arrayleccion = textoleccion;
	document.forms[0].ejercicio.value = cargaTextoleccion(textoraw);
	
	// aviso antes de iniciar
	alert("Al pulsar el boton aceptar, se pondra en marcha el cronometro.");
	// inicio del cronometro
	startTimer();
	// Definimos el handler para keyDown
	document.onkeydown = keyDownCaja;

}

/**
* startTimer ()
* inicio del cronometro
*/
function startTimer () {
	tiempo_inicio = new Date();
}

/**
* finishTimer ()
* parada del cronometro
*/
function finishTimer () {
	tiempo_final = new Date();
	// calculamos el tiempo final
	tiempo_total = new Date(tiempo_final - tiempo_inicio);
	tiempo_total_sec = tiempo_total.getSeconds();
}

/**
* cargaTextoleccion
* del array de datos
*/
function cargaTextoleccion (textoseguido) {

	re = /#/g;
	var texto_nuevo = textoseguido.replace(re,"\n");
	return texto_nuevo;	
}

/**
* keyDown
* 
*/
function keyDownCaja() {
	var ieKey = event.keyCode;
	var caracter = String.fromCharCode(ieKey).toLowerCase();
	texto_de_caja = document.forms[0].ejercicio.value;
	
	// Comprobar si ha terminado la leccion
	if (arrayleccion.length == (indice+1)) {
		document.forms[0].ejercicio.value = "";
		return terminarLeccion(((errores > maxerrores)?0:1));
	}
	
	// Comprobar si es el mismo caracter	
	if (
		 caracter == arrayleccion[indice] ||
		 ((ieKey == 192) && (arrayleccion[indice] == '�')) ||   // caso de �
		 ((ieKey == 13) && (arrayleccion[indice] == '#')) 		// caso de enter
		) 
		{
		// Caso de tocar 'enter' hay que eliminar dos caracteres
		quitar = (ieKey == 13)?2:1;
		//pulsado correcto seguir adelante.
		document.forms[0].ejercicio.value = texto_de_caja.substring(quitar,texto_de_caja.length);
		document.forms[0].guia_mensajes.value  = "";
		indice++;
		document.forms[0].guia_right.value  = arrayleccion[indice];
		document.forms[0].guia_left.value  = arrayleccion[indice];
	} else {
		document.forms[0].guia_mensajes.value  = mensajeError();
		incrementaError();
	}
	// DEBUG
	//alert("Ahi va: " + caracter + " " +  arrayleccion[6] +"  ->" +ieKey +" ->"+String.fromCharCode(ieKey).toLowerCase() + event.which);
}

/**
* mensajeError
* devuelve un mensaje de error aleatorio
*/
function mensajeError () {
	var ind = Math.round((Math.random()*100)) % mensajesError.length;
	return mensajesError[ind];
}

/**
* incrementaError
* incrementa el campo de errores
*/
function incrementaError() {
	errores++;
	document.forms[0].guia_errores.value = errores;
}

/**
* terminarLeccion
* realiza todas las operacion de fin de leccion,
* calculos de pulsaciones, redireccion etc...
*/
function terminarLeccion (flag) {
	// Paramos el cronometro!!
	if (!finalizado) {
		finishTimer();
		finalizado = 1;
	}
	
	var mensaje = "Mecano v1.0 \n-----------------------------\nResultado del ejercicio: \n\n";	

	if (flag) { // si hay exito.
	 mensaje += "APROBADO\n\n";
	 mensaje += "Caracteres:\t" +arrayleccion.length+" \n";
	 mensaje += "Errores:\t\t" +errores+" \n";
	 mensaje += "Segundos:\t" +tiempo_total.getSeconds()+" \n";
	 mensaje += "Pulsaciones/s:\t" +(arrayleccion.length/tiempo_total.getSeconds())+" \n";
	 mensaje += "Pulsaciones/m:\t" +((arrayleccion.length/tiempo_total.getSeconds())*60)+" \n";

	 document.forms[0].flagaprobado.value = true; 
	 document.forms[0].errores.value = errores; 
	 document.forms[0].velocidad.value = ((arrayleccion.length/tiempo_total.getSeconds())*60); 
	 
	} else { // si se ha suspendido

	 mensaje += "Eres un mierda!";
	 document.forms[0].flagaprobado.value = false; 
	 document.forms[0].errores.value = errores; 
	 document.forms[0].velocidad.value = 0;
	}
	
	alert(mensaje);
	document.forms[0].submit();
	

}

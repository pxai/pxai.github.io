##
#
# mecano.sql
# Fichero donde se almacenan todas las sentencias SQL de la aplicacion
# De esta manera, se pueden meter cambios o corregir errores SQL en tiempo
# de ejecucion o sin necesidad de reiniciar el servidor de aplicaciones
##
# Aplicacion Mecano. Ense�anza de mecanografia por lecciones
# para entorno web, multiusuario.
# Aplicacion web desarrollada segun el paradigam MVC
# con Struts (http://jakarta.apache.org/struts)
#
# Libre distribucion  (ver licencia: license.txt)
#
# Autor: Pello Xabier Altadill Izura pello.altadill@terra.com
# Actualizaciones, documentos, etc: http://ciberia.ya.com/pxai/ma.html
#
##

# Alta de nuevo usuario
InsertUsuario=INSERT INTO TBL_USUARIO  (login,password,nombre,fechaingreso,leccion,velocidadmedia,mediaerrores) VALUES (?,?,?,?,?,?,?)

# Alta de nueva leccion
InsertLeccion=INSERT INTO TBL_LECCION (codleccion,nombre,descripcion,textoleccion,maxerrores) VALUES (?,?,?,?,?)

# Nueva entrada en USUARIO LECCION
InsertUsuarioLeccion=INSERT INTO TBL_USUARIO_LECCION  VALUES (?,?,?,?,?)

# Consulta de un usuario
SelectUsuario=SELECT * FROM TBL_USUARIO WHERE login = ?

# Consulta si exite un usuario usuario
SelectUsuarioCount=SELECT COUNT(login) AS total FROM TBL_USUARIO WHERE login = ?

# Consulta la clasificacion de usuarios en cuanto a velocidad_media
SelectUsuarioVelocidad=SELECT * FROM TBL_USUARIO ORDER BY velocidadmedia DESC

# Consulta la clasificacion de usuarios en cuanto a errores
SelectUsuarioErrores=SELECT * FROM TBL_USUARIO ORDER BY mediaerrores ASC

# Consulta de una leccion
SelectLeccion=SELECT * FROM TBL_LECCION WHERE codleccion = ?

# Consulta de la ultima leccion insertada
SelectLastLeccion=SELECT max(codleccion) as maxleccion FROM TBL_LECCION

# Consulta todas las lecciones de un usuario
SelectUsuarioLeccion=SELECT * FROM TBL_USUARIO_LECCION WHERE  login = ? order by codleccion

# Consulta todas las lecciones de un usuario
AvgUsuarioLeccion=SELECT AVG(errores) as mediaerrores, AVG(velocidad) as velocidadmedia FROM TBL_USUARIO_LECCION WHERE  login = ?

# Busqueda de usuarios y sus campos opcionales de busqueda
SelectUsuarioBusqueda=SELECT * FROM TBL_USUARIO WHERE;ORDER BY LOGIN
CamposUsuarioBusqueda=login,nombre,fechaingreso,leccion,velocidadmedia,mediaerrores

# Busqueda de lecciones y sus campos opcionales de busqueda
SelectLeccionBusqueda=SELECT * FROM TBL_LECCION WHERE;ORDER BY CODLECCION
CamposLeccionBusqueda=codleccion,nombre,descripcion,textoleccion,maxerrores

# Modificacion de la tabla usuarios
UpdateUsuario=UPDATE TBL_USUARIO SET password = ? ,nombre = ? ,leccion = ? ,mediaerrores = ? ,velocidadmedia = ? WHERE login = ?

# Modificacion de la tabla usuarios para medias
UpdateUsuarioAvg=UPDATE TBL_USUARIO SET leccion= ?,mediaerrores = ? ,velocidadmedia = ? WHERE login = ?


# Modificacion de la tabla lecciones
UpdateLeccion=UPDATE TBL_LECCION SET nombre = ? , descripcion = ? ,textoleccion = ? ,maxerrores = ?  WHERE codleccion = ?

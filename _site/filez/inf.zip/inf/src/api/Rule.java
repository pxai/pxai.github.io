package com.javamercenary.ai.inferenczy.api;

/**
 * T�tulo:       API for Inference Engine
 * Descripcion:
 * Copyright:    Copyright (c) 2001
 * Empresa:
 * @author P. Al.
 * @version 1.0
 */
 import java.io.Serializable;

 
 public abstract class Rule implements Serializable{
 	
 	/**
 	* RULE Attributes
 	*/
 	
 	/**
 	* constructor
 	*/
 	public Rule () {
 	}
}//end kernel
/**
*
* SFPC at Home
* Search For Potential Customers
* SPFC performs searches at google of given subjects
* and retrieves emails from webpages.
*
* (C) 2003 - Pello Xabier Altadill Izura - pello@pello.info
* Check for updates at http://pello.info
*
*** (See LICENSE.txt for details) 
*
* Database.java Saves customer data (emails)
*/

/**
* package declaration
*/
package info.pello.SFPC;

/**
* imports
*/
import java.util.Date;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;

 /**
 * Class deklarazioa
 * @author Pello Altadill
 * @version 1.0 19/01/2003
 */
public class Database {

		private static PrintWriter outfile = null;

	/**
	* atributuak
	*/
	private static SFPCProperties PROPERTIES = SFPCProperties.getSFPCProperties();

	/**
	* Constructor
	*/
	public Database (){
	}

	/**
	* saveData
	* @param String email
	* Salva los datos de cliente
	*/
	public void saveData (String email) {
		saveData(email,"","");
	}
	
	/**
	* saveData
	* @param String email
	* @param String link
	* @param String description
	* Salva los datos de cliente
	*/
	public void saveData (String email,String link,String description) {
	
		try {
			// Open stream with append and auto-flush (true flags)
			outfile = new PrintWriter(new FileWriter (PROPERTIES.getProperty("output.file"),true),true);
			outfile.println(email + ";" + link + ";" + description);
			outfile.close();
		} catch (IOException ioe) {
			PROPERTIES.log("IO Exception: " +ioe.getMessage());		
   	} catch (Exception e) {
			PROPERTIES.log("General Exception: " + e.getMessage());		
   	}

	}

}//end class 

/**
*
* SFPC at Home
* Search For Potential Customers
* SPFC performs searches at google of given subjects
* and retrieves emails from webpages.
*
* (C) 2003 - Pello Xabier Altadill Izura - pello@pello.info
* Check for updates at http://pello.info
*
*** (See LICENSE.txt for details) 
*
* CustomerPageParser.java Parse customer Page
*/

/**
* package declaration
*/
package info.pello.SFPC.parsers;

/**
* imports
*/
import java.util.Date;
import javax.swing.text.html.HTMLEditorKit.*;
import javax.swing.text.html.parser.ParserDelegator;
import javax.swing.text.*;
import javax.swing.text.html.*;
import java.util.*;
import java.io.StringReader;

 /**
 * Class deklarazioa
 * @author Pello Altadill
 * @version 1.0 19/01/2003
 */
public class CustomerPageParser  extends SFPCParser {

	/**
	* atributuak
	*/
	private String result = "";
	private int link_cont = 0;
   	

	/**
	* Constructor
	*/
	public CustomerPageParser (){
	}

	/**
	* parseIt
	* parses HTML page
	* @param String text , html content
	* @return String result (vector, xml or whatever)
	*/
	public String parseIt (String text){
	    StringReader reader = null;
	    CustomerPageParser this_parser = new CustomerPageParser();

	    // Let's parse text
	    try {
	    	reader = new StringReader(text);
	    	this_parser.link_cont = Integer.parseInt(PROPERTIES.getProperty("max_results"));
    		new ParserDelegator().parse(reader, this_parser, true);

    		// Cut last character, if any
    		//if (this_parser.length() > 0) 
		    // this_parser.result = this_parser.result.substring(0,this_parser.result.length()-1);

    	} catch (Exception e) {
	    	//log(text);
	    	log("Error parsing text : " +e.getMessage());
	    } finally {
	    	return this_parser.result;
	    }
    	
	}

	/**
	* handleStartTag
	* Handles HTML start tags
	*/
  public void handleStartTag(HTML.Tag tag,MutableAttributeSet attrib,int pos)
    { 

	    // Check links for "mailto" tag
	   if (tag.equals(HTML.Tag.A)) {
      	captureA(attrib);
	   }

    }


	/**
	* handleText
	* Activates when simple text is parsed
	*/
  public void handleText(char [] text,int pos)
    {
	   String word = new String(text);
	   if (word.indexOf("@") >0) {
		   result += word + ",";
		  }
    }

    
	/**
	* handleSimpleTag
	* It hols html simple tags, tags like <br>, <img >, with no </a>-like
	* ending tags
	*/
  public void handleSimpleTag(HTML.Tag tag,MutableAttributeSet attrib,int pos)
    {
    }

    
	/**
	* handleEndTag
	* It holds ending tags like </td>, </a>
	*/
  public void handleEndTag(HTML.Tag tag,int pos)
    {
    }


   /**
    * captureA
    * It captures link properties, and looks for "mailto:"
    */
  public void captureA (MutableAttributeSet attrib)
  {
	   	if (attrib.getAttribute(HTML.Attribute.HREF) == null ) {
		   	return;
		  }
	  
	  String href = (String)attrib.getAttribute(HTML.Attribute.HREF); 


   		if (href.toLowerCase().startsWith("mailto:")) {
					result +=  href.substring(7,href.length()) + ",";		   				
		}
  }

}//end class 

/**
*
* SFPC at Home
* Search For Potential Customers
* SPFC performs searches at google of given subjects
* and retrieves emails from webpages.
*
* (C) 2003 - Pello Xabier Altadill Izura - pello@pello.info
* Check for updates at http://pello.info
*
*** (See LICENSE.txt for details) 
*
* ResultPageParser.java Parse result Page
*/

/**
* package declaration
*/
package info.pello.SFPC.parsers;

/**
* imports
*/

import java.util.Date;
import javax.swing.text.html.HTMLEditorKit.*;
import javax.swing.text.html.parser.ParserDelegator;
import javax.swing.text.*;
import javax.swing.text.html.*;
import java.util.*;
import java.io.StringReader;
import java.io.Reader;


 /**
 * Class deklarazioa
 * @author Pello Altadill
 * @version 1.0 19/01/2003
 */
public class ResultPageParser extends SFPCParser {

	/**
	* atributuak
	*/
	private boolean ready_for_link = false;
	private String result = "";
	private int link_cont = 0;
   	
	/**
	* Constructor
	*/
	public ResultPageParser (){
	}

	/**
	* parseIt
	* parses HTML page
	* @param String text , html content
	* @return String result (vector, xml or whatever)
	*/
	public String parseIt (String text){
	    StringReader reader = null;
	    ResultPageParser this_parser = new ResultPageParser();

	    // Let's parse text
	    try {
	    	reader = new StringReader(text);
	    	this_parser.link_cont = Integer.parseInt(PROPERTIES.getProperty("max_results"));
    		new ParserDelegator().parse(reader, this_parser, true);
		    //log("Finished! Result: " + this_parser.result);
		    // Cut last character
		    this_parser.result = this_parser.result.substring(0,this_parser.result.length()-1);
		    
    	} catch (Exception e) {
	    	//log(text);
	    	log("Error parsing text : " +e.getMessage());
	    } finally {
	    	return this_parser.result;
	    }
    	
	}

	/**
	* handleStartTag
	* Handles HTML start tags
	*/
  public void handleStartTag(HTML.Tag tag,MutableAttributeSet attrib,int pos)
    {
	    // If tag is a <p> be ready
	   if (tag.equals(HTML.Tag.P) && link_cont > 0) {
		    captureP(attrib);
		}
		 if (tag.equals(HTML.Tag.A) && ready_for_link) {
      	captureA(attrib);
	   }
	  
    }


	/**
	* handleText
	* Activates when simple text is parsed
	*/
  public void handleText(char [] text,int pos)
    {
    }

    
	/**
	* handleSimpleTag
	* It hols html simple tags, tags like <br>, <img >, with no </a>-like
	* ending tags
	*/
  public void handleSimpleTag(HTML.Tag tag,MutableAttributeSet attrib,int pos)
    {
    }

    
	/**
	* handleEndTag
	* It holds ending tags like </td>, </a>
	*/
  public void handleEndTag(HTML.Tag tag,int pos)
    {
    }

    /**
    * captureA
    * It captures P paragraph properties
    */
  public void captureP (MutableAttributeSet attrib)
  {
		// If tag is P and has class attribute
		 if (attrib.getAttribute(HTML.Attribute.CLASS) != null) {
		// If class attribute is g
				if (attrib.getAttribute(HTML.Attribute.CLASS).equals("g")) {
					ready_for_link = true;
				}
		 }
 
  }

    /**
    * captureA
    * It captures link properties
    */
  public void captureA (MutableAttributeSet attrib)
  {
			    	// log("Capturing HREF : " + (String)attrib.getAttribute(HTML.Attribute.HREF));
  	 				result += (String)attrib.getAttribute(HTML.Attribute.HREF) + ","; 
					ready_for_link = false;
  	 				link_cont--;
  }

}//end class 

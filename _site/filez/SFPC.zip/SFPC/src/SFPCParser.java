/**
*
* SFPC at Home
* Search For Potential Customers
* SPFC performs searches at google of given subjects
* and retrieves emails from webpages.
*
* (C) 2003 - Pello Xabier Altadill Izura - pello@pello.info
* Check for updates at http://pello.info
*
*** (See LICENSE.txt for details) 
*
* ResultPageParser.java Parse result Page
*/

/**
* package declaration
*/
package info.pello.SFPC.parsers;

/**
* imports
*/
import info.pello.SFPC.SFPCProperties;
import java.util.Date;
import javax.swing.text.html.HTMLEditorKit.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import java.util.*;



 /**
 * Class deklarazioa ABSTRACT
 * @author Pello Altadill
 * @version 1.0 19/01/2003
 */
public abstract class SFPCParser extends ParserCallback {

	/**
	* atributuak
	*/
	protected static SFPCProperties PROPERTIES = SFPCProperties.getSFPCProperties();
	
   	
	/**
	* Constructor
	*/
	public SFPCParser (){
	}

	/**
	* parseIt
	* parses HTML page
	* @param String text , html content
	* @return String result (vector, xml or whatever)
	*/
	public String parseIt (String text){
   	return "";
	}


	/**
	* log
	* @param String message
	*/
	public void log (String message) {
		PROPERTIES.log(message);	
	}

}//end class 

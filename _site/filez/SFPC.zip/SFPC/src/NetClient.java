/**
*
* SFPC at Home
* Search For Potential Customers
* SPFC performs searches at google of given subjects
* and retrieves emails from webpages.
*
* (C) 2003 - Pello Xabier Altadill Izura - pello@pello.info
* Check for updates at http://pello.info
*
*** (See LICENSE.txt for details) 
*
* NetClient.java It makes HTTP GET using java sockets
* needed for some hosts, like www.google.com
*/

/**
* package declaration
*/
package info.pello.SFPC;

/**
* imports
*/
import java.util.Date;
import java.util.StringTokenizer;
import java.io.*;
import java.net.*;

 /**
 * Class deklarazioa
 * @author Pello Altadill
 * @version 1.0 19/01/2003
 */

public class NetClient extends Thread {


	/**
	* atributes
	*/
	private String HOST="www.ibercom.com";
	private String REQUEST = "/";
	private int PORT = 80;
	private String UserAgent = "SFPC- www.pello.info -Dptmnt Of Aritificial Inteligence";
	private String HTTP = "HTTP/1.0";
	private String AcceptLanguage = "es";
	private String Host = "-"; 
	private String Connection = "nokeepalive";
	private int threads = 0;
	private static SFPCProperties PROPERTIES = SFPCProperties.getSFPCProperties();


/**
* NetClient constructor
*/
NetClient (String host, int port) {
	HOST = host;
	PORT = port;
}

/**
* NetClient constructor
*/
NetClient (String host, int port,String request) {
	HOST = host;
	PORT = port;
	REQUEST = request;
}


/**
* NetClient constructor
*/
NetClient (String host, int port,String request, String UserAgent,String HTTP,String AcceptLanguage,String Host, String Connection) {
	HOST = host;
	PORT = port;
	REQUEST = request;
	this.UserAgent = UserAgent;
	this.HTTP = HTTP;
	this.AcceptLanguage = AcceptLanguage;
	this.Host = Host;
	this.Connection = Connection;
}


/**
* run
*/
public void run () {
	
	// Establish request parameters using config file
	UserAgent = PROPERTIES.getProperty("useragent");
	HTTP = PROPERTIES.getProperty("http");
	AcceptLanguage = PROPERTIES.getProperty("acceptlanguage");
	Connection = PROPERTIES.getProperty("connection");

}

/**
* sendRequest
*/
private String sendRequest (String request) {
	//return "GET "+request+" "+HTTP+" Accept: */*\nAccept-Language: "+AcceptLanguage+"\nAccept-Encoding: .class \nUser-Agent: "+UserAgent+"\nHost: "+Host+"\nConnection: "+Connection+"\n";
	return "GET "+request+" "+HTTP+" \nAccept-Language: "+AcceptLanguage+"\nAccept-Encoding: .class \nUser-Agent: "+UserAgent+"\nHost: "+Host+"\nConnection: "+Connection+"\n";
}

/**
* tryConnection
*/
public String tryConnection ()  {
	Socket socket = null;
	PrintWriter out = null, outfile = null;
	BufferedReader in = null;
	String result = "";

try {
	socket = new Socket(HOST, PORT);
	} catch (UnknownHostException e) {
        	PROPERTIES.log("> Don't know this host: "+HOST+ " Exc: "+e.getMessage());
                        return "";
	} catch (IOException e) {
            PROPERTIES.log("> 1.-Can't connect to: "+HOST+ " Exc: "+e.getMessage());
                        return "";
  }
	
	try {

	// PREPARE IN OUT STREAMS
		
	// output Stream
	out = new PrintWriter(socket.getOutputStream(), true);
	
	// input stream
	in = new BufferedReader(new InputStreamReader(
         socket.getInputStream()));
	} catch (IOException e) {
                PROPERTIES.log("> Can't connect to: "+HOST+ " Exc: "+e.getMessage());
                        return "";
    }

		// Send the request!!
    	String userInput = sendRequest(REQUEST);
		out.println(userInput);

	try {

		// Retrieve HTML content
		while ((userInput = in.readLine()) != null) {
			result += userInput;
		}
		
		// Strip server response, get only HTML content
		result = result.substring(result.indexOf("<html>"),result.length());
	} catch (IOException e) {
           PROPERTIES.log("> Error while reading from Socket: "+HOST+" (port: "+PORT+")");
           return "";
     } catch (Exception ex) {
           PROPERTIES.log("General Error with result! :" +ex.getMessage());     
	 }


	try {
                      out.close();
                      in.close();
                      socket.close();
	} catch (IOException e) {
           PROPERTIES.log("Error closing streams :" +e.getMessage());     
                   return "";
    }
                      
    // Finally, we return the result!!
    // System.out.println(result);                
    return result;

}


/**
* main
* Useful for testing...
*/
public static void main(String[] args)  {
		System.out.println("EFPC Bot, awakening.");
		try {
 	if (args.length == 3) {
		NetClient nc = new NetClient(args[0], Integer.parseInt(args[1]), args[2]);
		nc.start();
	} else
		System.out.println("Try with <HOST> <PORT> <REQUEST>");
		} catch (Exception e) {
		 System.err.println("- Try with <HOST> <PORT> - Error: "+e.getMessage());
		}
  }

}
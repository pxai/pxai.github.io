/**
*
* SFPC at Home
* Search For Potential Customers
* SPFC performs searches at google of given subjects
* and retrieves emails from webpages.
*
* (C) 2003 - Pello Xabier Altadill Izura - pello@pello.info
*
* Developed at Dpmt of Artificial Intelligence and Automated Bots
* World Wide Web Ibercom - www.ibercom.com
*
* Check for updates at http://pello.info
*
*** (See LICENSE.txt for details) 
*
* SFPCProperties.java Program properties
*/

/**
* package declaration
*/
package info.pello.SFPC;

/**
* imports
*/
import java.util.Date;
import java.util.ResourceBundle;
import java.util.MissingResourceException;
import java.util.Locale;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;

 /**
 * Class SFPCProperties
 * @author Pello Altadill
 * @version 1.0 19/01/2003
 */
public class SFPCProperties  {

	/**
	* atributuak
	*/
	private String file = "";
	private String PROGRAM = "SFPC";
	private String VERSION = "1.0";
   private ResourceBundle resources;
	private static SFPCProperties PROPERTIES = new SFPCProperties();
	
	/**
	* Constructor
	*/
	public SFPCProperties (){
		super();
		init();
	}
	
	/**
	* init
	* Inicia el cotarro
	*/
	private void init () {
		// First we retrieve resources such as properties, etc..
   	     try {
      	      resources = ResourceBundle.getBundle("config/sfpc", 
                                                 Locale.getDefault());
        	} catch (MissingResourceException mre) {
         	   log("config/SFPC.properties not found. Exit.");
            	System.exit(1);
        	}
	}
	
	/**
	* getSFPCProperties
	* return Singleton class instance
	* @return SFPCProperties
	*/
	public static SFPCProperties getSFPCProperties () {
		return PROPERTIES;
	}
	
	/**
	* getProperty
	* @param String property
	* @returns String
	*
	* Retrives properties
	*/
	public String getProperty (String property) {
		return resources.getString(property);
	}

/************ UTILS ************************/
	/**
	* log
	* @param String message
	*/
	public void log (String message) {
		System.out.println(PROGRAM + "-" + VERSION + "> " + message);		
	}
	
	/**
	* log
	* @param String message
	* @param int flag
	*/
	public void log (String message, int flag) {
		switch (flag) {
			// 0: Log to standar output
			case 0 : log(message+"\n");
			// 1: Log to standar output without newline
			case 1 : log(message);
			// 2: Log to logfile
			case 2 : log_file(message);
			// 3: Log to logfile and standar output
			case 3 : log(message +"\n");log_file(message);
			
		}		
	}

	/**
	* log_file
	* @param String message
	* Logs message in LOGS file
	*/
	public void log_file (String message) {
		PrintWriter outfile = null;
		
		try {
		outfile = new PrintWriter(new FileWriter (getProperty("log_output")));
		outfile.println((new Date()).toString() + "> " + message);
		} catch (IOException ioe) {
			log("IO Exception: " +ioe.getMessage());		
   	} catch (Exception e) {
			log("General Exception: " + e.getMessage());		
   	}
		System.out.println( (new Date()).toString() + "> " + message);		
	}


}//end class 

/**
*
* SFPC at Home
* Search For Potential Customers
* SPFC performs searches at google of given subjects
* and retrieves emails from webpages.
*
* (C) 2003 - Pello Xabier Altadill Izura - pello@pello.info
* Check for updates at http://pello.info
*
*** (See LICENSE.txt for details) 
*
* SFPC.java Main class (starter for SPFC at home)
*/

/**
* package declaration
*/
package info.pello.SFPC;

/**
* imports
*/
import java.util.Date;
import java.util.StringTokenizer;

 /**
 * Class deklarazioa
 * @author Pello Altadill
 * @version 1.0 19/01/2003
 */
public class SFPC {

	/**
	* atributuak
	*/
	private static SFPCProperties PROPERTIES = SFPCProperties.getSFPCProperties();

	/**
	* Constructor
	*/
	public SFPC (){
	}
	
	/**
	* init
	* Inicia el cotarro
	*/
	public static void init() {
		StringTokenizer st = null;
		try {
			PROPERTIES.log("AMOOOOOO que vamo");
			// Load search-terms - Cargamos los terminos de busqueda
			st = new StringTokenizer(PROPERTIES.getProperty("search_terms"),",");
			while (st.hasMoreTokens()) {
				// Init the engine, and Start It!!!
				new Engine(st.nextToken()).start();
			}
			
			PROPERTIES.log("Work FINISHED!!!");
		} catch (Exception e) {
			PROPERTIES.log("General Error at main class. Check properties file: " + e.getMessage());
		}
	}



	/**
	* Main method
	*/
	public static void main (String args[]) {
		try { 
                SFPC.PROPERTIES.log(SFPC.PROPERTIES.getProperty("message"));
                SFPC.PROPERTIES.log("Using search engine: "+SFPC.PROPERTIES.getProperty("search_engine"));
                SFPC.PROPERTIES.log("Search terms: "+SFPC.PROPERTIES.getProperty("search_terms"));
                SFPC.PROPERTIES.log("LOG output: "+SFPC.PROPERTIES.getProperty("log_output"));
                SFPC.PROPERTIES.log("Results output: "+SFPC.PROPERTIES.getProperty("output_type") + " name: " + SFPC.PROPERTIES.getProperty("output.name"));
                SFPC.init();
                
		} catch (Exception e) {
		System.err.println("Exception: " + e.getMessage());  
		} 
	}


}//end class 

/**
*
* SFPC at Home
* Search For Potential Customers
* SPFC performs searches at google of given subjects
* and retrieves emails from webpages.
*
* (C) 2003 - Pello Xabier Altadill Izura - pello@pello.info
* Check for updates at http://pello.info
*
*** (See LICENSE.txt for details) 
*
* Engine.java Performs search and parse operation using threads
*/

/**
* package declaration
*/
package info.pello.SFPC;

/**
* imports
*/
import java.util.Date;
import info.pello.SFPC.parsers.SFPCParser;

 /**
 * Class deklarazioa Engine
 * @author Pello Altadill
 * @version 1.0 19/01/2003
 * @extends Thread
 */
public class Engine extends Thread {

	/**
	* atributuak
	*/
	// Web page raw content
	private String search_term = "";
	private static SFPCProperties PROPERTIES = SFPCProperties.getSFPCProperties();
	private int MAX_SEARCHES = 10;
	private int NUMBER_OF_SEARCHES = 100;
	private String INC_PARAM = "";
	private String SEARCH_ENGINE = "www.google.com";
	// Generic Handlers - Objetos genericos de handlers
	private Object google_parser = null;
	private Object customer_page_parser = null;
	private Database database = new Database();
	private int BARRIER = 10;
		
	/**
	* Constructor
	*/
	public Engine (String search_term){
		this.search_term = search_term;
		initEngine();
	}
	
	/**
	* initEngine
	* Init Engine, ready to start
	*/
	private void initEngine () {
		// Define generic class for dinamic Object generation
		Class google_parser_class = null;
		Class customer_page_parser_class = null;
		Page search_page = new Page();
		
		try {
			// Asignamos propiedades
			NUMBER_OF_SEARCHES = Integer.parseInt(PROPERTIES.getProperty("number_of_searches"));
			MAX_SEARCHES =Integer.parseInt(PROPERTIES.getProperty("max_results"));
			INC_PARAM = PROPERTIES.getProperty("inc_param");
			SEARCH_ENGINE = PROPERTIES.getProperty("search_engine");
			
			// Generate parser classes from name
			google_parser_class = Class.forName(PROPERTIES.getProperty("google_parser"));
			customer_page_parser_class = Class.forName(PROPERTIES.getProperty("client_parser"));

			// Instance creation!!
			google_parser = google_parser_class.newInstance();
			customer_page_parser = customer_page_parser_class.newInstance();		
			
			// IF anyone is null, STOP inmediatelly
			if (google_parser == null || customer_page_parser == null) 
				throw new Exception("One of Parser classes is NULL!! Check classpaths.");


		} catch (Exception e) {
			PROPERTIES.log("Error at Engine init. Unable to run!!! : " +e.getMessage());
			System.exit(-1);
		}
	}
	
	/**
	* run
	* Start of Engine
	*/
	public void run () {
		// search page, to store
		Page search_page = new Page();
		String search_result = "";
		String[] result = null;
		String search_url = null;
		// ThreadGroup to control paralell tasks
		ThreadGroup engineTasks = new ThreadGroup("EngineTasks");
		
		PROPERTIES.log("Starting engine for " + search_term + " search term.");
		
		try {
			// Damos las vueltas especificadas en properties, incrementando busquedas
		 	for (int i = 0; i < NUMBER_OF_SEARCHES; i += MAX_SEARCHES) {
			 	search_url = PROPERTIES.getProperty("search_string") + this.search_term  + "&" +INC_PARAM + i;
				PROPERTIES.log("Searching: " + search_url);
				
			 	// Load URL & Read links - Cargar peticion & Sacar enlaces 
				search_result = search_page.sendForm(SEARCH_ENGINE,search_url);
				result = ((SFPCParser)google_parser).parseIt(search_result).split(",");

				BARRIER = result.length;
				// Init tasks - Iniciamos tantas tareas como resultados
				for (int j = 0; j < result.length; j++) {
					PROPERTIES.log("<TASK " + i + " " + j + "> " + result[j]);
					new Dog(engineTasks,result[j]).start();
				}//end_for_2
				
				// Barrier
				while (BARRIER > 0);
				PROPERTIES.log("Otra RONDA!!");				
			 }//end_for_1
			 
		} catch (Exception e) {
			System.out.println("General Exception: " + e.getMessage());
		} finally { // En cualquier caso
			System.out.println("Finally");				
			// retornamos resultado
		}

	}

/**
* Dog, inner class that looks into client html page
*/
public class Dog extends Thread {
	/**
	* Atributes
	*/
	private String url = "";
	
	/**
	* Constructor
	*/
	Dog (ThreadGroup tg, String url) {
		this.url = url;
		}
	
	public void run () {
		PROPERTIES.log("RAUF RAUF! Dog started, sniffing at " + url);	
		Page page = new Page();
		String text_to_parse = "";
		String sniff_result = "";
		
		try {
			text_to_parse = page.getPage(url);
			sniff_result = ((SFPCParser)customer_page_parser).parseIt(text_to_parse);
			// add default account
			if (sniff_result.length() < 1)
				sniff_result += "webmaster@" + getEmailFromHost(page.getHost());
			// Save data into database
			database.saveData(sniff_result);
		} catch (Exception e) {
			PROPERTIES.log("Error in Dog with URL " + url);
		}	
		PROPERTIES.log("RAUF RAUF! Dog finished with host: " + page.getHost() + " [OK]. Result: " +sniff_result);	
		BARRIER--;
	}
}//end inner-class

	/**
	* getEmailFromHost
	* @param String host
	* @return String email
	* Gets possible email from host name: webmaster@host
	*/
	private String getEmailFromHost (String host) {
		String[] hostname = host.split(".");
		
		// If hostname is www.host.freehost.com return: host.freehost.com
			return host.substring(host.indexOf(".")+1,host.length());
		
	}

}//end class 

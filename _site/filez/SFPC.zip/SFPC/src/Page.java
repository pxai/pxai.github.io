/**
*
* SFPC at Home
* Search For Potential Customers
* SPFC performs searches at google of given subjects
* and retrieves emails from webpages.
*
* (C) 2003 - Pello Xabier Altadill Izura - pello@pello.info
* Check for updates at http://pello.info
*
*** (See LICENSE.txt for details) 
*
* Page.java Retrieves URL content, and saves into String
*/

/**
* package declaration
*/
package info.pello.SFPC;

/**
* imports
*/
import java.util.Date;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;
import java.net.HttpURLConnection;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.IOException;

 /**
 * Class deklarazioa
 * @author Pello Altadill
 * @version 1.0 19/01/2003
 */
public class Page {

	/**
	* atributuak
	*/
	// Web page raw content
	private String _CONTENT = "";
	private URL _URL;
	
	/**
	* Constructor
	*/
	public Page (){
	}
	
	/**
	* getPage
	* @param String URL
	* @return String description
	* Retrieves web page content from internet
	*/
	public String getPage (String url) {
		URL page = null;
		URLConnection connection = null;
		 BufferedReader in = null;
		 String result = "";
		 String temp = "";
		 
		try {
			// Creamos una URL
			page = new URL(url);
			_URL = page;
			
  			// Establish User-Agent
  			//connection.setRequestProperty("User-Agent","Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)");
  
	  		// Establish language - Establecemos lenguaje        
  			//connection.setRequestProperty("Content-Language", "es-ES");

  			// Abrimos la conexion
  	   		connection = page.openConnection();
	    // Enlazamos los streams de datos
	      in = new BufferedReader( new InputStreamReader( connection.getInputStream())); 
		// Leemos todo
	      	while ((temp =  in.readLine()) != null) 
		      	result += temp;
			      
			System.out.println("HTTP OK - 200 ");
		      
		// Cerramos conexion
			if (in != null) {
				in.close();
			}
			return result;
		
		} catch (MalformedURLException mue)  {
			System.out.println("MalformedURLException : " + mue.getMessage());			
		} catch (Exception e) {
			System.out.println("General Exception: " + e.getMessage());
		} finally { // En cualquier caso
			// retornamos resultado
			return result;
		}

	}

	/**
	* getHost
	* @param String url
	* @returns string
	*/
	public String getHost () {
		return _URL.getHost();
	}

	/**
	* sendForm
	* @param String URL
	* @return String params
	* Retrieves web page content from internet after sending form
	* It uses NetClient, for get around google automation problems
	*/
	public String sendForm (String host,String url) {
		 NetClient netclient = null;
		 String result = "";
	
		 try {
			netclient = new NetClient("www.google.com",80,url);
			netclient.start();
			result = netclient.tryConnection();
		} catch (Exception e) {
			System.out.println("General Exception: " + e.getMessage());
		} finally { // En cualquier caso
			// retornamos resultado
			return result;
		}

	}
	

}//end class 

/**
*
* SFPC at Home
* Search For Potential Customers
* SPFC performs searches at google of given subjects
* and retrieves emails from webpages.
*
* (C) 2003 - Pello Xabier Altadill Izura - pello@pello.info
* Check for updates at http://pello.info
*
*** (See LICENSE.txt for details) 
*
* SFPC.java Main class (starter for SPFC at home)
*/

/**
* package declaration
*/
package info.pello.SFPC;

/**
* imports
*/
import java.util.Date;
import java.util.StringTokenizer;
import info.pello.SFPC.parsers.*;


 /**
 * Class deklarazioa
 * @author Pello Altadill
 * @version 1.0 19/01/2003
 */
public class Tester {

	/**
	* atributuak
	*/
	private static SFPCProperties PROPERTIES = SFPCProperties.getSFPCProperties();

	/**
	* Constructor
	*/
	public Tester (){
	}
	
	/**
	* init
	* Inicia el cotarro
	*/
	public static void init() {
		StringTokenizer st = null;
		Page pagina = new Page();
		String result = "";
		ResultPageParser parser = new ResultPageParser();
		
			try {
			PROPERTIES.log("AMOOOOOO que vamo");
			result = pagina.sendForm("www.google.com","/search?q=manuales");
			String result_final = ((SFPCParser)parser).parseIt(result);
			System.out.println(result_final);
						
			PROPERTIES.log("Work FINISHED!!!");
		} catch (Exception e) {
			PROPERTIES.log("General Error at main class. Check properties file: " + e.getMessage());
		}
	}



	/**
	* Main method
	*/
	public static void main (String args[]) {
		try { 
               Tester.init();
                
		} catch (Exception e) {
		System.err.println("Exception: " + e.getMessage());  
		} 
	}


}//end class 


 	<div id="eskuina">

 		<h2>Calendar</h2>
    	    <?php get_calendar(); ?>
      	<h2>Main</h2>
      	
		<ul>
		<li><a href="<?php bloginfo('url'); ?>">Home</a></li>
		<?php wp_list_pages('sort_column=menu_order&title_li='); ?>
		</ul>

		<h2><?php _e('Categories:'); ?></h2>
		<ul>
		<?php wp_list_cats('sort_column=name&optioncount=1'); ?>
		</ul>

		<h2><?php _e('Archives:'); ?></h2>
		<ul>
      	<?php wp_get_archives('type=monthly&show_post_count=1'); ?>
      	</ul>
      	
      	<h2><label for="s"><?php _e('Search:'); ?></label></h2>	
		<form id="searchform" method="get" action="<?php echo $PHP_SELF; ?>">
		<div>
			<input type="text" name="s" id="s" size="17" class="navi-search" /><br />
			<input type="submit" name="submit" value="<?php _e('Search'); ?>" class="search-button" />
		</div>
		</form>

      	<h2> Links</h2>
      	<ul>
			<?php wp_get_links(1); ?>
		</ul>

		<h2><?php _e('Meta:'); ?></h2>
		<ul>
			<?php wp_register(); ?>
			<li><?php wp_loginout(); ?></li>
			<li><a href="feed:<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?>"><?php _e('<abbr title="Really Simple Syndication">RSS</abbr>'); ?></a></li>
			<li><a href="feed:<?php bloginfo('comments_rss2_url'); ?>" title="<?php _e('The latest comments to all posts in RSS'); ?>"><?php _e('Comments <abbr title="Really Simple Syndication">RSS</abbr>'); ?></a></li>
			<li><a href="http://validator.w3.org/check/referer" title="<?php _e('This page validates as XHTML 1.0 Transitional'); ?>"><?php _e('Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr>'); ?></a></li>
			<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
			<li><a href="http://wordpress.org/" title="<?php _e('Powered by WordPress, state-of-the-art semantic personal publishing platform.'); ?>"><abbr title="WordPress">WP</abbr></a></li>
			<?php wp_meta(); ?>
		</ul>

		<?php if (function_exists('wp_theme_switcher')) { ?>
		<h2>Styleswitcher</h2> 
		<?php wp_theme_switcher(); ?>
		<?php } ?>
    </div>
    
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<!--
Sunflowers Theme for Wordpress 2.0
Pello Xabier Altadill Izura

The CSS, XHTML and design is released under GPL:
http://www.opensource.org/licenses/gpl-license.php
-->
<head>
<title><?php bloginfo('name'); ?><?php wp_title(); ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo('charset'); ?>" />
<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />

<meta name="author" content="Pello Xabier Altadill Izurarl" />
<meta name="publisher" content="Pello Xabier Altadill Izura" />
<meta name="copyright" content="Pello Xabier Altadill Izura" />
<meta name="page-topic" content="Just another Wordpress" />
<meta name="audience" content="all" />
<meta name="robots" content="index,follow" />
<meta name="revisit-after" content="3 days" />
	
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<?php wp_get_archives('type=monthly&format=link'); ?>
<?php //comments_popup_script(); // off by default ?>
<?php wp_head(); ?>
</head>

<body>

<div id="orria">

<?php
require_once ('functions.php'); 
// todaysRandomImage: displays one different picture evey day
// randomImage: displays different picture on every reloatodaysRandomImaged
?>

 
 <div id="goiburua" style="background: url('<?php echo  get_template_directory_uri()."/".todaysRandomImage();?>');">
    
	<span id="wptitle"><a href="<?php bloginfo('url'); ?>"> 
      <?php bloginfo('name'); ?>
      </a>
    </span>
    <span id="wptitleitzala"><a href="<?php bloginfo('url'); ?>"> 
      <?php bloginfo('name'); ?>
      </a>
    </span>
    <br />
 	 <span id="wptagline">
      <?php bloginfo('description'); ?>
     </span>
     <span id="wptaglineitzala">
      <?php bloginfo('description'); ?>
     </span>
    
    <!-- OPTIONAL TABBED - MENU AUKERAZKO MENUA -->
	<!-- div id="menugoiburua">
	<ul>
		<li>Home</li>
		<li>Pages</li>
		<li>Registry</li>
		<li>Login</li>
		<li>About</li>
	</ul>
	</div-->
 </div>
 
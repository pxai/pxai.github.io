<?php require_once ('header.php'); ?>


<!- --------------------------------------------- ->
  <!-- RIGHT NAV BAR -->  	
    <?php require_once ('sidebar.php'); ?>


<!- --------------------------------------------- ->
<!-- CONTENT -->  	
<div id="nagusia">
<br /><br />
 <?php if ($posts) : foreach ($posts as $post) : start_wp(); ?>

  <h2 id="post-<?php the_ID(); ?>">
   <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a>
 </h2>

	<div class="storycontent">
		<?php the_content(__('(more...)')); ?> <?php edit_post_link(); ?>
	</div> 


 <?php endforeach; else: ?>
	<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
 <?php endif; ?>

<div class="center"><?php posts_nav_link('&nbsp;&nbsp;', __('&laquo; Previous'), __('Next &raquo;')); ?></div>

</div>

<!- --------------------------------------------- ->
<!-- FOOTER -->
    <?php require_once ('footer.php'); ?>

</div>

</body>
</html>

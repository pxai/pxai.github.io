<?php
/**
* functions.php
* For Sunflowers wordpress theme
* Pello Xabier Altadill Izura
*/
  
 	/**
 	* todaysRandomImage
 	* Displays random image in header, one per day
 	*/
 	function todaysRandomImage () 
 	{
 		$imagepath = "images/random/";
 		$images;
		$d = dir(dirname(__FILE__)."/images/random");
	
		while (false !== ($entrada = $d->read())) 
		{
			if ($entrada != "." && $entrada!="..") 
			{
				$images[] = $imagepath.$entrada;
	   			//echo $imagepath.$entrada."\n<br>";
			}
		}
		$d->close();
		
		// we take the total amount of files
		$total = count($images);
		// take day of the year
		$today = date("z");
		// select one index 
		$selected = $today % $total;
		// and return images array element: image path
		return $images[$selected];

 	}
 	
 	/**
 	* randomImage
 	* Displays random image in header
 	*/
 	function randomImage () 
 	{
 		$imagepath = "images/random/";
 		$images;
		$d = dir(dirname(__FILE__)."/images/random");
	
		while (false !== ($entrada = $d->read())) 
		{
			if ($entrada != "." && $entrada!="..") 
			{
				$images[] = $imagepath.$entrada;
	   			//echo $imagepath.$entrada."\n<br>";
			}
		}
		$d->close();
		
		// we take the total amount of files
		$total = count($images);
		// select one index within bounds
		$selected = rand(0, ($total-1));
		
		// and return images array element: image path
		return $images[$selected];

 	}
?>
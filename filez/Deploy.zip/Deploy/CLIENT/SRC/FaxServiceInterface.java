// Hauxe da zerbitzuaren proxy-ak inplementatuko
// duen interfazearen definizioa

package corejini.chapter5;

// Fax zerbitzuaren interfazea
public interface FaxServiceInterface {
    public String hartuMezua();
    public void martxanJarri();
    public String ekarriMezua();
    public void bidaliMezua(String mezu);
}
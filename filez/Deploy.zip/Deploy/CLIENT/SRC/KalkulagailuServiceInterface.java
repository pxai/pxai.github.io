// Hauxe da zerbitzuaren proxy-ak inplementatuko
// duen interfazearen definizioa
package corejini.chapter5;

import java.io.IOException;


// Kalkulagailu zerbitzuaren interfazea
public interface KalkulagailuServiceInterface {
    public String hartuMezua();
    public int batuketa(int a, int b);
    public int kenketa(int a, int b);
    public int biderketa(int a, int b);
    public int zatiketa(int a, int b);
    public int modulua(int a, int b);
    public int portzentaia(int a, int b);
    public void martxanJarri() throws IOException;
}
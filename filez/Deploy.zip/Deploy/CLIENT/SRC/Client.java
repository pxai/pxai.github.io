// A client of the print service

package corejini.chapter13;

import net.jini.discovery.*;
import net.jini.core.lookup.*;
import net.jini.core.event.*;
import net.jini.core.entry.*;
import net.jini.admin.*;
import java.io.*;
import java.awt.print.*;
import java.awt.*;
import java.rmi.*;
import java.rmi.server.*;
import java.awt.event.*;
import javax.swing.*;

public class Client implements Runnable { 
    ServiceTemplate template;

    // An inner class for discovery
    class Discoverer implements DiscoveryListener {
        public void discovered(DiscoveryEvent ev) {
            ServiceRegistrar[] regs = ev.getRegistrars();
            for (int i=0 ; i<regs.length ; i++) {
                doit(regs[i]);
            }
        }
        public void discarded(DiscoveryEvent ev) {
        }
    }
    
    public Client() throws IOException {
        Class[] types = { Printer.class };
        template = new ServiceTemplate(null, types, null);
        
        LookupDiscovery disco =
            new LookupDiscovery(LookupDiscovery.ALL_GROUPS);
        disco.addDiscoveryListener(new Discoverer());
    }

    void doit(ServiceRegistrar reg) {
        Printer printer = null;
        Entry[] attributes = null;
        
        try {
            ServiceMatches matches = reg.lookup(template, 
                                                Integer.MAX_VALUE);
            if (matches.totalMatches > 0) {
                printer = (Printer) matches.items[0].service;
                attributes = matches.items[0].attributeSets;
            } else {
                printer = null;
            }
        } catch (Exception ex) {
            System.err.println("Doing lookup: " + ex.getMessage());
            ex.printStackTrace();
        }
        
        if (printer == null)
            return;
        
        System.out.println("Got a printer!");
        
        // issue a couple of print requests.
        try {
            printer.print(PageFormat.PORTRAIT, 1, 
                          new PrintableString("Hello World"), 
                          new Listener());
            printer.print(PageFormat.LANDSCAPE, 1, 
                          new PrintableString("Hello Again"), 
                          new Listener());
        } catch (Exception ex) {
            System.out.println("Trouble printing: " + ex.getMessage());
            ex.printStackTrace();
        }
        
        PrintAdminPanel panel = null;
        
        for (int i=0, size=attributes.length ; i<size ; i++) {
            if (attributes[i] instanceof PrintAdminPanel) 
                panel = (PrintAdminPanel) attributes[i];
        }

        if (panel != null) {
            try {
                panel.setAdmin((PrintAdmin) 
                               ((Administrable) printer).getAdmin());
            } catch (RemoteException ex) {
                System.err.println("Error getting admin: " + ex.getMessage());
                ex.printStackTrace();
            }
        
            final JFrame frame = new JFrame("Print Admin Panel");
            frame.getContentPane().add(panel);
            frame.pack();
            frame.setVisible(true);
            frame.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent ev) {
                    frame.setVisible(false);
                    frame.dispose();
                }
            });
        }
    }
   
    // An inner class for handling events.
    class Listener extends UnicastRemoteObject implements PrintListener {
        Listener() throws RemoteException {
            super();
        }
        public void notify(RemoteEvent e) {
            if (!(e instanceof PrintServiceEvent)) {
                return;
            }
            PrintServiceEvent ev = (PrintServiceEvent) e;
            if (ev.printJobFinished()) {
                System.out.println("Job finished successfully!");
            } else {
                System.out.println("Job failed:  " + 
                                   ev.getException().getMessage());
                ev.getException().printStackTrace();
            }
        }
    }
    
    public void run() {
        while (true) {
            try {
                Thread.sleep(Integer.MAX_VALUE);
            } catch (InterruptedException ex) {
            }
        }
    }
   
    // A string that implements Printable
    static class PrintableString implements Printable, Serializable {
        String s;
        PrintableString(String s) {
            this.s = s;
        }
        public int print(Graphics g, PageFormat pf, int page) throws
            PrinterException {
            if (page >= 1) {
                return Printable.NO_SUCH_PAGE;
            }
            g.drawString(s, 20, 60);
            return Printable.PAGE_EXISTS;
        }
        public String toString() { 
            return s;
        }
    }

    public static void main(String[] args) {
        try {
            Client client = new Client();
            new Thread(client).start();
        } catch (Exception ex) {
            System.err.println("Bogus: " + ex.getMessage());
            System.exit(1);
        }
    }
}

// Hauxe da zerbitzuaren proxy-ak inplementatuko
// duen interfazearen definizioa

package corejini.chapter5;

// Telebista zerbitzuaren interfazea
public interface TelebistaServiceInterface {
    public String hartuMezua();
    public void martxanJarri();
}
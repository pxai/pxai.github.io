// Hauxe da zerbitzuaren proxy-ak inplementatuko
// duen interfazearen definizioa

package corejini.chapter5;

// Bideoa zerbitzuaren interfazea
public interface BideoaServiceInterface {
    public String hartuMezua();
    public void martxanJarri();
}
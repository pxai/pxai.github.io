// Bezero xinple bat TelebistaService erabiltzeko

package corejini.chapter5;

import net.jini.discovery.DiscoveryListener;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.LookupDiscovery;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceTemplate;
import java.util.Vector;
import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;

public class TelebistaClient implements Runnable {
    protected ServiceTemplate template;
    protected LookupDiscovery disco;
    
    // DiscoveryListener inplementatzeko inner-klasea
    class Listener implements DiscoveryListener {
        public void discovered(DiscoveryEvent ev) {
            ServiceRegistrar[] newregs = ev.getRegistrars();
            for (int i=0 ; i<newregs.length ; i++) {
                lookForService(newregs[i]);
            }
        }
        public void discarded(DiscoveryEvent ev) {
        }
    }
    
    public TelebistaClient() throws IOException {
        Class[] types = { TelebistaServiceInterface.class };
        
        template = new ServiceTemplate(null, types, null);
        
        // security manager bat ezartzen da...
        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new RMISecurityManager());
        }
        
        // Bakarrik 'public' taldean bilatzen da...
        disco = new LookupDiscovery(new String[] { "" });
        
        // Entzule bat instalatzen da...
        disco.addDiscoveryListener(new Listener());
    }
    
    // Behin Lookup zerbitzua(k) topatuta,  
    // HelloWorldServiceInterface plantillarekin bat datorren
    // zerbitzua bilatzen da bertan (hots, interfaze hori inplementatzen
    // duten zerbitzuak
    protected Object lookForService(ServiceRegistrar lusvc) {
        Object o = null;
        
        try {
            o = lusvc.lookup(template);
        } catch (RemoteException ex) {
            System.err.println("Error doing lookup: " + ex.getMessage());
            return null;
        }
        
        if (o == null) {
            System.err.println("No matching service.");
            return null;
        }
        
        System.out.println("Bat datorren zerbitzua topatu da!");
        System.out.println("Bere lehen mezua da: " +
                           ((TelebistaServiceInterface) o).hartuMezua());
        System.out.println("Telebista martxan jartzen dugu: ");
			
        ((TelebistaServiceInterface) o).martxanJarri();
			   
        return o;
    }
    
    // Hari honek ez du ezer ere ez egiten
    // discovery egiten den bitartean JVMtik ez ateratzeko.
    public void run() {
        while (true) {
            try {
                Thread.sleep(1000000);
            } catch (InterruptedException ex) {
            }
        }
    }
    
    // HelloWorldClient objektu bat sortu eta bere haria martxan jartzen du
    public static void main(String args[]) {
        try {
            TelebistaClient kc = new TelebistaClient();
            new Thread(kc).start();
        } catch (IOException ex) {
            System.out.println("Ezin izan dut bezeroa sortu: " +
                               ex.getMessage());
        }
    }
}
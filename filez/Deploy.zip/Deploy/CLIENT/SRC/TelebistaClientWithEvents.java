// Bezeroaren Luzapen bat da, gertaera berriak
// jasotzeko gai dena. Beraz, zerbitzua baino lehen
// exekuta daiteke.

package corejini.chapter5;

import net.jini.core.lookup.ServiceEvent;
import net.jini.core.lookup.ServiceItem;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.event.RemoteEvent;
import net.jini.core.event.RemoteEventListener;
import net.jini.core.event.UnknownEventException;
import java.util.Vector;
import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class TelebistaClientWithEvents extends TelebistaClient {
    protected final int LEASE_TIME = 10 * 60 * 1000; // 10 minutu

    // inner motako klasea gertaeren entzule bezala jokatzeko
    class MyEventListener
        extends UnicastRemoteObject
        implements RemoteEventListener {
        public MyEventListener() throws RemoteException {
        }

        // Gertaera bat jasotzen denean deitzen den funtzioa
        public void notify(RemoteEvent ev)
            throws RemoteException, UnknownEventException {
            System.out.println("Gertaera bat dator: " + ev.getSource()+"-tik");
            if (ev instanceof ServiceEvent) {
                ServiceEvent sev = (ServiceEvent) ev;
                ServiceItem item = sev.getServiceItem();
                TelebistaServiceInterface hws =
                    (TelebistaServiceInterface) item.service;

                System.out.println("Bilatzen den zerbitzua topatu da.");
                System.out.println("Bere mezua da: " +
                                   hws.hartuMezua());
                System.out.println("Interfazea mrtxan jartzen...");
                                   hws.martxanJarri();
		} else {
                System.out.println("Ez da zerbitzu gertaera...");
            }
        }
    }

    protected MyEventListener eventCatcher;

    // Gertaera entzulea martxan jartzen du.
    public TelebistaClientWithEvents() throws RemoteException, IOException {
        eventCatcher = new MyEventListener();
    }

    protected Object lookForService(ServiceRegistrar lu) {
        Object o = super.lookForService(lu);

        if (o != null) {
            return o;
        } else {
            try {
                registerForEvents(lu);
            } catch (RemoteException ex) {
                System.err.println("Ezin dut gertaerak jaso: "
                                   + ex.getMessage());
                // Discard, berriz bilatuko dugu beraz
                disco.discard(lu);
            } finally {
                return null;
            }
        }
    }

    // lookup zerbitzutik datozen gertaeren zain geratzeko
    protected void registerForEvents(ServiceRegistrar lu)
        throws RemoteException {
        lu.notify(template,
                  ServiceRegistrar.TRANSITION_NOMATCH_MATCH,
                  eventCatcher, null, LEASE_TIME);
    }

    // Bezeroa Hasi.
    public static void main(String args[]) {
        try {
            TelebistaClientWithEvents hwc = new TelebistaClientWithEvents();
            new Thread(hwc).start();
        } catch (Exception ex) {
            System.out.println("Ezin izan dut bezeroa hasieratu: " +
                               ex.getMessage());
        }
    }
}
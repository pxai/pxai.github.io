// Bezero xinple bat KafeMakinaService eravbiltzeko

package corejini.chapter5;

import net.jini.discovery.DiscoveryListener;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.LookupDiscovery;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceTemplate;
import java.util.Vector;
import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;

public class KafeMakinaClient implements Runnable {
    protected ServiceTemplate template;
    protected LookupDiscovery disco;
    
    // DiscoveryListener inplementatzen duen 'Inner' klasea
    class Listener implements DiscoveryListener {
        public void discovered(DiscoveryEvent ev) {
            ServiceRegistrar[] newregs = ev.getRegistrars();
            for (int i=0 ; i<newregs.length ; i++) {
                lookForService(newregs[i]);
            }
        }
        public void discarded(DiscoveryEvent ev) {
        }
    }
    
    public KafeMakinaClient() throws IOException {
        Class[] types = { KafeMakinaServiceInterface.class };
        
        template = new ServiceTemplate(null, types, null);
        
        // Segurtasun kudeatzaile bat ezartzen dugu
        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new RMISecurityManager());
        }
        
        // public taldean soilik begiratuko du
        disco = new LookupDiscovery(new String[] { "" });
        
        // listener edo gertaera entzula bt martxan jartzen da
        disco.addDiscoveryListener(new Listener());
    }
    
    // LookUp bat topatzen dugunean
    // KafeMakinaServiceInterface inplemtatzen duten
    // Proxy objektuak bilatzen ditugu
    protected Object lookForService(ServiceRegistrar lusvc) {
        Object o = null;
        
        try {
            o = lusvc.lookup(template);
        } catch (RemoteException ex) {
            System.err.println("Errorea lookup-ean: " + ex.getMessage());
            return null;
        }
        
        if (o == null) {
            System.err.println("Ez da bilatzen den zerbitzurik topatu.");
            return null;
        }
        
        System.out.println("Bat datorren zerbitzua topatu da!");
        System.out.println("Bere lehen mezua da: " +
                           ((KafeMakinaServiceInterface) o).hartuMezua());
        System.out.println("Programa mrtxan jartzen dugu.");
				try {
        ((KafeMakinaServiceInterface) o).martxanJarri();
			   } catch (IOException excep) {
			   System.out.println(excep.getMessage());
			   }
        return o;
    }
    
    // Hari honek ez du ezer ere ez egiten.
    // Discivery-a egiten den bitartean JVMtik ez ateratzeko
    // balio du.
    public void run() {
        while (true) {
            try {
                Thread.sleep(1000000);
            } catch (InterruptedException ex) {
            }
        }
    }
    
    // KafeMakinaClient sortu eta bere haria martxan jrtzen du
    public static void main(String args[]) {
        try {
            KafeMakinaClient kc = new KafeMakinaClient();
            new Thread(kc).start();
        } catch (IOException ex) {
            System.out.println("Ezin izan dut bezeroa sortu: " +
                               ex.getMessage());
        }
    }
}
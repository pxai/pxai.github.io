// Hauxe da zerbitzuaren proxy-ak inplementatuko
// duen interfazearen definizioa

package corejini.chapter5;

import java.io.IOException;


// KafeMakina zerbitzuaren interfazea
public interface KafeMakinaServiceInterface {
		String Status=null;
    public String hartuMezua();
    public String ordaindu(String visa,String urtea,String hilabetea);
    public String kafeHutsa(int azukrea);
    public String kafeEbakia(int azukrea);
    public String kafeEsnea(int azukrea);
    public String esneHutsa(int azukrea);
    public String kaputxinoa(int azukrea);
    public void martxanJarri() throws IOException;
}
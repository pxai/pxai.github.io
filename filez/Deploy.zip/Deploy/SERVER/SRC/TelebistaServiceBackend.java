// Honek, TelebistaService-ren luzapen bat da
// RMI erabiltzen duena aktibagarri den back-end
// prozesu batekin. Aktibagarritasuna jdk1.2tik aurrera
// RMI-n erabil daitekeen teknologia da.


// Paketearen definizioa
package corejini.chapter5;

// Import gunea
import java.util.Vector;
import java.util.Enumeration;
import java.io.IOException;
import java.io.Serializable;
import java.io.DataInputStream;
import java.io.DataInput;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.rmi.Remote;
import java.rmi.MarshalledObject;
import java.rmi.RMISecurityManager;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.activation.Activatable;
import java.rmi.activation.ActivationID;
import java.rmi.activation.ActivationDesc;
import java.rmi.activation.ActivationGroup;
import java.rmi.activation.ActivationGroupID;
import java.rmi.activation.ActivationGroupDesc;
import java.rmi.activation.ActivationException;
import java.util.Properties;
import java.awt.*;
import java.awt.event.*;


// Klasearen definizioa
public class TelebistaServiceBackend
    extends TelebistaServiceWithLeases {

    // Interfaze berezia proxy (bezeroek erabiliko duten objektua) eta
    // backend prozesuaren arteko komunikazio protokoloa definitzeko.
    interface BackendProtocol extends Remote {
          // Mezu bat itzultzen duen funtzio xinplea
         public String hartuMezua() throws RemoteException;

          // Interfaze grafikoa martxan jartzeaz arduratuko den funtzioa
         public void martxanJarri() throws RemoteException;

         // Sartutako balioak zernitzarian (Telebistan kasu honetan)
         // sartzeaz arduratuko den funtzioa
         public void balioakGorde(String balioa) throws RemoteException;
    }


		// Kabiatutako klase honek backend protokoloa
		// (goian inplementaturiko interfazea) inplementatzen du.
		// Aktibagarria da, beraz
		// UnicasRemoteObjektua izanen da.
    // Bezeroak jasoko duen proxy objektuak Backend honi
    // pasako dizkio eskaerak.
    public static class Backend extends Activatable
                                implements BackendProtocol {

        public Backend(ActivationID id, MarshalledObject data)
            throws RemoteException {
            super(id, 0);
        }

        // Jarraian interfazean deklaratutako funtzioak
        // inplementatzen dira.
        // Backend objektu honek Telebistarekin komunikatzen da
        // zuzenean, beraz dipositibo eta proxy-aren
        // bitartekaria da
	      public String hartuMezua() throws RemoteException{
        return "<zerbitzutik>Hauxe da Telebista zerbitzu Xinplea\n";}

        public void martxanJarri() throws RemoteException {};

        // Honek, bezerotik programazio ordu bat jasotzen du
        // eta bere 'memorian' gordetzen du...
        public void balioakGorde (String balioa) throws RemoteException {
          try {
          PrintWriter Telebista = new PrintWriter(new FileOutputStream("c:\\telebista-aginduak"));
          Telebista.println(balioa);
          Telebista.close();
          } catch (IOException ioex) {
           System.err.println("Errorea:"+ioex.getMessage());
          }
        }
      	// klase honek, aktibagarritasuna dela eta, lanik ez duenean
      	// 'sleep' egoerara pasako da.
    }


// TelebistaServiceProxy2 Klasea
    // Hauxe da bezeroei bidaliko zaien klasea zerbitzua
    // erabili nahi dutenean. Honek berezitasun bat dauka:
    // Bezeroari interfaze grafikoa erkusten dio
    static class TelebistaServiceProxy2
    extends Frame
    implements Serializable, TelebistaServiceInterface {

    BackendProtocol backend;// Honen bitartez, proxy-a backend-arekin komunikatuko da
  BorderLayout borderLayout1 = new BorderLayout();
  Panel panelBeheko = new Panel();
  Label label1 = new Label();
  Panel panelErdiko = new Panel();
  FlowLayout flowLayout1 = new FlowLayout();
  Button buttonReset = new Button();
  Button buttonKantzel = new Button();
  Button buttonGorde = new Button();
  Choice choiceItzaliPiztu = new Choice();	
  Choice choiceKonexioa = new Choice();
  Choice choiceKanala = new Choice();
  Choice choiceBolumena = new Choice();
  Choice choiceArgia = new Choice();
  Choice choiceKontrastea = new Choice();
  TextField TextFieldHasiOrdu = new TextField();
  TextField TextFieldBukaOrdu = new TextField();
  GridLayout gridLayout1 = new GridLayout();

  // Ikusten denez, proxy-ak ez dio dispositiboari
  // zuzenean agindua pasatzen, backend-ri
  // baizik...
  public String hartuMezua () {
    try {
          return backend.hartuMezua(); // Backend-ari pasatutako agindua
        } catch (RemoteException re) {
        return "Errorea balioakGorde() funtzioan...\n";
        }
  }

  public void martxanJarri() {
     try  {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  try {
          backend.martxanJarri(); // Backend-ari pasatutako agindua
        } catch (RemoteException re) {
        System.err.println("Errorea martxanJarri() funtzioan...\n");
        }

  }

  public void balioakGorde (String balioa) throws RemoteException {
    try {
          backend.balioakGorde(balioa); // Backend-ari pasatutako agindua
        } catch (RemoteException re) {
        System.err.println("Errorea hartuMezua() funtzioan...\n");
        }

  }

  // Funtzio nagusia. Ez da ezinbestekoa kasu honetan...
  public static void main (String args[]) {
   TelebistaServiceProxy2 bsp2= new TelebistaServiceProxy2();
  }

  // Eraikitzailea
  public TelebistaServiceProxy2() {

  }

  // Eraikitzailea
  public TelebistaServiceProxy2(BackendProtocol backend) {
    this.backend = backend;

  }

  private void hasieratuChoiceak() {
          int i;
  	choiceItzaliPiztu.addItem("ON / OFF");
  	choiceItzaliPiztu.addItem("PIZTU");
  	choiceItzaliPiztu.addItem("ITZALI");
	
      choiceKonexioa.addItem("Konexioa egin");
      choiceKonexioa.addItem("RCA");
      choiceKonexioa.addItem("Euro-konektorea");
      choiceKonexioa.addItem("InfraGorri portua");
      choiceKonexioa.addItem("G-Ether interfazea");
      choiceKanala.addItem("Kanala");
      choiceBolumena.addItem("Bolumena");
      choiceArgia.addItem("Argia");
      choiceKontrastea.addItem("Kontrastea");
      TextFieldHasiOrdu.setText("Pizteko Ordua->00:00");
      TextFieldBukaOrdu.setText("Itzaltzeko Ordua->00:00");


          for (i=0;i<99;i++) {
		choiceKanala.addItem(Integer.toString(i));
	     	choiceBolumena.addItem(Integer.toString(i));
      	choiceArgia.addItem(Integer.toString(i));
      	choiceKontrastea.addItem(Integer.toString(i));
          }
  }


  private void jbInit() throws Exception{
    hasieratuChoiceak();
    this.setLayout(borderLayout1);
    this.setBackground(Color.lightGray);
    this.setTitle("TelebistaServiceProxy Interface");
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
    borderLayout1.setVgap(10);
    panelBeheko.setBackground(Color.lightGray);
    borderLayout1.setHgap(10);
    label1.setAlignment(1);
    label1.setText("Telebista programatzeko zerbitzua");
    panelErdiko.setLayout(gridLayout1);
    buttonReset.setLabel("RESET");
    buttonKantzel.setLabel("KANTZEL");

    buttonKantzel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonKantzel_actionPerformed(e);
      }
    });
    buttonGorde.setLabel("BIDALI");
    buttonGorde.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonGorde_actionPerformed(e);
      }
    });
    gridLayout1.setRows(4);
    gridLayout1.setHgap(40);
    gridLayout1.setColumns(2);
    panelBeheko.setLayout(flowLayout1);
    this.add(panelBeheko, BorderLayout.SOUTH);
    panelBeheko.add(buttonGorde, null);
    panelBeheko.add(buttonReset, null);
    panelBeheko.add(buttonKantzel, null);
    this.add(label1, BorderLayout.NORTH);
    this.add(panelErdiko, BorderLayout.CENTER);
    panelErdiko.add(choiceItzaliPiztu, null);
    panelErdiko.add(choiceKanala, null);
    panelErdiko.add(choiceKonexioa, null);
    panelErdiko.add(choiceBolumena, null);
    panelErdiko.add(choiceArgia, null);
    panelErdiko.add(choiceKontrastea, null);
    panelErdiko.add(TextFieldBukaOrdu, null);
    panelErdiko.add(TextFieldHasiOrdu, null);
    this.setSize(400,300);
    this.show();
  }


  void this_windowClosing(WindowEvent e) {
    System.out.println("Leihoa ixten...");
    System.exit(0);
  }

  void buttonKantzel_actionPerformed(ActionEvent e) {
     System.out.println("Leihoa ixten...");
    System.exit(0);
  }

  // Funtzio honetan, backendari pasako zaion programazio ordua
  // eratzen da...
  private String sortuMezua () {

   return ("Kanala: "+choiceKanala.getSelectedItem() +"\n"
          +"Itzali / Piztu: "+choiceItzaliPiztu.getSelectedItem() +"\n"
          +"Bolumena: "+choiceBolumena.getSelectedItem() +"\n"
          +"Argia: "+choiceArgia.getSelectedItem() +"\n"
          +"Kontrastea: "+choiceKontrastea.getSelectedItem() +"\n"
          +"Konexioa: "+choiceKonexioa.getSelectedItem() +"\n"
          +"Piztu ordua: "+TextFieldBukaOrdu.getText() +"\n"
          +"Itzali ordua : "+TextFieldHasiOrdu.getText() +"\n");

  }
  void buttonGorde_actionPerformed(ActionEvent e) {
        try {
        balioakGorde(sortuMezua());
         } catch (RemoteException re) {
        System.err.println("Errorea balioak Telebistan gordetzerkoan..\n");
        }
       System.out.println("Balioa Telebistan gordetzen...");
       System.exit(0);
  }

  public void windowClosing(WindowEvent e) {
    dispose();
  }



}



   // TelebistaServiceBackend-ren hasiera

    public TelebistaServiceBackend() throws IOException {
    }

    protected TelebistaServiceInterface createProxy() {
        try {
        		// Aktibazio-talde berri batentzat deskribatzailea sortzen
        		// da gure backend objektua bertan exekutarazteko.
            Properties props = new Properties();
            props.put("java.security.policy", "c:\\tmp\\policy");
            ActivationGroupDesc group = new ActivationGroupDesc(props, null);
            // Taldea erregistratzen da eta IDa jasotzen da.
            ActivationGroupID gid =
                ActivationGroup.getSystem().registerGroup(group);
            // Orain taldea sortzen da.
            ActivationGroup.createGroup(gid, group, 0);

            // Aktibazio deskribatzailea sortzen dugu
            // gure objektuarentzat.

            String location = "file://tilde/kedwards/java/";
            MarshalledObject data = null;
            ActivationDesc desc =
                new ActivationDesc("corejini.chapter5." +
                       "TelebistaServiceBackend$Backend",
                       location, data);

            // Protokolo inplementatuko duen
            // Backend objektua sortzen dugu.
            BackendProtocol backend =
                (BackendProtocol) Activatable.register(desc);
            return new TelebistaServiceProxy2(backend);
        } catch (RemoteException ex) {
            System.err.println("Errorea backend objektua sortzerakoan: " +
                               ex.getMessage());
            System.exit(1);
            return null;
        } catch (ActivationException ex) {
            System.err.println("Arazoa aktibazioarekin: " + ex.getMessage());
            ex.printStackTrace();
            System.exit(1);
            return null;
        }
    }

		// Zerbitzua sortu eta bere
		// Lease hria martxan jartzen dugu.
    public static void main(String args[]) {
        try {
            TelebistaServiceBackend hws = new TelebistaServiceBackend();
            hws.leaseThread = new Thread(hws);
            hws.leaseThread.start();
        } catch (IOException ex) {
            System.out.println("Ezin izan da zerbitzua sortu: " +
                               ex.getMessage());
        }
    }
}
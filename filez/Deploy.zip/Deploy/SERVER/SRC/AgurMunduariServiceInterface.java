// This is the interface that the service's proxy
// implements

package corejini.chapter5;

public interface AgurMunduariServiceInterface {
    public String hartuMezua();
    public long hartuDenbora();
}

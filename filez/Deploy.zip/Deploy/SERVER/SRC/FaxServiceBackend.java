// Honek, FaxService-ren luzapen bat da
// RMI erabiltzen duena aktibagarri den back-end
// prozesu batekin. Aktibagarritasuna jdk1.2tik aurrera
// RMI-n erabil daitekeen teknologia da.


// Paketearen definizioa
package corejini.chapter5;

// Import gunea
import java.util.Vector;
import java.util.Enumeration;
import java.io.IOException;
import java.io.Serializable;
import java.io.DataInputStream;
import java.io.DataInput;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.rmi.Remote;
import java.rmi.MarshalledObject;
import java.rmi.RMISecurityManager;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.activation.Activatable;
import java.rmi.activation.ActivationID;
import java.rmi.activation.ActivationDesc;
import java.rmi.activation.ActivationGroup;
import java.rmi.activation.ActivationGroupID;
import java.rmi.activation.ActivationGroupDesc;
import java.rmi.activation.ActivationException;
import java.util.Properties;
import java.awt.*;
import java.awt.event.*;


// Klasearen definizioa
public class FaxServiceBackend
    extends FaxServiceWithLeases {

    // Interfaze berezia proxy (bezeroek erabiliko duten objektua) eta
    // backend prozesuaren arteko komunikazio protokoloa definitzeko.
    interface BackendProtocol extends Remote {
          // Mezu bat itzultzen duen funtzio xinplea
         public String hartuMezua() throws RemoteException;

          // Interfaze grafikoa martxan jartzeaz arduratuko den funtzioa
         public void martxanJarri() throws RemoteException;

        
        public String ekarriMezua () throws RemoteException;

	  // Honen bitartez, zerbitzaritik, jasotako azken fax-a bezerora
	  // bidal daiteke
	  public void bidaliMezua (String mezu) throws RemoteException;

    }


		// Kabiatutako klase honek backend protokoloa
		// (goian inplementaturiko interfazea) inplementatzen du.
		// Aktibagarria da, beraz
		// UnicasRemoteObjektua izanen da.
    // Bezeroak jasoko duen proxy objektuak Backend honi
    // pasako dizkio eskaerak.
    public static class Backend extends Activatable
                                implements BackendProtocol {

	  private static final String  azkenMezua= "c:\\azken-mezua.fax";
	  private static final String  bidaltzekoMezua= "c:\\bidaltzeko-mezua.fax";

	  // Eraikitzailea
        public Backend(ActivationID id, MarshalledObject data)
            throws RemoteException {
            super(id, 0);
        }

        // Jarraian interfazean deklaratutako funtzioak
        // inplementatzen dira.
        // Backend objektu honek Faxarekin komunikatzen da
        // zuzenean, beraz dipositibo eta proxy-aren
        // bitartekaria da
	      public String hartuMezua() throws RemoteException{
        return "<zerbitzutik>Hauxe da Fax zerbitzu Xinplea\n";}

        public void martxanJarri() throws RemoteException {};

        // Honek, bezerotik programazio fitxategi bat jasotzen du
        // eta bere 'memorian' gordetzen du, bidaltzen hasteko.
        public String ekarriMezua () throws RemoteException {
    		String mezua="",temp = null;
		try {
		 DataInputStream jal = new DataInputStream(new FileInputStream(azkenMezua));
	    	while (!((temp = jal.readLine()) == null))
	      	mezua=mezua+"\n"+temp;
    		jal.close();
		} catch (IOException ioex) {
			System.err.println("Errorea fitxategia irakurtzerakoan..."+ioex.getMessage());
			return ("Errorea fitxategia irakurtzerakoan..."+ioex.getMessage());
		}
		return mezua;
        }


	  // Honen bitartez, zerbitzaritik, jasotako azken fax-a bezerora
	  // bidal daiteke
	  public void bidaliMezua (String mezu) throws RemoteException {
		try {
		PrintWriter jal = new PrintWriter(new FileOutputStream(bidaltzekoMezua));
    		jal.println(mezu);
	   	jal.close();
			} catch (IOException ioex) {
			System.err.println("Errorea fitxategia idazterakoan..."+ioex.getMessage());
		}		
        }

      	// klase honek, aktibagarritasuna dela eta, lanik ez duenean
      	// 'sleep' egoerara pasako da.
    }


    // FaxServiceProxy2 Klasea
    // Hauxe da bezeroei bidaliko zaien klasea zerbitzua
    // erabili nahi dutenean. Honek berezitasun bat dauka:
    // Bezeroari interfaze grafikoa erkusten dio

static
class FaxServiceProxy2
extends Frame
implements FaxServiceInterface, Serializable {

  BackendProtocol backend;
  private boolean invokedStandalone = false;
  BorderLayout borderLayout1 = new BorderLayout();
  Panel panelControl = new Panel();
  Button buttonBidali = new Button();
  Button buttonJaso = new Button();
  GridLayout gridLayout1 = new GridLayout();
  TextArea textAreaMezua = new TextArea();
  Panel panel1 = new Panel();
  FlowLayout flowLayout1 = new FlowLayout();
  Label labelMezua = new Label();
  TextField textField1 = new TextField();
  Button buttonAukeratu = new Button();
  FileDialog fd;
  Panel panelBidali = new Panel();
  Button buttonSend = new Button();
  FlowLayout flowLayout2 = new FlowLayout();
  Button buttonIkusi = new Button();



  public FaxServiceProxy2() {
     }

  public FaxServiceProxy2(BackendProtocol backend) {
	this.backend = backend;
     }
  

  //Interfazea hasieratzeaz arduratzen den funtzioa
  private void jbInit() throws Exception {
    panelControl.setLayout(gridLayout1);
    this.setLayout(borderLayout1);
    this.setBackground(Color.lightGray);
    this.setTitle("FaxServiceProxy2 - Interface");
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
    buttonBidali.setLabel("BIDALI");
    buttonBidali.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonBidali_actionPerformed(e);
      }
    });
    buttonJaso.setLabel("JASOTAKOA");
    buttonJaso.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonJaso_actionPerformed(e);
      }
    });
    labelMezua.setText("Idatzi Fax zbkia");
    textField1.setText("(zenbakiak soilik)");
    buttonAukeratu.setLabel("AukeratuFitxategia");
    buttonSend.setLabel("Bidali Fax-a Zerbitzarira!!");
    buttonIkusi.setLabel("IKUSI testua");
    buttonIkusi.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonIkusi_actionPerformed(e);
      }
    });
    buttonSend.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonSend_actionPerformed(e);
      }
    });
    panelBidali.setLayout(flowLayout2);
    buttonAukeratu.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonAukeratu_actionPerformed(e);
      }
    });
    panel1.setLayout(flowLayout1);
    gridLayout1.setRows(4);
    gridLayout1.setColumns(1);
    this.add(panelControl, BorderLayout.WEST);
    panelControl.add(buttonBidali, null);
    panelControl.add(buttonJaso, null);
    this.add(textAreaMezua, BorderLayout.CENTER);
    this.add(panel1, BorderLayout.NORTH);
    panel1.add(labelMezua, null);
    panel1.add(textField1, null);
    panel1.add(buttonAukeratu, null);
    this.add(panelBidali, BorderLayout.SOUTH);
    panelBidali.add(buttonIkusi, null);
    panelBidali.add(buttonSend, null);
    textAreaMezua.setEditable(false);
     desagertarazi();
  }

  // Zenbait elementu GUIn agertarazteko
  private void agertarazi () {
   labelMezua.setVisible(true);
   textField1.setVisible(true);
   buttonAukeratu.setVisible(true);
    buttonSend.setVisible(true);
    buttonSend.setEnabled(false);
    buttonIkusi.setVisible(true);
    buttonIkusi.setEnabled(false);
  }

  // Zenbait elementu GUItik desagertarazteko
  private void desagertarazi () {
   labelMezua.setVisible(false);
   textField1.setVisible(false);
   buttonAukeratu.setVisible(false);
    buttonSend.setVisible(false);
    buttonSend.setEnabled(false);
     buttonIkusi.setVisible(false);
    buttonIkusi.setEnabled(false);
  }

    void buttonBidali_actionPerformed(ActionEvent e) {
    agertarazi();
    show();
  }

  void buttonAukeratu_actionPerformed(ActionEvent e) {
      fd = new FileDialog(this);
       fd.show();
        buttonSend.setEnabled(true);
        buttonIkusi.setEnabled(true);
  }

  // Jaso botoia sakatzerakoan exekutatzen
  // den metodoa
  void buttonJaso_actionPerformed(ActionEvent e) {
    desagertarazi();
    ekarriMezua();
  }

  void this_windowClosing(WindowEvent e) {
    System.exit(0);
  }


  // martxanJarri metodoren inplementazioa
  // honek interfazea martxan jartzen du...
  public void martxanJarri () {
	 try  {
    		  jbInit();
    		}
    		catch (Exception e) {
     		 e.printStackTrace();
	    }

	this.setSize(400,300);
	this.show();
   }

  // Hartu mezua metodoaren inplementazioa
  public String hartuMezua ()	{
	try {
      	return backend.hartuMezua();
	} catch (RemoteException re) {
		return("Errorea mezua jasotzerakoan.."+re.getMessage());
	}
 }
  // Fitxategia bidaltzeaz arduratuko den metodoa
  public void bidaliMezua (String mezu) {
	try {
      	backend.bidaliMezua(mezu);
	} catch (RemoteException re) {
		System.err.println("Errorea mezua bidaltzerakoan.."+re.getMessage());
	}
  }

  // Fitxategia jasotzeaz arduratuko den metodoa
  public String ekarriMezua ()   {
      textAreaMezua.setText("");
	try {
      textAreaMezua.appendText(backend.ekarriMezua());
	} catch (RemoteException re) {
		System.err.println("Errorea mezua ekartzerakoan.."+re.getMessage());
	}
	System.out.println("Mezua jaso da...");
	return "Mezua jaso da...";
  }

  // Send Botoia sakatzen denean
  // exekutatuko den metodoa
  void buttonSend_actionPerformed(ActionEvent e) {
    bidaliMezua(textAreaMezua.getText());
  }

  // Honen bitartez, aukeratu den fitxategia testuarean kargatzen da
  private void kargatuFitxategia (String izena) throws IOException {
	    String temp = null;
        try {
 	  DataInputStream fitx = new DataInputStream(new FileInputStream(izena));
 	     textAreaMezua.setText("");
		
 		   while (!((temp = fitx.readLine()) == null))
  		    textAreaMezua.appendText("\n"+temp);
  		  fitx.close();
	   } catch (IOException ioex) {
          System.err.println("Errorea fitxategian..."+ioex.getMessage());
        }
 }

  void buttonIkusi_actionPerformed(ActionEvent e) {

        if (fd.getFile().length() > 0)
        try {
        kargatuFitxategia(fd.getDirectory()+fd.getFile());
        } catch (IOException ioex) {
          System.err.println("Errorea fitxategian..."+ioex.getMessage());
        }
  }
}


    // FaxServiceProxy2 Klasearen BUKAERA

   // FaxServiceBackend-ren hasiera

    public FaxServiceBackend() throws IOException {
    }

    protected FaxServiceInterface createProxy() {
        try {
        		// Aktibazio-talde berri batentzat deskribatzailea sortzen
        		// da gure backend objektua bertan exekutarazteko.
            Properties props = new Properties();
            props.put("java.security.policy", "c:\\tmp\\policy");
            ActivationGroupDesc group = new ActivationGroupDesc(props, null);
            // Taldea erregistratzen da eta IDa jasotzen da.
            ActivationGroupID gid =
                ActivationGroup.getSystem().registerGroup(group);
            // Orain taldea sortzen da.
            ActivationGroup.createGroup(gid, group, 0);

            // Aktibazio deskribatzailea sortzen dugu
            // gure objektuarentzat.

            String location = "file://tilde/kedwards/java/";
            MarshalledObject data = null;
            ActivationDesc desc =
                new ActivationDesc("corejini.chapter5." +
                       "FaxServiceBackend$Backend",
                       location, data);

            // Protokolo inplementatuko duen
            // Backend objektua sortzen dugu.
            BackendProtocol backend =
                (BackendProtocol) Activatable.register(desc);
            return new FaxServiceProxy2(backend);
        } catch (RemoteException ex) {
            System.err.println("Errorea backend objektua sortzerakoan: " +
                               ex.getMessage());
            System.exit(1);
            return null;
        } catch (ActivationException ex) {
            System.err.println("Arazoa aktibazioarekin: " + ex.getMessage());
            ex.printStackTrace();
            System.exit(1);
            return null;
        }
    }

		// Zerbitzua sortu eta bere
		// Lease hria martxan jartzen dugu.
    public static void main(String args[]) {
        try {
            FaxServiceBackend hws = new FaxServiceBackend();
            hws.leaseThread = new Thread(hws);
            hws.leaseThread.start();
        } catch (IOException ex) {
            System.out.println("Ezin izan da zerbitzua sortu: " +
                               ex.getMessage());
        }
    }
}
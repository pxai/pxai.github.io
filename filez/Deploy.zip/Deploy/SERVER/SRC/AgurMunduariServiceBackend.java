// Honek, AgurMunduariService-ren luzapen bat da
// RMI erabiltzen duena aktibagarri den back-end
// prozesu batekin. Aktibagarritasuna jdk1.2tik aurrera
// RMI-n erabil daitekeen teknologia da.

package corejini.chapter5;

import java.util.Vector;
import java.util.Enumeration;
import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.Remote;
import java.rmi.MarshalledObject;
import java.rmi.RMISecurityManager;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.activation.Activatable;
import java.rmi.activation.ActivationID;
import java.rmi.activation.ActivationDesc;
import java.rmi.activation.ActivationGroup;
import java.rmi.activation.ActivationGroupID;
import java.rmi.activation.ActivationGroupDesc;
import java.rmi.activation.ActivationException;
import java.util.Properties;

public class AgurMunduariServiceBackend 
    extends AgurMunduariServiceWithLeases {
    
    // Interfaze berezia proxy (bezeroek erabiliko duten objektua) eta 
    // backend prozesuaren arteko komunikazio protokoloa definitzeko.
    interface BackendProtocol extends Remote {
        public String fetchString() throws RemoteException;
    }
    
		// Kabiatutako klase honek backend protokoloa
		// (goian inplementaturiko interfazea) inplementatzen du. 
		// Aktibagarria da, beraz
		// UnicasRemoteObjektua izanen da. 
    public static class Backend extends Activatable 
                                implements BackendProtocol {
        int nextMessage = 0;
        String[] messages = { "Agur Mundua", 
                              "Kaixo Mundua hemen nago",
                              "Zer moduz gaude??  Ondo!" };
        
        public Backend(ActivationID id, MarshalledObject data) 
            throws RemoteException {
            super(id, 0);
        }
        
        public synchronized String fetchString() throws RemoteException {
            String str =  messages[nextMessage];
            nextMessage = (nextMessage + 1) % messages.length;
            return str;
        }
        
      	// klase honek, aktibagarritasuna dela eta, lanik ez duenean
      	// 'sleep' egoerara pasako da.
    }
    
		// Orain BackendProtocol darabilen proxy klasea behar dugu.
		// Honek AgurMunduariServiceInterface  inplementatzen du
		// eta bezeroek modu gardenean erabili ahal izanen dute.
 
    static class AgurMunduariServiceProxy2 
        implements Serializable, AgurMunduariServiceInterface {
        BackendProtocol backend;
        
        public AgurMunduariServiceProxy2() {
        }
        public AgurMunduariServiceProxy2(BackendProtocol backend) {
            this.backend = backend;
        }
        public String hartuMezua() {
            try {
                return backend.fetchString();
            } catch (RemoteException ex) {
                return "Ezin izan dut backend-arekin kontaktatu: " + ex.getMessage();
            }
        }
        public long hartuDenbora() {
        	return System.currentTimeMillis();	
        }
    }
    
    public AgurMunduariServiceBackend() throws IOException {
    }
    
    protected AgurMunduariServiceInterface createProxy() {
        try {
        		// Aktibazio-talde berri batentzat deskribatzailea sortzen
        		// da gure backend objektua bertan exekutarazteko.
            Properties props = new Properties();
            props.put("java.security.policy", "c:\\tmp\\policy");
            ActivationGroupDesc group = new ActivationGroupDesc(props, null);
            // Taldea erregistratzen da eta IDa jasotzen da.
            ActivationGroupID gid = 
                ActivationGroup.getSystem().registerGroup(group);
            // Orain taldea sortzen da.
            ActivationGroup.createGroup(gid, group, 0);
            
            // Aktibazio deskribatzailea sortzen dugu
            // gure objektuarentzat.
            
            String location = "file://tilde/kedwards/java/";
            MarshalledObject data = null;
            ActivationDesc desc = 
                new ActivationDesc("corejini.chapter5." +
                       "AgurMunduariServiceBackend$Backend",
                       location, data);
            
            // Protokolo inplementatuko duen 
            // Backend objektua sortzen dugu.
            BackendProtocol backend = 
                (BackendProtocol) Activatable.register(desc);
            return new AgurMunduariServiceProxy2(backend);
        } catch (RemoteException ex) {
            System.err.println("Errorea backend objektua sortzerakoan: " +
                               ex.getMessage());
            System.exit(1);
            return null;
        } catch (ActivationException ex) {
            System.err.println("Arazoa aktibazioarekin: " + ex.getMessage());
            ex.printStackTrace();
            System.exit(1);
            return null;
        }
    }

		// Zerbitzua sortu eta bere 
		// Lease hria martxan jartzen dugu.
    public static void main(String args[]) {
        try {
            AgurMunduariServiceBackend hws = new AgurMunduariServiceBackend();
            hws.leaseThread = new Thread(hws);
            hws.leaseThread.start();
        } catch (IOException ex) {
            System.out.println("Ezin izan da zerbitzua sortu: " +
                               ex.getMessage());
        }
    }
}
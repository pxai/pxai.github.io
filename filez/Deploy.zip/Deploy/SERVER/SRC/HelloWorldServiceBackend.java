// Create an extension of the service that uses
// RMI to communicate with an activatable back-end
// process.

package corejini.chapter5;

import java.util.Vector;
import java.util.Enumeration;
import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.Remote;
import java.rmi.MarshalledObject;
import java.rmi.RMISecurityManager;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.activation.Activatable;
import java.rmi.activation.ActivationID;
import java.rmi.activation.ActivationDesc;
import java.rmi.activation.ActivationGroup;
import java.rmi.activation.ActivationGroupID;
import java.rmi.activation.ActivationGroupDesc;
import java.rmi.activation.ActivationException;
import java.util.Properties;

public class HelloWorldServiceBackend 
    extends HelloWorldServiceWithLeases {
    
    // An interface to define the remote
    // communications protocol between the
    // proxy and the backend.
    interface BackendProtocol extends Remote {
        public String fetchString() throws RemoteException;
    }
    
    // This is a nested class that implements the
    // backend protocol.  It's activatable, so it
    // is already a UnicastRemoteObject.
    public static class Backend extends Activatable 
                                implements BackendProtocol {
        int nextMessage = 0;
        String[] messages = { "Hello, World", 
                              "Goodbye, Cruel World",
                              "What's Up, Doc?" };
        
        public Backend(ActivationID id, MarshalledObject data) 
            throws RemoteException {
            super(id, 0);
        }
        
        public synchronized String fetchString() throws RemoteException {
            String str =  messages[nextMessage];
            nextMessage = (nextMessage + 1) % messages.length;
            return str;
        }
        
        // should put itself back to sleep after a while.
    }
    
    // We need a new proxy that uses the backend
    // protocol.  Since this proxy implements the
    // same HelloWorldServiceInterface as the old
    // one, clients can use it transparently.
    static class HelloWorldServiceProxy2 
        implements Serializable, HelloWorldServiceInterface {
        BackendProtocol backend;
        
        public HelloWorldServiceProxy2() {
        }
        public HelloWorldServiceProxy2(BackendProtocol backend) {
            this.backend = backend;
        }
        public String getMessage() {
            try {
                return backend.fetchString();
            } catch (RemoteException ex) {
                return "Couldn't contact back-end: " + ex.getMessage();
            }
        }
    }
    
    public HelloWorldServiceBackend() throws IOException {
    }
    
    protected HelloWorldServiceInterface createProxy() {
        try {
            // Create a descriptor for a new activation group to run our
            // backend object in.
            Properties props = new Properties();
            props.put("java.security.policy", "/tmp/policy");
            ActivationGroupDesc group = new ActivationGroupDesc(props, null);
            // Register the group and get the ID.
            ActivationGroupID gid = 
                ActivationGroup.getSystem().registerGroup(group);
            // Now create the group
            ActivationGroup.createGroup(gid, group, 0);
            
            // Create an activation descriptor
            // for our object
            String location = "file://tilde/kedwards/java/";
            MarshalledObject data = null;
            ActivationDesc desc = 
                new ActivationDesc("corejini.chapter5." +
                       "HelloWorldServiceBackend$Backend",
                       location, data);
            
            // Create the 'backend' object that will
            // implement the protocol.
            BackendProtocol backend = 
                (BackendProtocol) Activatable.register(desc);
            return new HelloWorldServiceProxy2(backend);
        } catch (RemoteException ex) {
            System.err.println("Error creating backend object: " +
                               ex.getMessage());
            System.exit(1);
            return null;
        } catch (ActivationException ex) {
            System.err.println("Problem with activation: " + ex.getMessage());
            ex.printStackTrace();
            System.exit(1);
            return null;
        }
    }

    // Create the service and start its lease
    // thread.
    public static void main(String args[]) {
        try {
            HelloWorldServiceBackend hws = new HelloWorldServiceBackend();
            hws.leaseThread = new Thread(hws);
            hws.leaseThread.start();
        } catch (IOException ex) {
            System.out.println("Couldn't create service: " +
                               ex.getMessage());
        }
    }
}

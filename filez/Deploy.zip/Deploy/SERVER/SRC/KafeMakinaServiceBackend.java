// Honek, KafeMakinaService-ren luzapen bat da
// RMI erabiltzen duena aktibagarri den back-end
// prozesu batekin. Aktibagarritasuna jdk1.2tik aurrera
// RMI-n erabil daitekeen teknologia da.

package corejini.chapter5;

import java.util.Vector;
import java.util.Enumeration;
import java.io.IOException;
import java.io.Serializable;
import java.io.DataInputStream;
import java.io.DataInput;
import java.rmi.RemoteException;
import java.rmi.Remote;
import java.rmi.MarshalledObject;
import java.rmi.RMISecurityManager;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.activation.Activatable;
import java.rmi.activation.ActivationID;
import java.rmi.activation.ActivationDesc;
import java.rmi.activation.ActivationGroup;
import java.rmi.activation.ActivationGroupID;
import java.rmi.activation.ActivationGroupDesc;
import java.rmi.activation.ActivationException;
import java.util.Properties;

public class KafeMakinaServiceBackend
    extends KafeMakinaServiceWithLeases {

    // Interfaze berezia proxy (bezeroek erabiliko duten objektua) eta
    // backend prozesuaren arteko komunikazio protokoloa definitzeko.
    interface BackendProtocol extends Remote {
         public String hartuMezua() throws RemoteException;
	   public String ordaindu(String visa,String urtea,String hilabetea) throws RemoteException;
    	   public String kafeHutsa(int azukrea) throws RemoteException;
         public String kafeEbakia(int azukrea) throws RemoteException;
         public String kafeEsnea(int azukrea) throws RemoteException;
         public String esneHutsa(int azukrea) throws RemoteException;
         public String kaputxinoa(int azukrea) throws RemoteException;

	
    }

		// Kabiatutako klase honek backend protokoloa
		// (goian inplementaturiko interfazea) inplementatzen du.
		// Aktibagarria da, beraz
		// UnicasRemoteObjektua izanen da.
    public static class Backend extends Activatable
                                implements BackendProtocol {

        public Backend(ActivationID id, MarshalledObject data)
            throws RemoteException {
            super(id, 0);
        }

	public String hartuMezua() throws RemoteException{ return "Hauxe da kalkulgailu zerbitzu Xinplea\n";}
    	public String ordaindu(String visa,String urtea,String hilabetea)	throws RemoteException {
		return "ONARTUA";	
   	}
    public String kafeHutsa(int azukrea) throws RemoteException{
	 String emaitza="Zure eskera (kafe hutsa / azukre kop="+azukrea+") egiten ari naiz";
	 return emaitza;
    }
    public String kafeEbakia(int azukrea) throws RemoteException{
	String emaitza="Zure eskera (kafe ebakia / azukre kop="+azukrea+") egiten ari naiz";
    	return emaitza;
    }
    public String kafeEsnea(int azukrea)	throws RemoteException{
	String emaitza="Zure eskera (kafe esnea / azukre kop="+azukrea+") egiten ari naiz";
    	return emaitza;
    }
    public String esneHutsa(int azukrea)	throws RemoteException{
	String emaitza="Zure eskera (esne hutsa / azukre kop="+azukrea+") egiten ari naiz";
    	return emaitza;
    }
    public String kaputxinoa(int azukrea)	throws RemoteException{
	String emaitza="Zure eskera (kaputxinoa / azukre kop="+azukrea+") egiten ari naiz";
	return emaitza;
    }

      	// klase honek, aktibagarritasuna dela eta, lanik ez duenean
      	// 'sleep' egoerara pasako da.
    }

		// Orain BackendProtocol darabilen proxy klasea behar dugu.
		// Honek KafeMakinaServiceInterface  inplementatzen du
		// eta bezeroek modu gardenean erabili ahal izanen dute.

    static class KafeMakinaServiceProxy2
        implements Serializable, KafeMakinaServiceInterface {
        BackendProtocol backend;

        public KafeMakinaServiceProxy2() {
        }
        public KafeMakinaServiceProxy2(BackendProtocol backend) {
            this.backend = backend;
        }
        public String hartuMezua() {
	  try {
                return backend.hartuMezua();
		} catch (RemoteException ex) {
		return "Errorea. hartuMezua funtzioan..\n";}
        }
	
	public String ordaindu(String visa,String urtea,String hilabetea)	{
	try {
	return backend.ordaindu(visa,urtea,hilabetea);
	} catch (RemoteException ex) {
		return "Errorea. Ordainketa prozesuan..\n";}
	}

	public String kafeHutsa(int azukrea) {
	try {
	return backend.kafeHutsa(azukrea);
	} catch (RemoteException ex) {
		return "Errorea. Kafe hutsa jartzerakoan..\n";}
	}

	public String kafeEbakia(int azukrea) {
	try {
	return backend.kafeEbakia(azukrea);
	} catch (RemoteException ex) {
		return "Errorea. Kafe ebakia jartzerakoan..\n";}
	}

	public String kafeEsnea(int azukrea) {
	try {
	return backend.kafeEsnea(azukrea);
	} catch (RemoteException ex) {
		return "Errorea. Kafe esnea jartzerakoan..\n";}
	}

    	public String esneHutsa(int azukrea) {
	try {
	return backend.esneHutsa(azukrea);
	} catch (RemoteException ex) {
		return "Errorea. Esnea hutsa jartzerakoan..\n";}
	}

	public String kaputxinoa(int azukrea) {
	try {
	return backend.kaputxinoa(azukrea);
	} catch (RemoteException ex) {
		return "Errorea. Kaputxinoa jartzerakoan..";}
	} 
	
	public void martxanJarri () throws IOException {
    	DataInput di = new DataInputStream(System.in);
    	int Aukera=1, azukrea=0;
    	String Lerroa ="0";
    	while (true) {
    		System.out.println("Aukeratu Edaria:\n\t1:Kafe Hutsa \n\t2: Kafe Ebakia\n\t3: Kafe Esnea" +
    											 "\n\t4: Esne Hutsa\n\t5: Kaputxinoa\n\t6: Hartu Mezua\n\n\t\t0: atera");
    		System.out.print("\t\t\tAukeratu");
    		Lerroa = di.readLine();
    		try {
    			Aukera = Integer.parseInt(Lerroa); 
    			if (Aukera==0) System.exit(0);
    			} catch (NumberFormatException ex1)
    			{System.out.println("Sartu zenbaki egokia, mesedez..."); Aukera=7;continue;}
    			
					System.out.println("Sartu zenbaki 1 <azukre kopurua>:");    
					Lerroa = di.readLine();
    		try {
    			azukrea = Integer.parseInt(Lerroa); 
    			} catch (NumberFormatException ex2)
    			{System.out.println("Sartu zenbaki egokia, mesedez..."); Aukera=7;continue;}
		
					 System.out.println("Kafe Makinaren erantzuna:");
    		switch (Aukera) {
    			 case 1:System.out.println(backend.kafeHutsa(azukrea));break;
    			 case 2:System.out.println(backend.kafeEbakia(azukrea));break;
    			 case 3:System.out.println(backend.kafeEsnea(azukrea));break;
    			 case 4:System.out.println(backend.esneHutsa(azukrea));break;
    			 case 5:System.out.println(backend.kaputxinoa(azukrea));break;
    			 case 6:System.out.println(backend.hartuMezua());break;
    			 case 0: System.exit(0);
    			 default : break;   			
    			}//case bukaera
    		}// while bukaera
    }//metodo bukaera



    }

    public KafeMakinaServiceBackend() throws IOException {
    }

    protected KafeMakinaServiceInterface createProxy() {
        try {
        		// Aktibazio-talde berri batentzat deskribatzailea sortzen
        		// da gure backend objektua bertan exekutarazteko.
            Properties props = new Properties();
            props.put("java.security.policy", "c:\\tmp\\policy");
            ActivationGroupDesc group = new ActivationGroupDesc(props, null);
            // Taldea erregistratzen da eta IDa jasotzen da.
            ActivationGroupID gid =
                ActivationGroup.getSystem().registerGroup(group);
            // Orain taldea sortzen da.
            ActivationGroup.createGroup(gid, group, 0);

            // Aktibazio deskribatzailea sortzen dugu
            // gure objektuarentzat.

            String location = "file://tilde/kedwards/java/";
            MarshalledObject data = null;
            ActivationDesc desc =
                new ActivationDesc("corejini.chapter5." +
                       "KafeMakinaServiceBackend$Backend",
                       location, data);

            // Protokolo inplementatuko duen
            // Backend objektua sortzen dugu.
            BackendProtocol backend =
                (BackendProtocol) Activatable.register(desc);
            return new KafeMakinaServiceProxy2(backend);
        } catch (RemoteException ex) {
            System.err.println("Errorea backend objektua sortzerakoan: " +
                               ex.getMessage());
            System.exit(1);
            return null;
        } catch (ActivationException ex) {
            System.err.println("Arazoa aktibazioarekin: " + ex.getMessage());
            ex.printStackTrace();
            System.exit(1);
            return null;
        }
    }

		// Zerbitzua sortu eta bere
		// Lease hria martxan jartzen dugu.
    public static void main(String args[]) {
        try {
            KafeMakinaServiceBackend hws = new KafeMakinaServiceBackend();
            hws.leaseThread = new Thread(hws);
            hws.leaseThread.start();
        } catch (IOException ex) {
            System.out.println("Ezin izan da zerbitzua sortu: " +
                               ex.getMessage());
        }
    }
}
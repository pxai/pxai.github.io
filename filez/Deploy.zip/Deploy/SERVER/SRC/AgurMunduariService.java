// Hauxe da AgurMunduari zerbitzua. Honek
// proxy objektu bat instalatzen deu Lookup-en
// eta bezeroek erabil dezakete AgurMunduariServiceInterface-k
// definitzen duen hartuMezua() 'zerbitzua' erabiltzeko.
// Kalse honen barruan Interfazea inplementatzen duen proxya dago alde batetik
// eta bestetik proxy hau publikatzen duen Jini zerbitzua: AgurMunduariService klasea.
package corejini.chapter5;

import net.jini.discovery.DiscoveryListener;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.LookupDiscovery;
import net.jini.core.lookup.ServiceItem;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceRegistration;
import java.util.Hashtable;
import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;

// Hauxe da bezeroek jeitsiko duten proxy objektua.
// Serializagarria da noski, eta AgurMunduariServiceInterface
// implementatzen du.
class AgurMunduariServiceProxy implements Serializable, 
    AgurMunduariServiceInterface {
    public AgurMunduariServiceProxy() {
    }
    public String hartuMezua() {
        return "Kaixo, Mundua!!!!";
    }
    public long hartuDenbora() {
        return System.currentTimeMillis();
    }

}

//AgurMunduariService "wrapper" klasea da
// zerbitzua sarean atzigarri jartzen du.
public class AgurMunduariService implements Runnable {
    // 10 minututako 'lease'a
    protected final int LEASE_TIME = 10 * 60 * 1000; 
    protected Hashtable registrations = new Hashtable();
    protected ServiceItem item;
    protected LookupDiscovery disco;
    
    // "Inner" klasea discovery gertaerak entzuteko 
    class Listener implements DiscoveryListener {
        // Lookup zerbitzua topatzerakoan deitzen den klasea.
        public void discovered(DiscoveryEvent ev) {
            System.out.println("Discovery: arrakasta!\nLookup zerbitzua topatua!");
            ServiceRegistrar[] newregs = ev.getRegistrars();
            for (int i=0 ; i<newregs.length ; i++) {
                if (!registrations.containsKey(newregs[i])) {
                    registerWithLookup(newregs[i]);
                }
            }
        }

        // Funtzio hau bakarrarik zerbitzu bat esplizituki
        // kendu nahi dugunean (ez zerbitzu bat "erortzen"
        // denean automatikoki. Behin "discovery" egiterakoan
        // ez dago ongoing komunikaziorik lookup zerbitzuarekin. 
        public void discarded(DiscoveryEvent ev) {
            ServiceRegistrar[] deadregs = ev.getRegistrars();
            for (int i=0 ; i<deadregs.length ; i++) {
                registrations.remove(deadregs[i]);
            }
        }
    }

    public AgurMunduariService() throws IOException {
        item = new ServiceItem(null, createProxy(), null);
        
        // Segurtasun kudeatzaile bat martxan jartzen da.
        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new RMISecurityManager());
        }
        
        // "public" taldea bilatzen da, konbentzioz
        // ""-z adierazten dena.
        disco = new LookupDiscovery(new String[] { "" });
        
        // Entzule bat jartzen da.
        disco.addDiscoveryListener(new Listener());
    }
    
    protected AgurMunduariServiceInterface createProxy() {
        return new AgurMunduariServiceProxy();
    }
    

    // Lan honetarko ezinbestekoa da urrutiko deia edo
    // 'remote call' bat jasotzea Lookup bat toptzen dela
    // jakiteko, eta denbora pixkat beharko da.
    protected synchronized void registerWithLookup(ServiceRegistrar registrar) {
        ServiceRegistration registration = null;

        try {
            registration = registrar.register(item, LEASE_TIME);
        } catch (RemoteException ex) {
            System.out.println("Ezin izan da registratu: " + ex.getMessage());
            return;
        }
        
        // Lehenbiziko aldiz erregistratzen bada zerbitzua
        // 'service ID' bat jasoko du (128 biteko zorizko balioa, munduan bakarra) 
        // Zerbitzu 'ON' batek ID hori gorde beharko luke beti erabiltzeko.
        if (item.serviceID == null) {
            item.serviceID = registration.getServiceID();
            System.out.println("Zerbitzu-IDa : serviceID:" + item.serviceID);
        }
        
        registrations.put(registrar, registration);
    }
    
    // Hari honen bitartez ez dugu ezer egiten, baino ziurtatzen
    // dugu zerbitzua martxan egonen dela Lookup bat bilatzen duen
    // bitartean, JVMtik atera gabe. 
    public void run() {
        while (true) {
            try {
                Thread.sleep(1000000);
            } catch (InterruptedException ex) {
            }
        }
    }
    
    // AgurMunduariService berria sortu eta bere 
    // haria hasieratu.
    public static void main(String args[]) {
        try {
            AgurMunduariService hws = new AgurMunduariService();
            new Thread(hws).start();
        } catch (IOException ex) {
            System.out.println("Ezin izan dut zerbitzua sortu!:" +
                               ex.getMessage());
        }
    }
}
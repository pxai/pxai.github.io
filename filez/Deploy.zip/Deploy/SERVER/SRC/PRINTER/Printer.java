// This is the interface that the proxy implements.

package corejini.chapter13;

import java.rmi.RemoteException;

public interface Printer {
    public void print(int format, int copies, Object data,
                      PrintListener listener)
        throws RemoteException;
}



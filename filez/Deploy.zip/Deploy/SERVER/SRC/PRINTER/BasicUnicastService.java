// A class to use as a superclass for RMI-based services.

package corejini.chapter13;

import net.jini.core.lease.*;
import net.jini.core.lookup.*;
import net.jini.core.entry.*;
import net.jini.core.discovery.*;
import com.sun.jini.lookup.*;
import com.sun.jini.lease.*;
import java.rmi.*;
import java.rmi.server.*;
import java.io.*;
import java.lang.reflect.*;

public abstract class BasicUnicastService extends UnicastRemoteObject 
    implements ServiceIDListener {
    protected JoinManager joinManager;
    protected String storageLoc;
    protected File file = null;
    protected ServiceID serviceID = null;
    protected LeaseRenewalManager leaseManager;
    protected RestoreListener restoreListener = null;
    protected Object proxy = null;

    // Store data for crash recovery
    static class PersistentData implements Serializable {
        ServiceID serviceID;
        Entry[] attrs;
        String[] groups;
        LookupLocator[] locs;
        Object subclassData;
        
        PersistentData(ServiceID serviceID, Entry[] attrs, String[] groups,
                       LookupLocator[] locs, Object subclassData) {
            this.serviceID = serviceID;
            this.attrs = attrs;
            this.groups = groups;
            this.locs = locs;
            this.subclassData = subclassData;
        }
    }
    
    // subclasses that want to be informed after a restore should implement
    // this
    public interface RestoreListener {
        public void restored(Object subclassData);
    }
    
    public BasicUnicastService(String storageLoc) throws RemoteException {
        super();
        
        this.storageLoc = storageLoc;
        file = new File(storageLoc);
    }
    
    // administration will call this to shutdown.  clients can override.
    protected void shutdown() {
        System.exit(1);
    }
    
    protected abstract Object getProxy();
    
    // subclasses override to return initial attributes
    protected Entry[] getAttributes() {
        return new Entry[0];
    }
    
    public void serviceIDNotify(ServiceID id) {
        serviceID = id;
        try {
            checkpoint();
        } catch (IOException ex) {
            System.err.println("Trouble checkpointing: " +
                               ex.getMessage());
        }
    }
    
    protected void checkpoint() throws IOException {
        checkpoint(null);
    }
    protected void checkpoint(Object subclassData) throws IOException {
        PersistentData data;
        
        data = new PersistentData(serviceID,
                                  joinManager.getAttributes(),
                                  joinManager.getGroups(),
                                  joinManager.getLocators(),
                                  subclassData);
        
        ObjectOutputStream out = new
            ObjectOutputStream(new FileOutputStream(file));
        
        out.writeObject(data);
        out.flush();
        out.close();
    }
    
    // restore should *only* be called once, at startup.
    protected void restore() throws IOException, ClassNotFoundException {
        ObjectInputStream in = new
            ObjectInputStream(new FileInputStream(file));
        PersistentData data = 
            (PersistentData) in.readObject();
        
        if (data == null) {
            System.err.println("No data in storage file.");
        } else {
            System.out.println("Restoring!");
            serviceID = data.serviceID;
            leaseManager = new LeaseRenewalManager();
            joinManager = new JoinManager(data.serviceID, proxy,
                                          data.attrs, data.groups,
                                          data.locs, leaseManager);
            if (restoreListener != null) {
                System.out.println("Calling restore listener!");
                restoreListener.restored(data.subclassData);
            } else {
                System.out.println("No restore listener");
            }
        }
    }

    // subclasses override this to do their own initialization behavior.
    protected void initialize() throws IOException, ClassNotFoundException {
        if (this instanceof RestoreListener) {
            restoreListener = (RestoreListener) this;
        }

        proxy = getProxy();
        
        if (file.exists()) {
            restore();
        }
        
        if (joinManager == null) {
            leaseManager = new LeaseRenewalManager();
            joinManager = new JoinManager(proxy, getAttributes(), 
                                          this, leaseManager);
        }
    }
    
    // subclasses write a main that creates a subclass of B-U-S and
    // calls initialize() on it, then waits.
}

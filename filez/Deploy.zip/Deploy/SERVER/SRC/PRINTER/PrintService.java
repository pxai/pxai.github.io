// This is the actual print service back-end.

package corejini.chapter13;

import java.awt.print.*;
import java.io.*;
import java.util.*;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.*;
import net.jini.core.lease.*;
import net.jini.core.lookup.*;
import net.jini.core.entry.*;
import net.jini.core.discovery.*;
import com.sun.jini.lookup.*;
import net.jini.admin.JoinAdmin;
import com.sun.jini.admin.DestroyAdmin;
import com.sun.jini.admin.StorageLocationAdmin;
import net.jini.lookup.entry.*;

public class PrintService extends BasicUnicastService
    implements RemotePrinter, BasicUnicastService.RestoreListener {
    protected Vector queue = new Vector();
    protected Hashtable agents = new Hashtable();
    protected PrintThread printThread;
    protected boolean done = false;
    protected PrintRecord currentRecord = null;
    protected PrintAdmin remoteAdmin = null;
    protected long lastEventSeqNo = 0;

    // Print-service specific persistent data
    static class PrintServiceData implements Serializable {
        PrintRecord currentRecord;
        Vector queue;
        long lastEventSeqNo;
        
        PrintServiceData(PrintRecord currentRecord,
                         Vector queue, long lastEventSeqNo) {
            this.currentRecord = currentRecord;
            this.queue = queue;
            this.lastEventSeqNo = lastEventSeqNo;
        }
    }
    
    // internal bookkeeping for recording print jobs
    static class PrintRecord implements Serializable {
        int format;
        int copies;
        Object data;
        Object agent;
        PrintListener listener;
        
        PrintRecord(int format, int copies, Object data,
                    Object agent, PrintListener listener) {
            this.format = format;
            this.copies = copies;
            this.data = data;
            this.agent = agent;
            this.listener = listener;
        }
    }
    
    // user-visible representation of a job
    public static class JobRecord implements Serializable {
        boolean current;
        int format;
        int copies;
        String dataName;
        int jobid;
        
        JobRecord(PrintRecord rec, boolean current) {
            this.current = current;
            this.format = rec.format;
            this.copies = rec.copies;
            this.dataName = rec.data.toString();
            this.jobid = rec.hashCode();
        }
        public boolean getCurrent() {
            return current;
        }
        public int getFormat() {
            return format;
        }
        public int getCopies() {
            return copies;
        }
        public String getDataName() {
            return dataName;
        }
        public int getJobID() {
            return jobid;
        }
        public String toString() {
            StringBuffer buf = new StringBuffer();

            if (current) {
                buf.append("[CURRENT] ");
            }
            switch (format) {
            case PageFormat.PORTRAIT:
                buf.append("portrait, ");
                break;
            case PageFormat.LANDSCAPE:
                buf.append("landscape, ");
                break;
            case PageFormat.REVERSE_LANDSCAPE:
                buf.append("reverse, ");
                break;
            }
            buf.append(copies + " copies, ");
            buf.append(dataName);
            
            return buf.toString();
        }
    }
    
    /// override to get correct shutdown behavior
    protected void shutdown() {
        done = true;
        notify();
        super.shutdown();
    }

    // This is the union of the administrative interfaces we
    // implement
    interface RemotePrintAdmin extends BasicUnicastAdmin.RemoteUnicastAdmin,
        PrintAdmin, Remote {
    }

    // An implementation of RemotePrintAdmin, using our
    // administration toolkit.
    class PrintAdminImpl extends BasicUnicastAdmin
        implements RemotePrintAdmin {
        PrintAdminImpl(PrintService s) throws RemoteException {
            super(s);
        }
        public Vector getJobs() {
            Vector jobs = new Vector();
            synchronized (PrintService.this) {
                if (currentRecord != null) {
                    jobs.addElement(new JobRecord(currentRecord, true));
                }
            
                for (int i=0, size=queue.size() ; i<size ; i++) {
                    jobs.addElement(new JobRecord((PrintRecord) 
                                                  queue.elementAt(i), 
                                                  false));
                }
            }
            return jobs;
        }
    }
    
    public PrintService(String storageLoc) throws RemoteException {
        super(storageLoc);
    }
    
    // override base implementation to also save PrintServiceData
    protected void checkpoint() throws IOException {
        checkpoint(new PrintServiceData(currentRecord, queue,
                                        lastEventSeqNo));
    }
    
    // override base implementation
    protected void initialize() throws IOException, ClassNotFoundException {
        super.initialize();
        
        printThread = new PrintThread();
        printThread.start();
    }

    // override base implementation
    protected Entry[] getAttributes() {
        Entry[] entries = new Entry[2];
        entries[0] = new ServiceInfo("Prentice-Hall",
                                     "PrintService",
                                     "PrintService",
                                     null,
                                     "Prentice-Hall",
                                     "v1.0");
        entries[1] = new PrintAdminPanel();
        return entries;
    }
    
    // override base implementation
    protected Object getProxy() {
        return new PrintProxy(this);
    }
    
    // implement RestoreListener
    public void restored(Object subclassData) {
        PrintServiceData data = (PrintServiceData) subclassData;
        currentRecord = data.currentRecord;
        queue = data.queue;
        lastEventSeqNo = data.lastEventSeqNo;
        System.out.println("Restore listener!");
    }
    
    public void print(int format, int copies, Object data, 
                      PrintListener listener) {
        Object agent = getPrintAgent(data);
        PrintRecord record = new PrintRecord(format, copies, data,
                                             agent, listener);
        queuePrinting(record);
    }
    
    public Object getAdmin() throws RemoteException {
        if (remoteAdmin == null) {
            remoteAdmin = new PrintAdminImpl(this);
        }
            
        return remoteAdmin;
    }
    
    Object getPrintAgent(Object data) {
        if (data instanceof Printable) {
            System.out.println("Data is printable");
            return data;
        }
        if (data instanceof Pageable) {
            System.out.println("Data is pageable");
            return data;
        }
        
        // build a list of data's classes and search for
        // them, most specific to least.
        System.out.println("Looking for print agent for " + data.getClass().getName());
        Vector classes = getClasses(data);
        
        for (int i=0, size=classes.size() ; i<size ; i++) {
            Object o = agents.get(classes.elementAt(i));
            if (o != null) {
                System.out.println("Found printer for " +
                                   ((Class) classes.elementAt(i)).getName());
                return o;
            }
        }
        
        System.out.println("No printer found");
        return null;
    }
    
    Vector getClasses(Object data) {
        Vector classes = new Vector();
        Class nextClass = data.getClass();
        
        while (nextClass != null) {
            classes.addElement(nextClass);
            Class[] interfaces = nextClass.getInterfaces();
            for (int i=0, size=interfaces.length ; i<size ; i++) {
                classes.addElement(interfaces[i]);
            }
            
            nextClass = nextClass.getSuperclass();
        }
        
        return classes;
    }
    
    void queuePrinting(PrintRecord record) {
        queue.addElement(record);
        try {
            checkpoint();
        } catch (IOException ex) {
            System.err.println("Trouble checkpointing; couldn't save job: " +
                               ex.getMessage());
        }
        System.out.println("Printing queueued, thread being notified...");
        
        synchronized(this) {
            notify();
        }
    }

    // PrintThread handles the actual mechanics of job management
    // and printing
    class PrintThread extends Thread {
        public void run() {
            System.out.println("PrintThread cranking...");
            while (!done) {
                PrintRecord record = null;
                
                System.out.println("Waiting for lock to dequeue");
                //
                // Grab the next item off the queue.  Check
                // currentRecord, since we may be initialized
                // with a print job in-progress after a restore.
                //
                if (currentRecord == null) {
                    synchronized (PrintService.this) {
                        System.out.println("Dequeueing...");
                        if (queue.size() != 0) {
                            record = (PrintRecord) queue.elementAt(0);
                            currentRecord = record;
                            queue.removeElementAt(0);
                            try {
                                checkpoint();
                            } catch (IOException ex) {
                                System.out.println("Couldn't checkpoint; " +
                                                   "job not saved: " +
                                                   ex.getMessage());
                            }
                        }
                    }
                } else {
                    record = currentRecord;
                }
                
                //
                // Print it, if we have something to print.
                //
                if (record != null) {
                    Exception ex = printRecord(record);
                    if (record.listener != null) {
                        PrintServiceEvent ev = 
                            new PrintServiceEvent((PrintProxy) proxy, 
                                                  lastEventSeqNo++, 
                                                  ex);
                        System.out.println("Sending event from proxy " +
                                           proxy);
                        try {
                            record.listener.notify(ev);
                        } catch (Exception ex2) {
                            System.err.println("Trouble sending event: " +
                                               ex2.getMessage());
                        }
                    }
                    currentRecord = null;
                    try {
                        checkpoint();
                    } catch (IOException ex2) {
                        System.out.println("Couldn't checkpoint; " +
                                           "job not saved: " +
                                           ex2.getMessage());
                    }
                }
                
                //
                // Wait for more stuff on the queue...
                //
                if (queue.size() > 0)
                    continue;
                
                System.out.println("Waiting for lock to wait");
                synchronized(PrintService.this) {
                    try {
                        System.out.println("waiting...");
                        PrintService.this.wait();
                    } catch (InterruptedException ex) {
                        System.out.println("interrupted...");
                    }
                }
                
                System.out.println("Waking up!  Something to print!");
            }
            System.out.println("Shutting down print thread...");
        }
        
        Exception printRecord(PrintRecord record) {
            Exception ex = null;
            System.out.println("Printing data " + record.data);
            
            PageFormat format = new PageFormat();
            format.setOrientation(record.format);
            
            PrinterJob job = PrinterJob.getPrinterJob();
            job.setCopies(record.copies);
            job.defaultPage(format);
            
            if (record.agent instanceof Pageable) {
                System.out.println("Printing to a pageable agent!");
                job.setPageable((Pageable) record.agent);
                try {
                    job.print();
                } catch (Exception ex2) {
                    ex = ex2;
                }
            } else if (record.agent instanceof Printable) {
                System.out.println("Printing to a printable agent!");
                job.setPrintable((Printable) record.agent, format);
                try {
                    job.print();
                } catch (Exception ex2) {
                    ex = ex2;
                }
            } else {
                System.out.println("BOGUS!  Agent is useless!");
                ex = new IllegalArgumentException("Bad agent");
            }
            
            return ex;
        }
    }
    
    public static void main(String[] args) {
        try {
            if (args.length != 1) {
                System.err.println("Usage: PrintService <datafile>");
                System.exit(1);
            }
            
            PrintService service = new PrintService(args[0]);
            service.initialize();
            System.out.println("Print Service Started");
        } catch (Exception ex) {
            System.err.println("Error starting print service: " +
                               ex.getMessage());
            System.exit(1);
        }
    }
}


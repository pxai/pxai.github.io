// This is the interface that the proxy uses to communicate with the
// service's back end.

package corejini.chapter13;

import java.rmi.Remote;
import java.rmi.RemoteException;
import net.jini.admin.Administrable;

public interface RemotePrinter extends Remote, Administrable {
    public void print(int format, int copies, Object data,
                      PrintListener listener) 
        throws RemoteException;
}

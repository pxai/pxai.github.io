// A Remote event listener for print events

package corejini.chapter13;

import net.jini.core.event.RemoteEventListener;

public interface PrintListener extends RemoteEventListener {
}


// A user interface for PrintAdmin objects.

package corejini.chapter13;

import net.jini.core.entry.Entry;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;
import java.rmi.RemoteException;

public class PrintAdminPanel extends JPanel implements Entry {
    public PrintAdminPanel() {
        super();
    }
    
    public void setAdmin(final PrintAdmin admin) {
        setLayout(new BorderLayout());
        add(new JLabel("Current Print Jobs"), "North");
        
        final JList list = new JList();
        add(list, "Center");
        
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                Vector jobs = null;
                try {
                    jobs = admin.getJobs();
                    System.out.println("Got back " + jobs.size() + " jobs");
                } catch (RemoteException ex) {
                    System.err.println("Error getting jobs: " +
                                       ex.getMessage());
                }
                list.setListData(jobs);
            }
        });
        
        add(refreshButton, "South");
        
        refreshButton.doClick();
    }
}

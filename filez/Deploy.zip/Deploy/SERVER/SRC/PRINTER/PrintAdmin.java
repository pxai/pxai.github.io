// A Simple interface for printer administration.

package corejini.chapter13;

import java.util.Vector;
import java.rmi.RemoteException;

public interface PrintAdmin {
    public Vector getJobs() throws RemoteException;
}

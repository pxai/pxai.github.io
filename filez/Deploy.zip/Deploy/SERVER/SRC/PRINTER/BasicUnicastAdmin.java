// A class for handling common administrative chores.

package corejini.chapter13;

import com.sun.jini.lookup.JoinManager;
import net.jini.admin.JoinAdmin;
import com.sun.jini.admin.DestroyAdmin;
import com.sun.jini.admin.StorageLocationAdmin;
import net.jini.core.entry.Entry;
import net.jini.core.discovery.LookupLocator;
import java.rmi.*;
import java.rmi.server.*;
import java.io.*;


public class BasicUnicastAdmin extends UnicastRemoteObject
    implements BasicUnicastAdmin.RemoteUnicastAdmin {
    protected BasicUnicastService service;
    
    interface RemoteUnicastAdmin extends JoinAdmin, DestroyAdmin,
        StorageLocationAdmin, Remote {
    }
    
    protected BasicUnicastAdmin(BasicUnicastService service) 
        throws RemoteException {
        super();
        this.service = service;
    }
    
    public synchronized void destroy() {
        File locFile = new File(service.storageLoc);
        service.joinManager.terminate();
        locFile.delete();
        service.shutdown();
    }
    
    public synchronized void setStorageLocation(String loc) 
        throws RemoteException {
        try {
            File newLocFile = new File(loc);
            File oldLocFile = new File(service.storageLoc);
                
            BufferedReader reader =
                new BufferedReader(new FileReader(oldLocFile));
            BufferedWriter writer =
                new BufferedWriter(new FileWriter(newLocFile));
                
            char[] buffer = new char[1024];
            int n;
            while ((n = reader.read(buffer)) > 0) {
                writer.write(buffer, 0, n);
            }
            reader.close();
            writer.close();
                
            service.storageLoc = loc;
            oldLocFile.delete();
        } catch (IOException ex) {
            throw new RemoteException(ex.toString());
        }
    }
    public String getStorageLocation() {
        return service.storageLoc;
    }
    public Entry[] getLookupAttributes() {
        return service.joinManager.getAttributes();
    }
    public void addLookupAttributes(Entry[] attrs)
        throws RemoteException {
        service.joinManager.addAttributes(attrs, true);
        try {
            service.checkpoint();
        } catch (IOException ex) {
            throw new RemoteException(ex.toString());
        }
    }
    public void modifyLookupAttributes(Entry[] tmpls,
                                       Entry[] attrs)
        throws RemoteException {
        service.joinManager.modifyAttributes(tmpls, attrs, true);
        try {
            service.checkpoint();
        } catch (IOException ex) {
            throw new RemoteException(ex.toString());
        }
    }
    public String[] getLookupGroups() {
        return service.joinManager.getGroups();
    }
    public void addLookupGroups(String[] groups) 
        throws RemoteException {
        try {
            service.joinManager.addGroups(groups);
        } catch (IOException ex) {
        }
        try {
            service.checkpoint();
        } catch (IOException ex) {
            throw new RemoteException(ex.toString());
        }
    }
    public void removeLookupGroups(String[] groups) 
        throws RemoteException {
        try {
            service.joinManager.removeGroups(groups);
        } catch (IOException ex) {
        }
        try {
            service.checkpoint();
        } catch (IOException ex) {
            throw new RemoteException(ex.toString());
        }
    }
    public void setLookupGroups(String[] groups)
        throws RemoteException {
        try {
            service.joinManager.setGroups(groups);
        } catch (IOException ex) {
        }
        try {
            service.checkpoint();
        } catch (IOException ex) {
            throw new RemoteException(ex.toString());
        }
    }
    public LookupLocator[] getLookupLocators() {
        return service.joinManager.getLocators();
    }
    public void addLookupLocators(LookupLocator[] locs) 
        throws RemoteException {
        service.joinManager.addLocators(locs);
        try {
            service.checkpoint();
        } catch (IOException ex) {
            throw new RemoteException(ex.toString());
        }
    }
    public void removeLookupLocators(LookupLocator[] locs) 
        throws RemoteException {
        service.joinManager.removeLocators(locs);
        try {
            service.checkpoint();
        } catch (IOException ex) {
            throw new RemoteException(ex.toString());
        }
    }
    public void setLookupLocators(LookupLocator[] locs)
        throws RemoteException {
        service.joinManager.setLocators(locs);
        try {
            service.checkpoint();
        } catch (IOException ex) {
            throw new RemoteException(ex.toString());
        }
    }
}

// Honek, BideoaService-ren luzapen bat da
// RMI erabiltzen duena aktibagarri den back-end
// prozesu batekin. Aktibagarritasuna jdk1.2tik aurrera
// RMI-n erabil daitekeen teknologia da.

package corejini.chapter5;

import java.util.Vector;
import java.util.Enumeration;
import java.io.IOException;
import java.io.Serializable;
import java.io.DataInputStream;
import java.io.DataInput;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.rmi.Remote;
import java.rmi.MarshalledObject;
import java.rmi.RMISecurityManager;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.activation.Activatable;
import java.rmi.activation.ActivationID;
import java.rmi.activation.ActivationDesc;
import java.rmi.activation.ActivationGroup;
import java.rmi.activation.ActivationGroupID;
import java.rmi.activation.ActivationGroupDesc;
import java.rmi.activation.ActivationException;
import java.util.Properties;
import java.awt.*;
import java.awt.event.*;


public class BideoaServiceBackend
    extends BideoaServiceWithLeases {

    // Interfaze berezia proxy (bezeroek erabiliko duten objektua) eta
    // backend prozesuaren arteko komunikazio protokoloa definitzeko.
    interface BackendProtocol extends Remote {
         public String hartuMezua() throws RemoteException;
         public void martxanJarri() throws RemoteException;
          public void balioakGorde(String balioa) throws RemoteException;
    }


		// Kabiatutako klase honek backend protokoloa
		// (goian inplementaturiko interfazea) inplementatzen du.
		// Aktibagarria da, beraz
		// UnicasRemoteObjektua izanen da.
    public static class Backend extends Activatable
                                implements BackendProtocol {

        public Backend(ActivationID id, MarshalledObject data)
            throws RemoteException {
            super(id, 0);
        }

	      public String hartuMezua() throws RemoteException{
        return "Hauxe da kalkulgailu zerbitzu Xinplea\n";}

        public void martxanJarri() throws RemoteException {};

        public void balioakGorde (String balioa) throws RemoteException {
          try {
          PrintWriter bideoa = new PrintWriter(new FileOutputStream("c:\\bideo-programa"));
          bideoa.println(balioa);
          bideoa.close();
          } catch (IOException ioex) {
           System.err.println("Errorea:"+ioex.getMessage());
          }
        }
      	// klase honek, aktibagarritasuna dela eta, lanik ez duenean
      	// 'sleep' egoerara pasako da.
    }

    // BideoaServiceProxy2 Klasea

    static class BideoaServiceProxy2
extends Frame
implements Serializable, BideoaServiceInterface {

  BackendProtocol backend;
  BorderLayout borderLayout1 = new BorderLayout();
  Panel panelBeheko = new Panel();
  Label label1 = new Label();
  Panel panelErdiko = new Panel();
  FlowLayout flowLayout1 = new FlowLayout();
  Button buttonReset = new Button();
  Button buttonKantzel = new Button();
  Button buttonGorde = new Button();
  Choice choiceKanala = new Choice();
  Choice choiceUrtea = new Choice();
  Choice choiceHila = new Choice();
  Choice Eguna = new Choice();
  Choice choiceHasiOrdu = new Choice();
  Choice choiceHasiMinutu = new Choice();
  Choice choiceBukaOrdu = new Choice();
  Choice choiceBukaMinutu = new Choice();
  GridLayout gridLayout1 = new GridLayout();

  public String hartuMezua () {
    try {
          return backend.hartuMezua();
        } catch (RemoteException re) {
        return "Errorea balioakGorde() funtzioan...\n";
        }
  }

  public void martxanJarri() {
     try  {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  try {
          backend.martxanJarri();
        } catch (RemoteException re) {
        System.err.println("Errorea martxanJarri() funtzioan...\n");
        }

  }

  public void balioakGorde (String balioa) throws RemoteException {
    try {
          backend.balioakGorde(balioa);
        } catch (RemoteException re) {
        System.err.println("Errorea hartuMezua() funtzioan...\n");
        }

  }

  public static void main (String args[]) {
   BideoaServiceProxy2 bsp2= new BideoaServiceProxy2();
  }


  public BideoaServiceProxy2() {

  }

  public BideoaServiceProxy2(BackendProtocol backend) {
    this.backend = backend;

  }

  private boolean konprobatuChoiceak() {
          return (!(
          choiceKanala.getSelectedItem().startsWith("Aukeratu kanala") ||
          choiceUrtea.getSelectedItem().startsWith("Aukeratu urtea") ||
          choiceHila.getSelectedItem().startsWith("Aukeratu hilabetea") ||
          Eguna.getSelectedItem().startsWith("Aukeratu eguna") ||
          choiceHasiOrdu.getSelectedItem().startsWith("Aukeratu hasiera ordua") ||
          choiceHasiMinutu.getSelectedItem().startsWith("Aukeratu hasiera minutua") ||
          choiceBukaOrdu.getSelectedItem().startsWith("Aukeratu bukaera ordua") ||
          choiceBukaMinutu.getSelectedItem().startsWith("Aukeratu bukaera minutua")));
  }
  private void hasieratuChoiceak() {
          int i,j,k;
          choiceKanala.addItem("Aukeratu kanala");
          choiceUrtea.addItem("Aukeratu urtea");
          choiceHila.addItem("Aukeratu hilabetea");
          Eguna.addItem("Aukeratu eguna");
          choiceHasiOrdu.addItem("Aukeratu hasiera ordua");
          choiceHasiMinutu.addItem("Aukeratu hasiera minutua");
          choiceBukaOrdu.addItem("Aukeratu bukaera ordua");
          choiceBukaMinutu.addItem("Aukeratu bukaera minutua");

          for (i=0;i<60;i++) {
              choiceHasiMinutu.addItem(Integer.toString(i));
              choiceBukaMinutu.addItem(Integer.toString(i));
              choiceKanala.addItem(Integer.toString(i));
          }
          for (j=0;j<24;j++) {
              choiceHasiOrdu.addItem(Integer.toString(j));
              choiceBukaOrdu.addItem(Integer.toString(j));
              choiceKanala.addItem(Integer.toString(i+j));
          }
          for (k=1999;k<2051;k++)
              choiceUrtea.addItem(Integer.toString(k));
          for (i=1;i<31;i++) {
              Eguna.addItem(Integer.toString(i));
          }
          for (j=1;j<13;j++) {
              choiceHila.addItem(Integer.toString(j));
          }
  }

  private void jbInit() throws Exception{
    hasieratuChoiceak();
    this.setLayout(borderLayout1);
    this.setBackground(Color.lightGray);
    this.setTitle("BideoServiceProxy Interface");
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
    borderLayout1.setVgap(10);
    panelBeheko.setBackground(Color.lightGray);
    borderLayout1.setHgap(10);
    label1.setAlignment(1);
    label1.setText("Bideoa programatzeko zerbitzua");
    panelErdiko.setLayout(gridLayout1);
    buttonReset.setLabel("RESET");
    buttonKantzel.setLabel("KANTZEL");
    buttonKantzel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonKantzel_actionPerformed(e);
      }
    });
    buttonGorde.setLabel("GORDE");
    buttonGorde.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonGorde_actionPerformed(e);
      }
    });
    gridLayout1.setRows(4);
    gridLayout1.setHgap(40);
    gridLayout1.setColumns(2);
    panelBeheko.setLayout(flowLayout1);
    this.add(panelBeheko, BorderLayout.SOUTH);
    panelBeheko.add(buttonGorde, null);
    panelBeheko.add(buttonReset, null);
    panelBeheko.add(buttonKantzel, null);
    this.add(label1, BorderLayout.NORTH);
    this.add(panelErdiko, BorderLayout.CENTER);
    panelErdiko.add(choiceKanala, null);
    panelErdiko.add(choiceUrtea, null);
    panelErdiko.add(choiceHila, null);
    panelErdiko.add(Eguna, null);
    panelErdiko.add(choiceHasiOrdu, null);
    panelErdiko.add(choiceHasiMinutu, null);
    panelErdiko.add(choiceBukaOrdu, null);
    panelErdiko.add(choiceBukaMinutu, null);
    this.setSize(400,300);
    this.show();
  }


  void this_windowClosing(WindowEvent e) {
    System.out.println("Leihoa ixten...");
    System.exit(0);
  }

  void buttonKantzel_actionPerformed(ActionEvent e) {
     System.out.println("Leihoa ixten...");
    System.exit(0);
  }

  private String sortuMezua () {

   return ("Kanala: "+choiceKanala.getSelectedItem() +"\n"
          +"Urtea: "+choiceUrtea.getSelectedItem() +"\n"
          +"Hilabetea: "+choiceHila.getSelectedItem() +"\n"
          +"Eguna: "+Eguna.getSelectedItem() +"\n"
          +"Hasiera Ordua: "+choiceHasiOrdu.getSelectedItem() +"\n"
          +"Hasiera Minutua: "+choiceHasiMinutu.getSelectedItem() +"\n"
          +"Bukaera ordua: "+choiceBukaOrdu.getSelectedItem() +"\n"
          +"Bukaera Minutua: "+choiceBukaMinutu.getSelectedItem() +"\n");

  }
  void buttonGorde_actionPerformed(ActionEvent e) {
    if (konprobatuChoiceak())      {
        try {
        balioakGorde(sortuMezua());
         } catch (RemoteException re) {
        System.err.println("Errorea balioak bideoan gordetzerkoan..\n");
        }
       System.out.println("Balioa bideoan gordetzen...");
       System.exit(0);
       }
    else {
        try {
        balioakGorde("Errorea balioetan!!\n"+sortuMezua());
         } catch (RemoteException re2) {
        System.err.println("Errorea balioak bideoan gordetzerkoan..\n");
        }
    }
  }

  public void windowClosing(WindowEvent e) {
    dispose();
  }



}


   // BideoaServiceBackend-ren hasiera

    public BideoaServiceBackend() throws IOException {
    }

    protected BideoaServiceInterface createProxy() {
        try {
        		// Aktibazio-talde berri batentzat deskribatzailea sortzen
        		// da gure backend objektua bertan exekutarazteko.
            Properties props = new Properties();
            props.put("java.security.policy", "c:\\tmp\\policy");
            ActivationGroupDesc group = new ActivationGroupDesc(props, null);
            // Taldea erregistratzen da eta IDa jasotzen da.
            ActivationGroupID gid =
                ActivationGroup.getSystem().registerGroup(group);
            // Orain taldea sortzen da.
            ActivationGroup.createGroup(gid, group, 0);

            // Aktibazio deskribatzailea sortzen dugu
            // gure objektuarentzat.

            String location = "file://tilde/kedwards/java/";
            MarshalledObject data = null;
            ActivationDesc desc =
                new ActivationDesc("corejini.chapter5." +
                       "BideoaServiceBackend$Backend",
                       location, data);

            // Protokolo inplementatuko duen
            // Backend objektua sortzen dugu.
            BackendProtocol backend =
                (BackendProtocol) Activatable.register(desc);
            return new BideoaServiceProxy2(backend);
        } catch (RemoteException ex) {
            System.err.println("Errorea backend objektua sortzerakoan: " +
                               ex.getMessage());
            System.exit(1);
            return null;
        } catch (ActivationException ex) {
            System.err.println("Arazoa aktibazioarekin: " + ex.getMessage());
            ex.printStackTrace();
            System.exit(1);
            return null;
        }
    }

		// Zerbitzua sortu eta bere
		// Lease hria martxan jartzen dugu.
    public static void main(String args[]) {
        try {
            BideoaServiceBackend hws = new BideoaServiceBackend();
            hws.leaseThread = new Thread(hws);
            hws.leaseThread.start();
        } catch (IOException ex) {
            System.out.println("Ezin izan da zerbitzua sortu: " +
                               ex.getMessage());
        }
    }
}
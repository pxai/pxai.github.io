// Hauxe da KafeMakina zerbitzua. Honek
// proxy objektu bat instalatzen deu Lookup-en
// eta bezeroek erabil dezakete KafeMakinaServiceInterface-k
// definitzen duituen kafeEsnea, kafeHutsa,... 'zerbitzuak' erabiltzeko.
// Klase honen barruan Interfazea inplementatzen duen proxya dago alde batetik
// eta bestetik proxy hau publikatzen LookUp batean duen Jini zerbitzua: 
// KafeMakinaService klasea.
        

package corejini.chapter5;


import net.jini.discovery.DiscoveryListener;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.LookupDiscovery;
import net.jini.core.lookup.ServiceItem;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceRegistration;
import java.util.Hashtable;
import java.io.IOException;
import java.io.Serializable;
import java.io.DataInput;
import java.io.DataInputStream;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;

// Hauxe da bezeroek jeitsiko duten proxy objektua.
// Serializagarria da noski, eta KafeMakinaServiceInterface
// implementatzen du.

class KafeMakinaServiceProxy implements Serializable, 
    KafeMakinaServiceInterface {
    public KafeMakinaServiceProxy() {
    }
		// Hemen barruan inplementaturik daude KafeMakina interfazean
		// definituriko metodoak. Metodo ezin xinpleagoak dira, eta ez dute
		// azalpenen beharrik.
		public String hartuMezua() { return "Hauxe da KafeMakina zerbitzu Xinplea\n";}
   	public String ordaindu(String visa,String urtea,String hilabetea)	{
   		return "ONARTUA";	
   	}
    public String kafeHutsa(int azukrea)	{
			String emaitza="Zure eskera egiten ari naiz";
    	return emaitza;
    }
    public String kafeEbakia(int azukrea)	{
			String emaitza="Zure eskera egiten ari naiz";
    	return emaitza;
    }
    public String kafeEsnea(int azukrea)	{
			String emaitza="Zure eskera egiten ari naiz";
    	return emaitza;
    }
    public String esneHutsa(int azukrea)	{
			String emaitza="Zure eskera egiten ari naiz";
    	return emaitza;
    }
    public String kaputxinoa(int azukrea)	{
			String emaitza="Zure eskera egiten ari naiz";
    	return emaitza;
    }

    
    // metodo hau nagusia da. Erabiltzailearen
    // sarreraren zain geratzen d eta honek nahi dituen kalkuluak
    // egiten dira.
    public void martxanJarri () throws IOException {
    	DataInput di = new DataInputStream(System.in);
    	int Aukera=1, int1=0,int2=0;
    	String Lerroa ="0";
    	while (true) {
    		System.out.println("Aukeratu eragiketa:\n\t1: batuketa\n\t2: kenketa\n\t3: biderketa" +
    											 "\n\t4: zatiketa\n\t5: modulua\n\t6: portzentaia\n\n\t\t0: atera");
    		System.out.print("\t\t\tAukeratu");
    		Lerroa = di.readLine();
    		try {
    			Aukera = Integer.parseInt(Lerroa); 
    			if (Aukera==0) System.exit(0);
    			} catch (NumberFormatException ex1)
    			{System.out.println("Sartu zenbaki egokia, mesedez..."); Aukera=7;continue;}
    			
					System.out.println("Sartu zenbaki 1");    
					Lerroa = di.readLine();
    		try {
    			int1 = Integer.parseInt(Lerroa); 
    			} catch (NumberFormatException ex2)
    			{System.out.println("Sartu zenbaki egokia, mesedez..."); Aukera=7;continue;}
		
					System.out.println("Sartu zenbaki 2");    
					Lerroa = di.readLine();
    		try {
    			int2 = Integer.parseInt(Lerroa); 
    			} catch (NumberFormatException ex3)
    			{System.out.println("Sartu zenbaki egokia, mesedez..."); Aukera=7;continue;}
					 System.out.println("Emaitza:");
    		switch (Aukera) {
    			 case 1:System.out.println(kafeHutsa(1));break;
    			 case 2:System.out.println(kafeEbakia(1));break;
    			 case 3:System.out.println(kafeEsnea(1));break;
    			 case 4:System.out.println(esneHutsa(1));break;
    			 case 5:System.out.println(kaputxinoa(1));break;
    			 case 6:System.out.println(hartuMezua());break;
    			 case 0: System.exit(0);
    			 default : break;   			
    			}//case bukaera
    		}// while bukaera
    }//metodo bukaera
    
}

// KafeMakinaService wrapper klasea da
// zerbitzua sarean atzigarri jartzen du.
public class KafeMakinaService implements Runnable {
    // 20 minutuko lease-a
    protected final int LEASE_TIME = 20 * 60 * 1000; 
    protected Hashtable registrations = new Hashtable();
    protected ServiceItem item;
    protected LookupDiscovery disco;
    
	// Inner klasea discovery gertaerak entzuteko   
    class DiscoveryEntzule implements DiscoveryListener {
	// Lookup zerbitzua topatzerakoan deitzen den klasea.
        public void discovered(DiscoveryEvent ev) {
            System.out.println("LookUp zerbitzu bat topatu da!");
            ServiceRegistrar[] newregs = ev.getRegistrars();
            for (int i=0 ; i<newregs.length ; i++) {
                if (!registrations.containsKey(newregs[i])) {
                    registerWithLookup(newregs[i]);
                }
            }
        }
        

	      // Funtzio hau bakarrarik zerbitzu bat esplizituki
        // kendu nahi dugunean (ez zerbitzu bat erortzen
        // denean automatikoki). Behin discovery egiterakoan
        // ez dago ongoing komunikaziorik lookup zerbitzuarekin.
        public void discarded(DiscoveryEvent ev) {
            ServiceRegistrar[] deadregs = ev.getRegistrars();
            for (int i=0 ; i<deadregs.length ; i++) {
                registrations.remove(deadregs[i]);
            }
        }
    }

    public KafeMakinaService() throws IOException {
        item = new ServiceItem(null, createProxy(), null);
        
        // Segurtasun kudeatzaile bat martxan jartzen da.  
        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new RMISecurityManager());
        }
        
	      // public taldea bilatzen da, konbentzioz
        // ""-z adierazten dena.
        disco = new LookupDiscovery(new String[] { "" });
        
        // Entzule bat jartzen da.
        // Hemendik aurrera, zerbitzu hau begizta amaigabean sartuko
        // da, eta entzule honek LookUp-ak topatzen dituenean, goian
        // ikusiriko inner-class berezia (DiscoveryEntzule) arduratuko da 
        // bertan erregistratzeaz. 
        disco.addDiscoveryListener(new DiscoveryEntzule());
    }
    
    protected KafeMakinaServiceInterface createProxy() {
        return new KafeMakinaServiceProxy();
    }
    

	      // Lan honetarko ezinbestekoa da urrutiko deia edo
        // 'remote call' bat jasotzea Lookup bat topatzen dela
        // jakiteko, eta denbora pixkat beharko da.
    protected synchronized void registerWithLookup(ServiceRegistrar registrar) {
        ServiceRegistration registration = null;

        try {
        		// Hementxe erregistratzen da zerbitzua.
        		// item aldagaian, proxy objektu bat sarturik dago.
            registration = registrar.register(item, LEASE_TIME);
        } catch (RemoteException ex) {
            System.out.println("Ezin izan dut zerbitzua erregistratu LookUp-ean: " + ex.getMessage());
            return;
        }
        
        // Lehenbiziko aldiz erregistratzen bada zerbitzua
        // 'service ID' bat jasoko du (128 biteko zorizko balioa, munduan bakarra) 
        // Zerbitzu 'ON' batek ID hori gorde beharko luke beti erabiltzeko.
        if (item.serviceID == null) {
            item.serviceID = registration.getServiceID();
            System.out.println("Zerbitzuaren serviceID-a " + item.serviceID);
        }
        
        registrations.put(registrar, registration);
    }
    
    // Hari honen bitartez ez dugu ezer egiten, baino ziurtatzen
    // dugu zerbitzua martxan egonen dela Lookup bat bilatzen duen
    // bitartean, JVMtik atera gabe. 
    public void run() {
        while (true) {
            try {
                Thread.sleep(1000000);
            } catch (InterruptedException ex) {
            }
        }
    }
    
    // KafeMakinaService berria sortu eta bere 
    // haria hasieratu.	
    public static void main(String args[]) {
        try {
            KafeMakinaService hws = new KafeMakinaService();
            new Thread(hws).start();
        } catch (IOException ex) {
            System.out.println("Ezin izan dut zerbitzua sortu: " +
                               ex.getMessage());
        }
    }
}
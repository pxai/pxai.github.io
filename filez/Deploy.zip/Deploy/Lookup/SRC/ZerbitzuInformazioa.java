// Find and print services that have ServiceInfo 
// attributes.

package JiniAdministrator;

import net.jini.discovery.LookupDiscovery;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.DiscoveryListener;
import net.jini.core.lookup.ServiceMatches;
import net.jini.core.lookup.ServiceItem;
import net.jini.core.lookup.ServiceTemplate;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.lookup.entry.ServiceInfo;
import net.jini.core.entry.Entry;
import java.util.Hashtable;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;
import java.io.IOException;

public class ZerbitzuInformazioa implements Runnable {
    protected Hashtable registrars = new Hashtable();
    protected Hashtable services = new Hashtable();
    protected ServiceTemplate tmpl;
    
    class Discoverer implements DiscoveryListener {
        public void discovered(DiscoveryEvent ev) {
            ServiceRegistrar[] newregs = ev.getRegistrars();
            for (int i=0 ; i<newregs.length ; i++) {
                addRegistrar(newregs[i]);
            }
        }
        public void discarded(DiscoveryEvent ev) {
            ServiceRegistrar[] newregs = ev.getRegistrars();
            for (int i=0 ; i<newregs.length ; i++) {
                removeRegistrar(newregs[i]);
            }
        }
    }
    
    public ZerbitzuInformazioa() throws IOException {
	if (System.getSecurityManager() == null) {
	    System.setSecurityManager(
		    new RMISecurityManager());
	}

        // build our template
        Entry[] attrTemplates = new Entry[1];
        attrTemplates[0] = new ServiceInfo(null, null, null, 
                                           null, null, null);
        tmpl = new ServiceTemplate(null, null, attrTemplates);
        
        // set up for discovery
        LookupDiscovery disco = 
            new LookupDiscovery(LookupDiscovery.ALL_GROUPS);
        disco.addDiscoveryListener(new Discoverer());
    }
    
    protected synchronized void addRegistrar(ServiceRegistrar reg) {
        if (registrars.contains(reg.getServiceID()))
            return;
            
        registrars.put(reg.getServiceID(), reg);
        findServices(reg);
    }
    protected synchronized void removeRegistrar(ServiceRegistrar reg) {
        if (!registrars.contains(reg.getServiceID()))
            return;
        
        registrars.remove(reg.getServiceID());
    }
    
    void findServices(ServiceRegistrar reg) {
        try {
            ServiceMatches matches = reg.lookup(tmpl, Integer.MAX_VALUE);
        
            for (int i=0 ; i<matches.totalMatches ; i++) {
                if (services.contains(matches.items[i].serviceID))
                    continue;
            
        
                addService(matches.items[i]);
            }
        } catch (RemoteException ex) {
            System.err.println("Couldn't search for services: " +
                               ex.getMessage());
        }
    }
    
    protected void addService(ServiceItem item) {
        services.put(item.serviceID, item);
        System.out.println("New service found: " + item.serviceID);
        printServiceInfo(item);
    }
    
    protected void printServiceInfo(ServiceItem item) {
        for (int i=0 ; i<item.attributeSets.length ; i++) {
            if (item.attributeSets[i] instanceof ServiceInfo) {
                ServiceInfo info = (ServiceInfo) item.attributeSets[i];
                System.out.println("    Name = " + info.name);
                System.out.println("    Manufacturer = " + info.manufacturer);
                System.out.println("    Vendor = " + info.vendor);
                System.out.println("    Version = " + info.version);
                System.out.println("    Model = " + info.model);
                System.out.println("    Serial Number = " + info.serialNumber);
            }
        }
    }
    
    public void run() {
        while (true) {
            try {
                Thread.sleep(Long.MAX_VALUE);
            } catch (InterruptedException ex) {
            }
        }
    }
    
    public static void main(String args[]) {
        try {
            ZerbitzuInformazioa searcher = new ZerbitzuInformazioa();
            new Thread(searcher).start();
        } catch (Exception ex) {
            System.err.println("Error starting service info searcher: " +
                               ex.getMessage());
            ex.printStackTrace();
        }
    }
}

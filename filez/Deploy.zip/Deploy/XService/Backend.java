// Honek, AgurMunduariService-ren luzapen bat da
// RMI erabiltzen duena aktibagarri den back-end
// prozesu batekin. Aktibagarritasuna jdk1.2tik aurrera
// RMI-n erabil daitekeen teknologia da.

package zerbitzuak.zerbitzuakv3;


import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.Remote;
import java.rmi.MarshalledObject;
import java.rmi.RMISecurityManager;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.activation.Activatable;
import java.rmi.activation.ActivationID;
import java.rmi.activation.ActivationDesc;
import java.rmi.activation.ActivationGroup;
import java.rmi.activation.ActivationGroupID;
import java.rmi.activation.ActivationGroupDesc;
import java.rmi.activation.ActivationException;
import java.util.Properties;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.IOException;

		// Kabiatutako klase honek backend protokoloa
		// (goian inplementaturiko interfazea) inplementatzen du.
		// Aktibagarria da, beraz
		// UnicasRemoteObjektua izanen da.
    public
    class Backend
    extends Activatable
    implements BackendProtocol {

        // atributuak
        JoinKudeatzailea.RemoteUnicastAdmin adminbackend;
        int nextMessage = 0;
        String[] messages = { "Agur Mundua, lehena naiz",
                              "Kaixo Mundua hemen nago",
                              "Zer moduz gaude??  Ondo!" };

        // eraikitzailea
        public Backend(ActivationID id, MarshalledObject data)
            throws RemoteException {
            super(id, 0);
            try {
            adminbackend = (JoinKudeatzailea.RemoteUnicastAdmin)(data.get());

            } catch (Exception ex) {
             System.err.println("<backend> Errorea objektua berreskuratzerakoan."+ex.getMessage());
             System.err.println("<backend> Pila: ");ex.printStackTrace();
            }
        }

        public synchronized String hartuMezua() throws RemoteException {
            String str =  messages[nextMessage];
            nextMessage = (nextMessage + 1) % messages.length;
            return str;
        }


    // Zerbitzuaren administrazio objektu itzultzen duen metodoa
      public Object getAdmin () throws RemoteException{
          return new XAdminInplementazioa(adminbackend);
      }
      	// klase honek, aktibagarritasuna dela eta, lanik ez duenean
      	// 'sleep' egoerara pasako da.

}

// Jini Zerbitzuaren datuak modu seguruan gordetzeko klasea:
// zerbitzu ID-a, topatutako Lookup-ak, Entry-en egoera,
// zerbitzuaren (dispositiboaren) errore baten ostean oso baliogarria
// gerta daiteke informazio hau berreskuratzea, Jini ingurunean berriz
// sartzeko.

package zerbitzuak.zerbitzuakv3;

// import gunea
import net.jini.core.lookup.ServiceID;
import net.jini.core.entry.Entry;
import net.jini.core.discovery.LookupLocator;
import java.io.Serializable;



    // klasearen deklarazioa
    class ZerbitzuDatuak
    implements Serializable {

        // atributuak
        ServiceID zerbitzuID;
        Entry[] atributuak;
        LookupLocator[] locs;
        Object subclassData;

        // eraikitzailea
        ZerbitzuDatuak(ServiceID serviceID, Entry[] attrs,
                       LookupLocator[] locs, Object subclassData) {
            zerbitzuID = serviceID;
            atributuak = attrs;
            this.locs = locs;
            this.subclassData = subclassData;
        }
    }



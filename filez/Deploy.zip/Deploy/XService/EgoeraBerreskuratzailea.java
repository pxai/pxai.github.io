// Egoera berreskuratzailea. Honen bitartez, zerbitzuak
// gorde dituen Jini inguruneari buruzko datuak berreskuratzen ditu
// eta lehengo egoerara itzultzen saia daiteke, itzali baino lehen
// zituen atributu berdinekin, ID berarekin, e.a...

package zerbitzuak.zerbitzuakv3;

// import gunea
import net.jini.discovery.DiscoveryListener;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.LookupDiscovery;
import net.jini.core.lookup.ServiceItem;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceRegistration;
import net.jini.core.entry.*;
import net.jini.lookup.entry.*;
import net.jini.core.lease.Lease;
import net.jini.core.lookup.ServiceID;
import net.jini.core.entry.Entry;
import net.jini.core.discovery.LookupLocator;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.MalformedURLException;
import java.util.Hashtable;
import java.rmi.RemoteException;

// klasearen deklarazioa
public
class EgoeraBerreskuratzailea
extends Thread {

  // Atributuak
  protected final int LEASE_TIME = 10 * 60 * 1000;
  public String fitxategia;
  public Object proxyObjektua;
  public ZerbitzuDatuak data;
  public Hashtable erregistratutakoak = new Hashtable();


  public EgoeraBerreskuratzailea(String fitxategia, Object o) {
    this.fitxategia = fitxategia;
    proxyObjektua = o;
  }

  // funtzio honi behin bakarrik deituko zaio: zerbitzua hasieratzerakoan
    public void berreskuratu() throws IOException {
        data = null;
        try {
        ObjectInputStream in = new ObjectInputStream(new FileInputStream(fitxategia));
        data = (ZerbitzuDatuak) in.readObject();

        } catch (Exception ex)
         {
            System.err.println("Errorea fitxategia irakurtzerakoan: "+ex.getMessage());
         }
        if (data == null) {
            System.err.println("Ez dago daturik berreskuratzeko...");
        } else {
            System.out.println("Zerbitzuko lehengo egoera berreskuratzen...");
            if (data.zerbitzuID != null)    
            System.out.println("Zerbitzu ID-a: "+ data.zerbitzuID);
            System.out.println("Locator-ak: "+ data.locs);
            System.out.println("Zerbitzu atributuak: "+ data.atributuak);
            System.out.println("Zerbitzuko objektua: "+data.subclassData);
            try {
            erregistratu(data);
            } catch (ClassNotFoundException cnfex) {
              System.err.println("Errorea berriz erregistratzerakoan:"+cnfex.getMessage());
            }

        }
    }

    // datuak modu seguru batean gordetzeko deitzen den metodoa
    public void checkpoint(Object subclassData,Entry[] entryak,ServiceID zerbitzuID,LookupLocator[] ll)
    {
        ZerbitzuDatuak data;

        data = new ZerbitzuDatuak(zerbitzuID,entryak,ll,subclassData);
         try {
        ObjectOutputStream out = new
            ObjectOutputStream(new FileOutputStream(fitxategia));

        out.writeObject(data);
        out.flush();
        out.close();
         } catch (IOException ioex)
         {
            System.err.println("<egoera berreskuratzailea> Errorea egoera gordetzerakoan: "+ioex.getMessage());
         }
        System.out.println("<egoera berreskuratzailea>Zerbitzuaren egoera gorde da.");
    }

    // honen bitartez, berriz ere erregistratuko gara gure fitxategian gordetako
    // Lookup zerbitzuetan. Gainera zuzenean topatuko ditugu: Unicast Discovery
    // bat eginen da azken finean
    private
    void erregistratu (ZerbitzuDatuak datuak)
    throws MalformedURLException, IOException, ClassNotFoundException {
     ServiceRegistration registration = null;
     ServiceRegistrar registrar = null;
     ServiceItem item = null;
          try {
            for (int i = 0;i<datuak.locs.length;i++)  {
              registrar = datuak.locs[i].getRegistrar();
              item = new ServiceItem(datuak.zerbitzuID,proxyObjektua,datuak.atributuak);
              registration = registrar.register(item, LEASE_TIME);
              erregistratutakoak.put(registrar,registration);
              }
              System.out.println("<egoera berreskuratzailea> Zerbitzuko lehengo egoera berreskuratuta...");
      } catch (Exception ex) {
          System.err.println("<egoera berreskuratzailea>Errorea lookup egiterakoan "+ex.getMessage());
      }
    }

    


}

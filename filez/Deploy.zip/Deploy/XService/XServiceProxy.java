// XServiceProxy, bezeroek zerbitzuarekin komunikatzeko erabiliko
// duten klasea izanen da hau.
package zerbitzuak.zerbitzuakv3;

// import gunea
import net.jini.admin.Administrable;
import java.io.Serializable;
import java.rmi.RemoteException;

// Hauxe da bezeroek jeitsiko duten proxy objektua.
// Serializagarria da noski, eta XServiceInterface
// implementatzen du.
public
class XServiceProxy
implements Serializable, XServiceInterface, Administrable {
    // Atributuak
    BackendProtocol backend;


    // eraikitzailea
    public XServiceProxy() {
    }


    // eraikitzailea argumentuekin
    public XServiceProxy(BackendProtocol backend) {
      this.backend = backend;
    }


    // Administrazio objektua itzultzen duen metodoa
    public Object getAdmin () {
      Object objetua = null;
      try {
          return backend.getAdmin();
          } catch (RemoteException re)
          {
            System.err.println("Errorea backend-ari deia pasatzerakoan" + re.getMessage());
          }
      return objetua;
    }
    // hartuMezua-ren inplementazioa, deia backend-ari
    // deia pasatzen zaio
    public String hartuMezua() {
      try {
          return backend.hartuMezua();
          } catch (RemoteException re)
          {
            return "Errorea backend-ari deia pasatzerakoan" + re.getMessage();
          }
    }
}

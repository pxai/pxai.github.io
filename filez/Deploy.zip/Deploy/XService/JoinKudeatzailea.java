// Hauxe JoinKudeatzailea da: Lookup zerbitzuak
// bilatzeaz arduratuko den klasea da, eta gainera,
// zerbitzuaren Join informazioa (Entry-ak) ere
// manipulatzeko erabili ahal izanen da.


package zerbitzuak.zerbitzuakv3;

// import gunea
import net.jini.discovery.DiscoveryListener;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.LookupDiscovery;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceRegistration;
import net.jini.core.discovery.LookupLocator;
import net.jini.core.entry.Entry;
import net.jini.admin.JoinAdmin;
import com.sun.jini.admin.DestroyAdmin;
import com.sun.jini.admin.StorageLocationAdmin;
import java.util.Hashtable;
import java.util.Vector;
import java.io.IOException;
import java.io.Serializable;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.File;
import java.rmi.RemoteException;
import java.rmi.Remote;
import java.rmi.server.UnicastRemoteObject;


// Klasearen deklarazioa
public
class JoinKudeatzailea
extends UnicastRemoteObject
implements JoinKudeatzailea.RemoteUnicastAdmin, Serializable  {

  // Atributuak
  protected final int LEASE_TIME = 10 * 60 * 1000;
  public Hashtable registrations = new Hashtable();
  protected Vector serviceRegistrationVector = new Vector(0);
  protected XService zerbitzua;
  protected LookupDiscovery lookupDiscovery;
  protected LeaseBerritzailea leaseberritzailea;
  public LookupLocator[] lookupLocator;
  protected String[] LookupTaldeak = new String[] { "" };
  protected Vector lookupLocatorVector = new Vector(0);

  // eraikitzailea
  public JoinKudeatzailea () throws RemoteException{
      super();
  }


  // metodo bat hariak eta entzuleak aktibatzeko
  public void martxanJarri (XService zerbitzua, Hashtable regis) {
     this.zerbitzua = zerbitzua;
      registrations = regis;
    // lease-ak berritzeaz arduratuko den Thread klasea martxan jartzen dugu.
    // hemendik aurrera, klase honetan ez gara arduratuko Lease-taz
     if (zerbitzua.egoeraBerreskuratzailea.data != null)
     lookupLocator = zerbitzua.egoeraBerreskuratzailea.data.locs;
     try {
      leaseberritzailea = new LeaseBerritzailea(registrations);
      leaseberritzailea.start();
      lookupDiscovery = new LookupDiscovery(LookupTaldeak);
      lookupDiscovery.addDiscoveryListener(new JoinEntzulea());
    } catch  (IOException ioex) {
      System.err.println("Errorea Discovery Entzule sortzerakoan...: "+ioex.getMessage());
    }

  }


  // 'inner' motko klasea Lookup egiteko...
  class JoinEntzulea
  implements DiscoveryListener {


    public void discovered(DiscoveryEvent ev) {
            System.out.println("<join kudeatzailea> Discovery: arrakasta!\nLookup zerbitzua topatua!");
            ServiceRegistrar[] newregs = ev.getRegistrars();
            for (int i=0 ; i<newregs.length ; i++) {
                if (!registrations.containsKey(newregs[i])) {
                    registerWithLookup(newregs[i]);
                    leaseberritzailea.interrupt();
                }
            }
        }

        // Funtzio hau bakarrarik zerbitzu bat esplizituki
        // kendu nahi dugunean (ez zerbitzu bat "erortzen"
        // denean automatikoki. Behin "discovery" egiterakoan
        // ez dago ongoing komunikaziorik lookup zerbitzuarekin.
        public void discarded(DiscoveryEvent ev) {
            ServiceRegistrar[] deadregs = ev.getRegistrars();
            for (int i=0 ; i<deadregs.length ; i++) {
                registrations.remove(deadregs[i]);
            }
        }
      } // inner klasearen bukaera


    // interfazea urrutiko administrazioa bideratzeko
    interface
    RemoteUnicastAdmin
    extends XAdmin, JoinAdmin, DestroyAdmin, StorageLocationAdmin, Remote {
    }



    // Lan honetarko ezinbestekoa da urrutiko deia edo
    // 'remote call' bat jasotzea Lookup bat topatzen dela
    // jakiteko, eta denbora pixkat beharko da.
    public synchronized void registerWithLookup(ServiceRegistrar registrar) {
        ServiceRegistration registration = null;
        LookupLocator[] lookupLocator = null;
        try {
            registration = registrar.register(zerbitzua.item, LEASE_TIME);
  					serviceRegistrationVector.addElement(registration);
        } catch (RemoteException ex) {
            System.out.println("<join kudeatzailea> Ezin izan da registratu: " + ex.getMessage());
            return;
        }

        // Lehenbiziko aldiz erregistratzen bada zerbitzua
        // 'service ID' bat jasoko du (128 biteko zorizko balioa, munduan bakarra)
        // Zerbitzu 'ON' batek ID hori gorde beharko luke beti erabiltzeko.
        if (zerbitzua.item.serviceID == null) {
            zerbitzua.item.serviceID = registration.getServiceID();
            System.out.println("Zerbitzu-IDa :" + zerbitzua.item.serviceID);
            zerbitzua.egoeraBerreskuratzailea.checkpoint(zerbitzua.item.service,zerbitzua.entriBat,zerbitzua.item.serviceID,lookupLocator);
        }

        registrations.put(registrar, registration);
            try {
            lookupLocatorVector.addElement(registrar.getLocator());
            lookupLocator =  new LookupLocator[lookupLocatorVector.size()];
            lookupLocatorVector.copyInto(lookupLocator);
            } catch (RemoteException re) {
            System.out.println("<join kudeatzailea> Ezin izan da locator-a ekarri " + re.getMessage());
            }
        zerbitzua.egoeraBerreskuratzailea.checkpoint(zerbitzua.item.service,zerbitzua.entriBat,zerbitzua.item.serviceID,lookupLocator);
    }


  // Hemendik aurrera, Zerbitzuaren Entry-ak manipulatzeko zenbait metodo
  // ikusiko ditugu, gero administrazio lanerako erabil daitezkeenak
  // Hauek dira azken finean administrazio interfazea inplementatzen
  // duten metodoak.

  public void mezuaEragin () throws RemoteException {
   System.out.println("<join kudeatzailea> Mezua eragin da urrutitik!!");
  }


  // JoinKudeatzailearen egoera (Lookup zerbitzuak, helbideak,...)
  // gordetzen duen fitxategiaren aldatzeko metodoa
  	public void setStorageLocation (String loc) throws RemoteException {
         String izena = zerbitzua.egoeraBerreskuratzailea.fitxategia;

  	 try {
  		File locBerria = new File(loc);
                File locZaharra = new File(izena);
  		BufferedReader br = new BufferedReader(new FileReader(locZaharra));
  		BufferedWriter bw = new BufferedWriter(new FileWriter(locBerria));
  		char[] buffer = new char[1024];
  		int n = 0;
  		while ((n = br.read(buffer)) >0 ) 
  			bw.write(buffer,0,n);
  		bw.close();
  		br.close();
  		locZaharra.delete();
                zerbitzua.egoeraBerreskuratzailea.fitxategia = loc;
  	} catch (IOException ioex) {
  			System.err.println(ioex.getMessage());
  		}
  	}
  	
  // JoinKudeatzailearen egoera (Lookup zerbitzuak, helbideak,...)
  // gordetzen duen fitxategiaren izena itzultzen duen.
  	public String getStorageLocation () throws RemoteException {
                return zerbitzua.egoeraBerreskuratzailea.fitxategia;
	}
  		
  		
  	
    // Zerbitzua suntsitzeko metodoa...
    public synchronized void destroy () throws RemoteException{
      zerbitzua.shutdownZerbitzua(10);
    }


    //Zerbitzuko Lookup-erako atributuak (Entry-ak) itzultzen  dituen metodoa
   public Entry[] getLookupAttributes () throws RemoteException{
      return zerbitzua.entriBat;
   }

    //Zerbitzuko Lookup-erako atributuak (Entry-ak) gehitzen dituen metodoa
    public void addLookupAttributes(Entry[] attrs) throws RemoteException{
        Vector bektorea = new Vector(0);
        int i;
        for (i=0; i < zerbitzua.entriBat.length;i++)
          bektorea.addElement(zerbitzua.entriBat[i]);
        for (i=0; i < attrs.length;i++)
          bektorea.addElement(attrs[i]);
        try {
        Entry[] entry = new Entry[bektorea.size()];
        bektorea.copyInto(entry);
        zerbitzua.entriBat = entry;
        System.out.println("<join-kudeatzailea-admin>Atributuak gehitu dira.\nEntry-ak"+zerbitzua.entriBat);
         } catch (ArrayStoreException asex) {
            System.err.println("Errorea arrayarekin.."+asex.getMessage());
         }
            zerbitzua.egoeraBerreskuratzailea.checkpoint(zerbitzua.item.service,zerbitzua.entriBat,zerbitzua.item.serviceID,lookupLocator);
    }

    //Zerbitzuko Lookup-erako atributuak (Entry-ak) aldatzen dituen metodoa
    public void modifyLookupAttributes(Entry[] tmpls,Entry[] attrs) throws RemoteException{
        Vector emaitza = new Vector(0);
        Entry[] e = null, eSave = attrs;
        boolean topatua = false;

        try {
        for (int i = 0;i< zerbitzua.entriBat.length;i++)
        {
          topatua = false;
          for (int j = 0;j < tmpls.length; j++)
          if (zerbitzua.entriBat[i].equals(tmpls[j])) {
              emaitza.addElement(attrs[j]);
              topatua = true;
              }
          if (!topatua)
              emaitza.addElement(zerbitzua.entriBat[i]);
        }
              e = new Entry[emaitza.size()] ;
              emaitza.copyInto(e);
              zerbitzua.entriBat = e;
        } catch (ArrayStoreException asex) {
            System.err.println("Errorea arrayarekin.."+asex.getMessage());
         }
        for (int k=0;k<zerbitzua.entriBat.length;k++)
            System.out.println(zerbitzua.entriBat[k].toString());
        try {
        aldatuEntryak(e);
        } catch (RemoteException re) {
        	System.err.println("<join kudeatzailea> Errorea atributuak Lookup-etan aldatzerakoan."+re.getMessage());	
        } catch (Exception ex) {
        	System.err.println("<join kudeatzailea> Errorea atributuak Lookup-etan aldatzerakoan."+ex.getMessage());	        	
        	}
                zerbitzua.egoeraBerreskuratzailea.checkpoint(zerbitzua.item.service,zerbitzua.entriBat,zerbitzua.item.serviceID,lookupLocator);
    }
    
    // aldatuEntry-ak. Erregistraturik dagoen Lookup-zerbitzutan
    // bere atributuak aldatzen ditu...
    private void aldatuEntryak (Entry[] e1) throws Exception{
    	for (int i = 0; i < serviceRegistrationVector.size(); i++) 
    		((ServiceRegistration)serviceRegistrationVector.elementAt(i)).setAttributes(e1);
    	
    }

    // Atributuak ezabatzeko metodoa
     public void ezabatuEntryAtributuak(Entry[] tmpls,Entry[] attrs) throws RemoteException{
        Vector emaitza = new Vector(0);
        try {
        for (int i = 0;i< zerbitzua.entriBat.length;i++)
        {
          for (int j = 0;j < tmpls.length; j++)
          if (!zerbitzua.entriBat[i].equals(tmpls[j]))
              emaitza.addElement(zerbitzua.entriBat[i]);
        }
              emaitza.copyInto(zerbitzua.entriBat);
        } catch (ArrayStoreException asex) {
            System.err.println("Errorea arrayarekin.."+asex.getMessage());
         }
            zerbitzua.egoeraBerreskuratzailea.checkpoint(zerbitzua.item.service,zerbitzua.entriBat,zerbitzua.item.serviceID,lookupLocator);
    }


    // Zerbitzuak erabiltzen dituen Lookup Taldeak itzultzen duen metodoa
    public String[] getLookupGroups() throws RemoteException{
      return (LookupTaldeak);
    }

    // Zerbitzuen Lookup Taldeak gehitzen duen metodoa
    public void addLookupGroups(String[] groups)  throws RemoteException{
      Vector bektorea = new Vector(0);
      int i;
        for (i=0; i < LookupTaldeak.length;i++)
          bektorea.addElement(LookupTaldeak[i]);
        for (i=0; i < groups.length;i++)
          bektorea.addElement(groups[i]);
        try {
         String[] taldeak = new String[bektorea.size()];
         bektorea.copyInto(taldeak);
         LookupTaldeak = taldeak;
          System.out.println("<join-kudeatzailea-admin>LookupTaldeak gehitu dira.\n Taldeak:"+LookupTaldeak);
         } catch (ArrayStoreException asex) {
            System.err.println("Errorea arrayarekin.."+asex.getMessage());
         }
            zerbitzua.egoeraBerreskuratzailea.checkpoint(zerbitzua.item.service,zerbitzua.entriBat,zerbitzua.item.serviceID,lookupLocator);

    }

    // Zerbitzuak erabiltzen dituen Lookup Taldeak ezabatzen duen metodoa
    public void removeLookupGroups(String[] groups) throws RemoteException{
      Vector emaitza = new Vector(0);
      for (int i = 0;i < LookupTaldeak.length; i++)
        for (int j = 0;j < groups.length; j++)
          if (!LookupTaldeak[i].equals(groups[j]))
              emaitza.addElement(LookupTaldeak[i]);
        try {
         String[] taldeak = new String[emaitza.size()];
         emaitza.copyInto(taldeak);
         LookupTaldeak = taldeak;
          System.out.println("<join-kudeatzailea-admin>LookupTaldeak ezabatu dira.\n Taldeak:"+LookupTaldeak);
         } catch (ArrayStoreException asex) {
            System.err.println("Errorea arrayarekin.."+asex.getMessage());
         }
            zerbitzua.egoeraBerreskuratzailea.checkpoint(zerbitzua.item.service,zerbitzua.entriBat,zerbitzua.item.serviceID,lookupLocator);
    }

    // Zerbitzuak erabiltzen dituen Lookup Taldeak ezartzen duen metodoa
    public void setLookupGroups(String[] groups)   throws RemoteException{
      Vector gehitu = new Vector(0);
      for (int j = 0;j < groups.length; j++)
      gehitu.addElement(groups[j]);
        try {
         String[] taldeak = new String[gehitu.size()];
         gehitu.copyInto(taldeak);
         LookupTaldeak = taldeak;
          System.out.println("<join-kudeatzailea-admin>LookupTaldeak ezarri dira.\n Taldeak:"+LookupTaldeak);
         } catch (ArrayStoreException asex) {
            System.err.println("Errorea arrayarekin.."+asex.getMessage());
         }
            zerbitzua.egoeraBerreskuratzailea.checkpoint(zerbitzua.item.service,zerbitzua.entriBat,zerbitzua.item.serviceID,lookupLocator);
    }

    // LookUpLocator, Lookup zerbitzuak topatzeaz arduratzen
    // den klasea da. Beraz, metodo honen bitartez lookuplocator
    // guztiak eskuratzen ditugu
    public LookupLocator[] getLookupLocators() throws RemoteException{
        return lookupLocator;
    }

    // Metodo honen bitartez, LookupLocator berriak
    // gehitzen ditugu
    public void addLookupLocators(LookupLocator[] locs) throws RemoteException{
      Vector bektorea = new Vector(0);
      int i;
        for (i=0; i < lookupLocator.length;i++)
          bektorea.addElement(lookupLocator[i]);
        for (i=0; i < locs.length;i++)
          bektorea.addElement(locs[i]);
        try {
        LookupLocator[] lookuploc = new LookupLocator[bektorea.size()];
        bektorea.copyInto(lookuploc);
        lookupLocator = lookuploc;
        System.out.println("<join-kudeatzailea-admin> Lookup locator-ak gehitu dira.");
         } catch (ArrayStoreException asex) {
            System.err.println("<join-kudeatzailea-admin> Errorea arrayarekin.."+asex.getMessage());
         }
            zerbitzua.egoeraBerreskuratzailea.checkpoint(zerbitzua.item.service,zerbitzua.entriBat,zerbitzua.item.serviceID,lookupLocator);


    }

    // Metodo honen bitartez, LookupLocator berriak
    // ezabatzen ditugu
    public void removeLookupLocators(LookupLocator[] locs)  throws RemoteException{
      Vector emaitza = new Vector(0);
      LookupLocator[] ll;
      for (int i = 0;i < lookupLocator.length; i++)
        for (int j = 0;j < locs.length; j++)
          if (!lookupLocator[i].toString().equals(locs[j].toString())) {
              emaitza.addElement(lookupLocator[i]);
          System.out.println("<join-kudeatzailea-admin> Lookup locator-a topatu da.");
              }
        try {
          ll = new LookupLocator[emaitza.size()];
          emaitza.copyInto(ll);
          lookupLocator = ll;
          System.out.println("<join-kudeatzailea-admin> Lookup locator-ak ezabatu dira.");
         } catch (ArrayStoreException asex) {
            System.err.println("<join-kudeatzailea-admin> Errorea arrayarekin.."+asex.getMessage());
         }
            zerbitzua.egoeraBerreskuratzailea.checkpoint(zerbitzua.item.service,zerbitzua.entriBat,zerbitzua.item.serviceID,lookupLocator);
    }


    // Metodo honen bitartez, LookupLocator berriak
    // ezartzen ditugu
    public void setLookupLocators(LookupLocator[] locs) throws RemoteException{
      Vector emaitza = new Vector(0);
      for (int j = 0;j < locs.length; j++)
        emaitza.addElement(locs[j]);

        try {
          lookupLocator = null;
          LookupLocator[] ll = new LookupLocator[emaitza.size()];
          emaitza.copyInto(ll);
          lookupLocator = ll;
          System.out.println("<join-kudeatzailea-admin> Lookup locator-ak ezarri dira.");
         } catch (ArrayStoreException asex) {
            System.err.println("<join-kudeatzailea-admin> Errorea arrayarekin.."+asex.getMessage());
         }
            zerbitzua.egoeraBerreskuratzailea.checkpoint(zerbitzua.item.service,zerbitzua.entriBat,zerbitzua.item.serviceID,lookupLocator);
    }



}
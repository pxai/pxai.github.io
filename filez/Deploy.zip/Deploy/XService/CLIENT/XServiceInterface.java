// This is the interface that the service's proxy
// implements

package zerbitzuak.zerbitzuakv3;

public interface XServiceInterface {
    public String hartuMezua();
    
}

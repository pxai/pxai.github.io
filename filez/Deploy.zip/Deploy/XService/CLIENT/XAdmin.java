// Interfaze xinplea zerbitzu administrazioarako

package zerbitzuak.zerbitzuakv3;

// import gunea
import java.rmi.RemoteException;

public interface XAdmin {
    public void mezuaEragin() throws RemoteException;
}

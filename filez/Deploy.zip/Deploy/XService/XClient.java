// Bezero xinple bat XService erabiltzeko

package zerbitzuak.zerbitzuakv3;

import net.jini.discovery.DiscoveryListener;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.LookupDiscovery;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceTemplate;
import net.jini.core.lookup.ServiceMatches;
import net.jini.core.discovery.LookupLocator;
import net.jini.core.entry.Entry;
import net.jini.admin.Administrable;
import net.jini.admin.JoinAdmin;
import net.jini.lookup.entry.ServiceInfo;
import com.sun.jini.admin.DestroyAdmin;
import java.util.Vector;
import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;
import java.net.MalformedURLException;


public class XClient implements Runnable {
    protected ServiceTemplate template;
    protected LookupDiscovery disco;
    XAdmin administratzailea;
    DestroyAdmin zerbitzuSuntsitzailea;
    JoinAdmin joinAdministratzailea;
    Object objetua;
    private        String[] s1;
    private        String[] taldea;
    private        Entry[] e1;
    private        LookupLocator[] l1;


    // DiscoveryListener inplementatzeko inner-klasea
    class Listener implements DiscoveryListener {
        public void discovered(DiscoveryEvent ev) {
            ServiceRegistrar[] newregs = ev.getRegistrars();
            for (int i=0 ; i<newregs.length ; i++) {
              lookForService(newregs[i]);
                try {
               administratzailea.mezuaEragin();
                } catch (RemoteException ex) {
                    System.err.println("<Client> Errorea deia pastzerakoan: " + ex.getMessage());
                }

            }
        }
        public void discarded(DiscoveryEvent ev) {
        }
    }

    public XClient() throws IOException {
        Class[] types = { XServiceInterface.class };

        template = new ServiceTemplate(null, types, null);

        // security manager bat ezartzen da...
        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new RMISecurityManager());
        }

        // Bakarrik 'public' taldean bilatzen da...
        disco = new LookupDiscovery(new String[] { "" });

        // Entzule bat instalatzen da...
        disco.addDiscoveryListener(new Listener());
    }

    // Behin Lookup zerbitzua(k) topatuta,
    // HelloWorldServiceInterface plantillarekin bat datorren
    // zerbitzua bilatzen da bertan (hots, interfaze hori inplementatzen
    // duten zerbitzuak
    protected void lookForService(ServiceRegistrar lusvc) {
        Object o = null;

        try {
            o = lusvc.lookup(template);
        } catch (RemoteException ex) {
            System.err.println("Errorea lookup egiterakoan: " + ex.getMessage());
        }

        if (o == null) {
            System.err.println("Ez da toptu bat datorren zerbitzurik");
        }

        System.out.println("Bat datorren zerbitzua topatu da!");
        System.out.println("Bere lehen mezua da: " +
                           ((XServiceInterface) o).hartuMezua());
        System.out.println("Bere bigarren mezua da: " +
                           ((XServiceInterface) o).hartuMezua());
        System.out.println("Bere hirugarren mezua da: " +
                           ((XServiceInterface) o).hartuMezua());
            try {
            //XAdmin administratzailea = (XAdmin)((XServiceInterface)((Administrable)o).getAdmin());
            administratzailea =  (XAdmin)((Administrable)o).getAdmin();
            joinAdministratzailea =  (JoinAdmin)((Administrable)o).getAdmin();
            zerbitzuSuntsitzailea =  (DestroyAdmin)((Administrable)o).getAdmin();
            try {
            probakEgin();
            } catch (MalformedURLException muex) {
            System.err.println("Errorea administrazio objektua ekartzerakoan " + muex.getMessage());
            }
            } catch (RemoteException ex2) {
            System.err.println("Errorea administrazio objektua ekartzerakoan " + ex2.getMessage());
        }


    }

    public void probakEgin() throws MalformedURLException {
           LookupLocator[] l2 = new LookupLocator[1];
           String[] s2 = new String[1];
	 	  Entry[] entriBat = new Entry[1];
              Entry[] entriBi = new Entry[1];
		  entriBat[0] = new ServiceInfo("X Zerbitzu Generikoa",
						    "PelloX GeNeRiC Systems ltd.",
						    "PelloX Mikorsystemak ltd.",
						    "v3.0",
						    "X model, xxx",
						    "000-000-x");
		  entriBi[0] = new ServiceInfo("X Zerbitzu Generikoa??",
						    "EZ, aldatu baitut!!",
						    "Entry honen atributuak",
						    "Aldatu ditut",
						    "KAGON SOS",
						    "Lortu diat");
            try {
            s1 = joinAdministratzailea.getLookupGroups();
            e1 = joinAdministratzailea.getLookupAttributes();
            l1 = joinAdministratzailea.getLookupLocators();
            inprimatu();

              l2[0] = new LookupLocator("jini://satan00/");

               //s2[0] = "";
            //joinAdministratzailea.addLookupGroups(taldea);
            //joinAdministratzailea.setLookupLocators(l2);
            //joinAdministratzailea.removeLookupLocators(l2);
            //joinAdministratzailea.setLookupGroups(s2);
            // joinAdministratzailea.removeLookupGroups(s2);
            //joinAdministratzailea.addLookupAttributes(entriBi);
            joinAdministratzailea.modifyLookupAttributes(entriBi,entriBat);

                

            s1 = joinAdministratzailea.getLookupGroups();
            e1 = joinAdministratzailea.getLookupAttributes();
            l1 = joinAdministratzailea.getLookupLocators();
            inprimatu();
            } catch (RemoteException ex2) {
            System.err.println("<bezeroa> Errorea urrutiko objektuari deia egiterakoan: " + ex2.getMessage());
          }
    }

    public void inprimatu () {
     int i;
     for (i = 0;i < e1.length;i++)
            System.out.println(i+".-garren Entri-a: "+e1[i]);
     for (i = 0;i < l1.length;i++)
            System.out.println(i+".-garren Locator-a: "+l1[i].toString());
     for (i = 0;i < s1.length;i++)
            System.out.println(i+".-garrena : "+s1[i]);

    }

    // Hari honek ez du ezer ere ez egiten
    // discovery egiten den bitartean JVMtik ez ateratzeko.
    public void run() {
        while (true) {
            try {
                Thread.sleep(1000000);
            } catch (InterruptedException ex) {
            }
        }
    }
    
    // HelloWorldClient objektu bat sortu eta bere haria martxan jartzen du
    public static void main(String args[]) {
        try {
            XClient kc = new XClient();
            new Thread(kc).start();
        } catch (IOException ex) {
            System.out.println("Ezin izan dut bezeroa sortu: " +
                               ex.getMessage());
        }
    }
}


package zerbitzuak.zerbitzuakv3;

//import gunea
import net.jini.admin.JoinAdmin;
import com.sun.jini.admin.DestroyAdmin;
import com.sun.jini.admin.StorageLocationAdmin;
import net.jini.core.entry.Entry;
import net.jini.core.discovery.LookupLocator;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.io.Serializable;

// klasearen deklarazioa
public
class XAdminInplementazioa
implements JoinAdmin, DestroyAdmin, XAdmin, StorageLocationAdmin, Serializable {

  // Atributuak
  JoinKudeatzailea.RemoteUnicastAdmin adminbackend;

  // eraikitzailea -argumenturik gabe-
  public XAdminInplementazioa() {
  }

  // eraikitzailea -argumentuekin-
  public XAdminInplementazioa(JoinKudeatzailea.RemoteUnicastAdmin adminbackend) {
    this.adminbackend = adminbackend;
  }


  // JoinKudeatzailearen egoera (Lookup zerbitzuak, helbideak,...)
  // gordetzen duen fitxategiaren aldatzeko metodoa
  	public void setStorageLocation (String loc) throws RemoteException {
  	try {	
  		 adminbackend.setStorageLocation(loc);	
  	} catch (Exception re) {
      System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
    }
  	}
  	
  // JoinKudeatzailearen egoera (Lookup zerbitzuak, helbideak,...)
  // gordetzen duen fitxategiaren izena itzultzen duen.
  	public String getStorageLocation () throws RemoteException {
		 String loc = "";
  	try {	
  		return adminbackend.getStorageLocation();	
  	} catch (RemoteException re) {
      System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
    }
    return loc;
}
  		


  public synchronized void destroy () {
    try {
      adminbackend.destroy();
    } catch (RemoteException re) {
      System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
    }
  }

  public void mezuaEragin () {
    try {
         adminbackend.mezuaEragin();
    } catch (RemoteException re) {
      System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
    }
  }

    //Zerbitzuko Lookup-erako atributuak (Entry-ak) itzultzen  dituen metodoa
   public Entry[] getLookupAttributes () {
      Entry[] entry = null;
      try {
        return adminbackend.getLookupAttributes();
    } catch (RemoteException re) {
      System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
    }
      return entry;
   }

    //Zerbitzuko Lookup-erako atributuak (Entry-ak) gehitzen dituen metodoa
    public void addLookupAttributes(Entry[] attrs) {
      try {
              adminbackend.addLookupAttributes(attrs);
    } catch (RemoteException re) {
      System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
    }
    }

    //Zerbitzuko Lookup-erako atributuak (Entry-ak) aldatzen dituen metodoa
    public void modifyLookupAttributes(Entry[] tmpls,Entry[] attrs) {
      try {
          adminbackend.modifyLookupAttributes(tmpls,attrs);
    } catch (RemoteException re) {
      System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
    }
    }





    // Zerbitzuak erabiltzen dituen Lookup Taldeak itzultzen duen metodoa

    public String[] getLookupGroups() {
      String[] stringBat = null;
      try {
          return adminbackend.getLookupGroups();
      } catch (RemoteException re) {
       System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
      }
      return stringBat;
    }

    // Zerbitzuen Lookup Taldeak gehitzen duen metodoa
    public void addLookupGroups(String[] groups) {
      try {
          adminbackend.addLookupGroups(groups);
      } catch (RemoteException re) {
       System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
      }
    }

    // Zerbitzuak erabiltzen dituen Lookup Taldeak ezabatzen duen metodoa
    public void removeLookupGroups(String[] groups) {
      try {
                adminbackend.removeLookupGroups(groups);
      } catch (RemoteException re) {
        System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
      }
    }

    // Zerbitzuak erabiltzen dituen Lookup Taldeak ezartzen duen metodoa
    public void setLookupGroups(String[] groups)  {
      try {
             adminbackend.setLookupGroups(groups);
      } catch (RemoteException re) {
        System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
      }
    }

    // LookUpLocator, Lookup zerbitzuak topatzeaz arduratzen
    // den klasea da. Beraz, metodo honen bitartez lookuplocator
    // guztiak eskuratzen ditugu
    public LookupLocator[] getLookupLocators() {
      LookupLocator[] ll = null;
      try {
        return  adminbackend.getLookupLocators();
      } catch (RemoteException re) {
        System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
      }
      return ll;
    }

    // Metodo honen bitartez, LookupLocator berriak
    // gehitzen ditugu
    public void addLookupLocators(LookupLocator[] locs) {
      try {
             adminbackend.addLookupLocators(locs);
      } catch (RemoteException re) {
      System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
    }
    }

    // Metodo honen bitartez, LookupLocator berriak
    // ezabatzen ditugu
    public void removeLookupLocators(LookupLocator[] locs)  {
       try {
          adminbackend.removeLookupLocators(locs);
      } catch (RemoteException re) {
        System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
      }
    }


    // Metodo honen bitartez, LookupLocator berriak
    // ezartzen ditugu
    public void setLookupLocators(LookupLocator[] locs) {
      try {
           adminbackend.setLookupLocators(locs);
      } catch (RemoteException re) {
        System.err.println("<admin-proxy> Errorea Administrazio backend-ari deia pasatzerakoan: "+re.getMessage());
      }
    }

}
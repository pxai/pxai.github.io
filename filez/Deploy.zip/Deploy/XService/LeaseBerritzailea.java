// Zerbitzuaren Leaseak berritzeaz arduratzen den
// klase 'delegatua'

package zerbitzuak.zerbitzuakv3;

// import gunea
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceRegistration;
import net.jini.core.lease.Lease;
import net.jini.core.lease.UnknownLeaseException;
import net.jini.core.lookup.ServiceItem;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import java.io.IOException;
import java.io.Serializable;


// klasearen deklarazioa
public
class LeaseBerritzailea
extends Thread
 {

    // Atributuak
    // 10 minututako LEASEa
    protected final int LEASE_TIME = 1 * 60 * 1000;
    protected Hashtable registrations;
    protected ServiceItem item;

    // Eraikitzailea
    public LeaseBerritzailea(Hashtable reg) throws IOException {
      registrations = reg;
    }


    // run metodoa Lease-ak mantentzeaz
    // arduratuko da.
    public void run() {
        while (true) {
            try {
                long sleepTime = computeSleepTime();
                Thread.sleep(sleepTime);
                renewLeases(); // hementxe berritzen dira Lease-ak
            } catch (InterruptedException ex) {
            }
        }
    }


    // prozesuaren loaldi denbora tartea prestatu
    protected synchronized long computeSleepTime() {
        long soonestExpiration = Long.MAX_VALUE;
        Enumeration enum = registrations.elements();
        while (enum.hasMoreElements()) {
            Lease l = ((ServiceRegistration) enum.nextElement()).getLease();
            if (l.getExpiration() - (20 * 1000) < soonestExpiration) {
                soonestExpiration = l.getExpiration() - (20 * 1000);
            }
        }

        long now = System.currentTimeMillis();

        if (now >= soonestExpiration) {
            return 0;
        } else {
            return soonestExpiration - now;
        }
    }

    // Lease berritzearen lana egiten duen metodoa.
    protected synchronized void renewLeases() {
        long now = System.currentTimeMillis();
        Vector deadLeases = new Vector();

        Enumeration keys = registrations.keys();
        while (keys.hasMoreElements()) {
            ServiceRegistrar lu = (ServiceRegistrar) keys.nextElement();
            ServiceRegistration r = (ServiceRegistration) registrations.get(lu);
            Lease l = r.getLease();
            if (now <= l.getExpiration() &&
                now >= l.getExpiration() - (20 * 1000)) {
                try {
                    System.out.println("<lease berritzailea>Lease-a berritzen.");
                    l.renew(LEASE_TIME);
                } catch (Exception ex) {
                    System.err.println("Ezin izan dut lease-a berritu: " +
                                       ex.getMessage());
                    deadLeases.addElement(lu);
                }
            }
        }

        // Hil diren Lease-ak garbitzen ditugu.
        for (int i=0, size=deadLeases.size() ; i<size ; i++) {
            registrations.remove(deadLeases.elementAt(i));
        }
    }


}
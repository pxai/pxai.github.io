// Interfaze xinplea zerbitzu administrazioarako

package zerbitzuak.zerbitzuakv3;

// import gunea
import java.rmi.RemoteException;
import java.rmi.Remote;

public
interface RemoteXAdmin
extends JoinKudeatzailea.RemoteUnicastAdmin, XAdmin, Remote {
}

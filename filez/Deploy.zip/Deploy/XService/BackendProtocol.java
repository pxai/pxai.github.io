// Interfaze berezia proxy (bezeroek erabiliko duten objektua) eta
// backend prozesuaren arteko komunikazio protokoloa definitzeko.

package zerbitzuak.zerbitzuakv3;

// import gunea
import net.jini.admin.Administrable;
import java.rmi.RemoteException;
import java.rmi.Remote;

// interfazearen deklarazioa
interface
BackendProtocol
extends Remote, Administrable {

        public String hartuMezua() throws RemoteException;
}


// Entry honen bitartez, zerbitzuaren APIa
// zehazten dugu.

package zerbitzuak.zerbitzuakv3;

// import gunea
import net.jini.entry.AbstractEntry;
import net.jini.lookup.entry.ServiceControlled;
import java.util.Vector;

// klasearen deklarazioa
public class Jinidoc 
extends AbstractEntry 
implements ServiceControlled {
 	// atributuak
 	public Vector atributuak = null;
 	public Vector metodoak = null;
    
    // eraikitzailea
    public Jinidoc() {
    }
    
    // eraikitzailea
    public Jinidoc(Vector atributuak, Vector metodoak) {
    	this.atributuak = atributuak;
    	this.metodoak = metodoak;
    }
}
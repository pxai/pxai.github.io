
package zerbitzuak.zerbitzuakv3;

// import gunea
import java.rmi.Remote;
import net.jini.admin.Administrable;

// interfazearen deklarazioa
public
interface RemoteX
extends Remote, Administrable{
} 
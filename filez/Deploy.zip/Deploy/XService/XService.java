// Hauxe da X zerbitzua. Honek
// proxy objektu bat instalatzen deu Lookup-en
// eta bezeroek erabil dezakete XServiceInterface-k
// definitzen duen hartuMezua() 'zerbitzua' erabiltzeko.
// Kalse honen barruan Interfazea inplementatzen duen proxya dago alde batetik
// eta bestetik proxy hau publikatzen duen Jini zerbitzua: XService klasea.
package zerbitzuak.zerbitzuakv3;

// import gunea

import net.jini.core.lookup.ServiceItem;
import net.jini.core.entry.*;
import net.jini.lookup.entry.*;
import net.jini.core.lease.Lease;
import net.jini.core.lease.UnknownLeaseException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;
import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;
import java.rmi.MarshalledObject;
import java.rmi.RMISecurityManager;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.activation.Activatable;
import java.rmi.activation.ActivationID;
import java.rmi.activation.ActivationDesc;
import java.rmi.activation.ActivationGroup;
import java.rmi.activation.ActivationGroupID;
import java.rmi.activation.ActivationGroupDesc;
import java.rmi.activation.ActivationException;


//XService "wrapper" klasea da
// zerbitzua sarean atzigarri jartzen du.
public class XService implements Runnable {

    // Atributuak


    public ServiceItem item;
    public JoinKudeatzailea joinKudeatzailea;
    public Entry[] entriBat;
    public Entry[] entriBi;
    public EgoeraBerreskuratzailea egoeraBerreskuratzailea;
    protected String informazioFitxategia = "zerbitzu.info";
    protected JoinKudeatzailea.RemoteUnicastAdmin remoteAdmin = null;
    protected String location = "file://deploy/XService";
    protected String objektuAktibagarria = "zerbitzuak.zerbitzuakv3.Backend";




    // Eraikitzailea
    public XService() throws IOException {
        Object proxyObjektua = null;
        egoeraBerreskuratzailea = new EgoeraBerreskuratzailea(informazioFitxategia,proxyObjektua);
        // Join-az (hots, Lookup-ak bilatzeaz) arduratuko den klasea
        // hasieratzen dugu. Public taldean erregistratzen saiatuko da.
        joinKudeatzailea = new JoinKudeatzailea();
        try {
         proxyObjektua = createProxy();
        } catch (IOException ioex) {
          System.err.println("<service> Errorea proxy-a sortzerakoan."+ioex.getMessage());
        }
        item = new ServiceItem(null, proxyObjektua, sortuEntry());

        // aurreko egoera berreskuratzen saiatuko gara...
        egoeraBerreskuratzailea.proxyObjektua = proxyObjektua;
        egoeraBerreskuratzailea.berreskuratu();

        joinKudeatzailea.martxanJarri(this,egoeraBerreskuratzailea.erregistratutakoak);

        // Segurtasun kudeatzaile bat martxan jartzen da.
        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new RMISecurityManager());
        }

    }

    // Entry bat sortzen duen metodoa
	  // Honen bitartez, zerbitzua zenbait atributuekin erregistra
	  // dezakegu...
	  protected Entry[] sortuEntry () {
		  entriBat = new Entry[2];
      Vector atributuak = new Vector(0);
      Vector metodoak = new Vector(0);
      atributuak.addElement("ServiceItem item");
      atributuak.addElement("JiniKudeatzailea jiniKudeatzailea");
      atributuak.addElement("EgoeraBerreskuratzailea egoeraBerreskuratzailea");
      
      metodoak.addElement("Object getAdmin()");
      metodoak.addElement("String hartuMezua()");

		  entriBat[0] = new ServiceInfo("X Zerbitzu Generikoa",
						    "PelloX GeNeRiC Systems ltd.",
						    "PelloX Mikorsystemak ltd.",
						    "v3.0",
						    "X model, xxx",
						    "000-000-x");
		  entriBat[1] = new Jinidoc(atributuak, metodoak);
						    

		  return entriBat;
	  }

    // AWT interfaze itzultzen duen metodoa, Zerbitzuaren Entry-an
    // gordetzeko
    protected Object lortuAWTInterfazea () {
      return null;
    }

    // WAP interfaze itzultzen duen metodoa, Zerbitzuaren Entry-an
    // gordetzeko (esperimentala)
    protected Object lortuWAPInterfazea () {
      return null;
    }


    // run metodoa Lease-ak mantentzeaz
    // arduratuko da.
    public void run() {
        while (true) {
            try {
                Thread.sleep(1000000);
            } catch (InterruptedException ex) {
            }
        }
    }

    public void shutdownZerbitzua (int denbora) {
        System.out.println("Zerbitzua itzaltzera doa!! denbora: "+denbora);
         try {
                Thread.sleep(denbora);
            } catch (InterruptedException ex) {
            }
        System.exit(0);
    }
    // metodo konplexu honen bitartez, proxy objektua itzultzen da
    // baino RMI aktibazioa erabiltzen da.
    protected XServiceInterface createProxy() throws IOException {
        try {
        		// Aktibazio-talde berri batentzat deskribatzailea sortzen
        		// da gure backend objektua bertan exekutarazteko.
            Properties props = new Properties();
            props.put("java.security.policy", "c:\\tmp\\policy");
            ActivationGroupDesc group = new ActivationGroupDesc(props, null);
            // Taldea erregistratzen da eta IDa jasotzen da.
            ActivationGroupID gid =
                ActivationGroup.getSystem().registerGroup(group);
            // Orain taldea sortzen da.
            ActivationGroup.createGroup(gid, group, 0);

            // Aktibazio deskribatzailea sortzen dugu
            // gure objektuarentzat.

            //MarshalledObject data = null;
            MarshalledObject data = new MarshalledObject(joinKudeatzailea);
           
              ActivationDesc desc =
                new ActivationDesc(objektuAktibagarria,
                       location, data);
            // Protokolo inplementatuko duen
            // Backend objektua sortzen dugu.
            BackendProtocol backend =
                (BackendProtocol) Activatable.register(desc);
            return new XServiceProxy(backend);
        } catch (RemoteException ex) {
            System.err.println("Errorea backend objektua sortzerakoan: " +
                               ex.getMessage());
            System.exit(1);
            return null;
        } catch (ActivationException ex) {
            System.err.println("Arazoa aktibazioarekin: " + ex.getMessage());
            ex.printStackTrace();
            System.exit(1);
            return null;
        }
    }


    // XService berria sortu eta bere
    // haria hasieratu.
    public static void main(String args[]) {
        try {
            XService hws = new XService();
            new Thread(hws).start();
        } catch (IOException ex) {
            System.out.println("Ezin izan dut zerbitzua sortu!:" +
                               ex.getMessage());
        }
    }

} // Klasearen bukaera
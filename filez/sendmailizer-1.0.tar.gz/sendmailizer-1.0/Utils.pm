#!/usr/bin/perl

# Sendmailizer
# Autor: Allconnections - Pello Xabier Altadill Izura
# Email: webmaster@allconnections.net
# Internet: http://www.allconnections.net

# Utils.pm utilities and config

package Utils;


## System Constructor
sub new {
    my $class = shift;
    my $self  = { };
    bless($self, $class);
    return $self;
}

## Destroyer method
sub DESTROY {
    my $self = shift;
}

# load config
# Fill an associative array with name=value pairs from a file
#
# arg1 : file
# arg2 : result hash
# arg3 : order
# arg4 : case
sub loadConfig {
	my ($obj,$file, $result, $order, $case) = @_;

	open(ARFILE, $file) || return %result;
	while(<ARFILE>) {
		s/\r|\n//g;
        if (!/^#/ && /^([^=]*)=(.*)$/) {
			$result->{$order ? lc($1) : $1} = $2;
			push(@{$order}, $1) if ($order);
        }
     }
close(ARFILE);
return 1;
}


# finish
sub finish {
	print <<EOF;
Sendmailizer v-1.0 . (C) 2003 Pello Xabier Altadill Izura
Distributed under GPL license - www.allconnections.net
EOF

}

# log
sub log {
	print "Sendmailizer> $_[0]\n";
}



1;
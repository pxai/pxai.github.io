#!/usr/bin/perl

# Sendmailizer.pl
# Author: Allconnections - Pello Xabier Altadill Izura
# Email: webmaster@allconnections.net
# Internet: http://www.allconnections.net
# 
# Some code taken from:
# Maillog2Commonlog v. 3.2 is copyright 1995, 1996 by Joey Hess.
# May be distributed under the terms of the GPL.
# (http://www.gnu.org/copyleft/gpl.html)
#

package Parser;

require User;

my @LOCAL_DOMAINS = ();
# User output
my $USER_FILE = "";

# User data
my %USER_DATA;

## System Constructor
sub new {
    my $class = shift;
    my $self  = { };
    bless($self, $class);
    return $self;
}

## Destroyer method
sub DESTROY {
    my $self = shift;
}

# parse
# parses logfile
sub parse {

my ($obj, $input,$output,$logtype, $domains) = @_;

# Filez for output
my $GENERAL_FILE = $output."/general.report";
$USER_FILE = $output."/";

# DATA hashes: 0: local.first element: inbound, second: outbound
my @GENERAL_DATA = [[0,0,0],[0,0,0]];

my $inout = "";
@LOCAL_DOMAINS = split(/,/,$domains);

my $final_date = "";


# Could use internal localtime function, but it doesn't tell century..
@_=split/ /,`date`;
$year=@_[$#_];
chomp($year);

# Now on to actually processing the logs. Sendmail and smail use very 
# different file formats, sendmail is all on 1 line, smail is a muilt-
# line format that's easier to process, with \n\n seperating each multi-
# line record. And newsmail is ugly ('nuff said..)

if ($logtype eq 'smail') { 
	# read in a whole multi-line record at one go.
	$/="\n\n";
}

if ($logtype=~m/smail/) { 
	# Set up numeric date to Mmm date translation table for smail.
	my $i=1;
	foreach (Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec) { 
		$date_trans[$i++]=$_;
	}
}

# Set Mmm format to numeric format!
if ($logtype=~m/sendmail/) { 
	my $i=1;
	%date_trans = (Jan,'01',Feb,'02',Mar,'03',Apr,'04',May,'05',Jun,'06',Jul,'07',Aug,'08',Sep,'09',Oct,'10',Nov,'11',Dec,'12');
}


open(LOGFILE,$input) or die ("Unable to open log file!!!");

while (<LOGFILE>) {
	# There are 2 distinct log lines types, either mail is being recieved or sent. 
	# We have to combine the 2 lines to get a clear picture of a mail message.
	# For qmail, there ate 3 log line types: mail recieved, delivery 
	# started, and delivery completed.

	if ((/: from=/ ne undef) || (/\] received\n/m ne undef) ||
	    (/\] Received / ne undef) || (/info msg .* from/ ne undef)) { # Recieved mail.
		if (/: from=/ ne undef) { # SENDMAIL and POSTFIX
			($message_id,$from,$size)=m/\w+\s+\d+\s+\d+:\d+:\d+\s+\w+\s+(?:sendmail|postfix\/qmgr)\[\d+\]:\s+(.*?):\s+from=(.*?),\s+size=(.*?),/;
		}
		elsif (/\] received\n/m ne undef) { # SMAIL
			($message_id,$from)=m/^\d+\/\d+\/\d+\s+\d+\:\d+\:\d+\:\s+\[(.*?)\]\s+received\n\|\s+from:\s+(.*?)\n/m;
			($size)=m/\|\s+size:\s+(\d+)\s+bytes\n/m;
		}
		elsif (/\] Received / ne undef) { # NEWSMAIL
			($message_id)=m/\[(.*?)\]/;
			($from)=m/Received FROM:(.*?) /;
			($size)=m/SIZE:(\d+)\s/;
		}
		elsif (/info msg .* from/ ne undef) { # QMAIL
			($message_id,$size,$from)=m/info msg (\d+): bytes (\d+) from <(.*)>/;
		}

		if (!$from) { $from="unknown" }
		$from=clearEmail($from);

		$msg_buf{$message_id}{from}=$from;
		$msg_buf{$message_id}{size}=$size;

		if ($msg_buf{$message_id}{to}) { 
			$inout = &isInboudOutbound($from,$to);
			$GENERAL_DATA[0][$inout] += $size;
			$GENERAL_DATA[1][$inout]++;
			&Log($message_id,$inout);
			# Date String
			$final_date = "$day/$mon/$year $time";
			# Load General DATA:

			# If from is local, save!
			if (&isLocal($from)) {
				#print("$USER_FILE".&getUser($from).".outbound.report ,$message_id,$from,$to,$final_date,$size\n");
				$user = &getUser($from);	
				&saveUserData($USER_FILE.$user.".outbound.report", $user,$message_id, $from, $to, $final_date, $size);
			}

			if (&isLocal($to)) {
				#print("$USER_FILE".&getUser($to).".inbound.report ,$message_id,$from,$to,$final_date,$size\n");
				$user = &getUser($to);	
				&saveUserData($USER_FILE.$user.".inbound.report", $user,$message_id, $from, $to, $final_date, $size);
			}
	
		}
	}
	elsif ((/: to=.*stat(us)?=sent/i ne undef) || (/\] delivered\n/m ne undef) ||
	       (/\] Delivered / ne undef) || (/starting delivery/ ne undef)) { # The line logs mail being sent ok.
		if (/: to=.*stat(us)?=sent/i ne undef) {
			($mon,$day,$time,$message_id,$to)=m/(\w+)\s+(\d+)\s+(\d+:\d+:\d+)\s+\w+\s+(?:sendmail|postfix\/(?:local|smtp))\[.*?\]:\s+(.*?):\s+to=(.*?),/;
			$mon = $date_trans{$mon};
		}
		elsif (/\] delivered\n/m ne undef) {
			($mon,$day,$time,$message_id,$to)=m/(\d+)\/(\d+)\/\d+\s+(\d+:\d+:\d+):\s\[(.*?)\] delivered\n\|\s+to:\s+(.*?)\n/m;
			$mon = $date_trans{$mon};
			#$mon=$date_trans[$mon]; # Translate to Mmm format.
		}
		elsif (/\] Delivered / ne undef) {
			($mon,$day,$time,$message_id)=m/(\d+)\/(\d+)\/\d+\s+(\d+:\d+:\d+):\s\[(.*?)\]/;
			($to)=m/TO:(.*?)\s/;
			$mon = $date_trans{$mon};
			#$mon=$date_trans[$mon]; # Translate to Mmm format.
		}
		elsif (/starting delivery/ ne undef) {
			($mon,$day,$time,$message_id,$to)=m/^(\w+)\s+(\d+)\s+(\d+:\d+:\d+)\s+.*\s+msg\s+(\d+)\s+to\s+.*?\s+(.*)$/;
			$mon = $date_trans{$mon};
		}

		$to=clearEmail($to);
		if (length($day) eq 1 ) { $day="0$day" }

		$msg_buf{$message_id}{mon}=$mon;
		$msg_buf{$message_id}{day}=$day;
		$msg_buf{$message_id}{time}=$time;
		$msg_buf{$message_id}{to}=$to;
				
		if ($msg_buf{$message_id}{from}) { 
			$inout = &isInboudOutbound($from,$to);

			$GENERAL_DATA[0][$inout] += $size;
			$GENERAL_DATA[1][$inout]++;
			&Log($message_id,$inout);
			# Date String
			$final_date = "$day/$mon/$year $time";

			# If from is local, save!
			if (&isLocal($from)) {
				#print("$USER_FILE".&getUser($from).".outbound.report ,$message_id,$from,$to,$final_date,$size\n");
				$user = &getUser($from);	
				&saveUserData($USER_FILE.$user.".outbound.report", user,$message_id, $from, $to, $final_date, $size);
			}

			if (&isLocal($to)) {
				#print("$USER_FILE".&getUser($to).".inbound.report ,$message_id,$from,$to,$final_date,$size\n");
				$user = &getUser($to);	
				&saveUserData($USER_FILE.$user.".inbound.report", $user,$message_id, $from, $to, $final_date, $size);
			}
	

		 }
	}
	
	
	
# Close input file
}#foreach



close($input);

# Print general data:
&log("SIZE local: $GENERAL_DATA[0][0] inbound: $GENERAL_DATA[0][1] outboud: $GENERAL_DATA[0][2])");
&log("EMAIL local: $GENERAL_DATA[1][0] inbound: $GENERAL_DATA[1][1] outboud: $GENERAL_DATA[1][2]");

open(USERLIST,">".$USER_FILE."users") or die ("Couldn't open user file $file!!");
foreach $i (keys(%USER_DATA)) {
	print USERLIST "$i\n"; 
}
close(USERLIST);

return @GENERAL_DATA;
}

# Log
sub Log { my ($message_id,$inout) = @_;
	#print "insert into mail values ('$message_id','$msg_buf{$message_id}{from}','$msg_buf{$message_id}{to}','$year-$msg_buf{$message_id}{mon}-$msg_buf{$message_id}{day} $msg_buf{$message_id}{time}',$msg_buf{$message_id}{size},$inout);\n";
	undef $msg_buf{$message_id};
}

# simple print...
# log
sub log { 
	print "Sendmailizer> $_[0]\n";
}

# clearEmail
sub clearEmail { 
	$_=shift;
	s/[<|>]//g;
	return $_;
}


# getDomain
sub getDomain { 
	$_=shift;
	s/[<|>]//g;
	if (m/\@(.*)$/ ne '') {
		if ($pub_hosts_hash{$1}) { ($_)=m/^(.*)\@/ } else { $_=$1 }
	}
	return $_;
}

# getUser
sub getUser { 
	$_=shift;
	s/[<|>]//g;
	if (m/(.*)$\@/ ne '') {
		if ($pub_hosts_hash{$1}) { ($_)=m/^(.*)\@/ } else { $_=$1 }
	}
	return $_;
}

#isInboudOutbound
# decides if email is inbound or outbound depending on 'local_domain' configuration parameter
sub isInboudOutbound {
        my ($from,$to) = @_;
        $from = getDomain($from);
        $to = getDomain($to);

        #print "\t$from => $to $LOCAL_DOMAINS[0] $LOCAL_DOMAINS[1] $LOCAL_DOMAINS[2]\n"; # Debug

	# Is $from domain a LOCAL DOMAIN?
        my @element = grep { /$from/ } @LOCAL_DOMAINS;
	# Is $to domain a LOCAL DOMAIN?
        my @element2 = grep { /$to/ } @LOCAL_DOMAINS;

	if (($#element > -1) && ($#element2 > -1)) {
	        return 0;
	} else {
	        return (($#element < 0)?"1":"2");
	}
	
} 

# isLocal?
# check if email is from our local domain
sub isLocal {
	my ($email) = @_; 
	my $from = getDomain($email);
    my @element = grep { /$from/ } @LOCAL_DOMAINS;

    return ($#element > -1);

}

#saveUserData
# save user related data to raw file
sub saveUserData {
	my ($file,$user,$id,$from,$to,$date,$size) = @_;

	$USER_DATA{$user} = "";

	open(USERFILE,">> $file") or die ("Couldn't open user file $file!!");

	print USERFILE "$id|$from|$to|$date|$size\n"; 

	#print "$id|$from|$to|$date|$size|  $file \n"; # DEBUG purposes only
	# cerramos el fichero de usuario
	close(USERFILE);

}

1;

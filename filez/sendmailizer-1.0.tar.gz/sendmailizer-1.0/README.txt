Sendmailizer 1.0
alpha release

FOR THE IMPATIENT
1. move where sendmailizer.pl lives
2. Modify sendmailizer.conf (parameters are self-explanatory)
(logfile should be: /var/log/maillog)
(please especify local domains: mydomain.com,mydomain.net...)
3. Try with ./sendmailizer.pl sendmailizer.conf


DESCRIPTION
Sendmailizer performs log analisis from sendmail MTA log files, and generates html based
reports with gd graphics.


TODO
Programming guide.
XML based forms.

Please at this moment don't report bugs,
this is just an pre-alpha-proposal release.
AUTHOR
Pello Xabier Altadill Izura
pello.altadill@ibercom.com

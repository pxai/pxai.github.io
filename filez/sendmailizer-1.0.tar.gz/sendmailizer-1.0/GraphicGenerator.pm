#!/usr/bin/perl

# Sendmailizer
# Autor: Allconnections - Pello Xabier Altadill Izura
# Email: webmaster@allconnections.net
# Internet: http://www.allconnections.net

Package GraphicGenerator;

## System Constructor
sub new {
    my $class = shift;
    my $self  = { };
    bless($self, $class);
    return $self;
}

## Destroyer method
sub DESTROY {
    my $self = shift;
}


1;
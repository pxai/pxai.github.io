#!/usr/bin/perl

# Sendmailizer
# Autor: Allconnections - Pello Xabier Altadill Izura
# Email: webmaster@allconnections.net
# Internet: http://www.allconnections.net

package HTMLGenerator;

my %OUTPUT = {};
my $GENERAL_RESULT;
my @USERLIST;

## System Constructor
sub new {
    my $class = shift;
    my $self  = { };
    bless($self, $class);
    return $self;
}

## Destroyer method
sub DESTROY {
    my $self = shift;
}

# generate_html
# Generate HTML 
sub generate_html {
	my ($obj,$CONFIGURATION, $GENERAL_RESULT) = @_;
	
	# invoke general report
	&general_report($CONFIGURATION,$GENERAL_RESULT);
	
	# invoke per-user report
	&user_report($CONFIGURATION);
}

# general_report
# Generate general report
sub general_report {
	my ($CONFIGURATION,$RESULT) = @_;
open(USER_LIST,"$CONFIGURATION->{output_dir}/users") or die("Couldn't open user list file $!");

$user_html = "<table border=1><tr><th>User List</th></tr>";
while (<USER_LIST>) {
	chop($_);
	push(@USERLIST,$_);
	$user_html .= "<tr><td><a href='$_.html'>$_</a></td></tr>\n";
}

$user_html .= "\n</table>";

close(USER_LIST);

open(GENERAL_REPORT,">$CONFIGURATION->{output_dir}/index.html") or die("Couldn't generate general report file $!");

print GENERAL_REPORT <<EOF;
<html>
<head>
<title>Sendmailizer - Analisis de log de sendmail y MTAs</title>
</head>
<body>
<center><h3>Sendmailizer - Analisis de Log</h3></center>
<table border=1>
<tr><th></th><th>Local</th><th>Entrante</th><th>Saliente<th><th>Total</th></tr>
<tr><td>Total</td><td>$RESULT->[0][0]</td><td>$RESULT->[0][1]</td><td>$RESULT->[0][2]</td><td><td></tr>
<tr><td>Tama&ntilde;o</td><td>$RESULT->[1][0]</td><td>$RESULT->[1][1]</td><td>$RESULT->[1][2]</td><td></td></tr>
</table>
$user_html
<hr size=1>
<center>
Generado por Sendmailizer - v1.0 - (C) 2003 Pello Xabier Altadill Izura<br>
Distributed under GPL - Check for versions at www.pello.info
</center>
</body>
</html>
EOF

close(GENERAL_REPORT);
}

# user_report
# Generate a report per user
sub user_report {
	my ($CONFIGURATION) = @_;
	my $header = "";
	my $inbound = "";
	my $outbound = "";
	my @USERDATA;

#Generacion por usuario
foreach $user (@USERLIST) {
	$header = "";
	$inbound = "";
	$outbound = "";
	@USERDATA = [[0,0],[0,0]];

	print "Sendmailizer> Generating report for $user \n";

	# INBOUND
	open(USERDIR,"$CONFIGURATION->{output_dir}/$user.inbound.report");
	
	$inbound .= "INBOUND<br><table border=1><tr><th>From</th><th>To</th><th>Date</th><th>Size</th></tr>\n";
	while (<USERDIR>){
		chop($_);
		($id,$from,$to,$date,$size) = split(/\|/,$_);
		$inbound .= "<tr><td><a href='$id'>$from -&gt;</td><td>$to</td><td>$date</td><td>$size</td></tr>\n";
		$USERDATA[0][0] += $size;
		$USERDATA[0][1] += $email;
	}
	$inbound .= "</table><hr size=1>\n";

	# cerramos fichero
	close USERDIR;

	# OUTBOUND
	open(USERDIR,"$CONFIGURATION->{output_dir}/$user.outbound.report");
	
	$outbound .= "OUTBOUND<br><table border=1><tr><th>From</th><th>To</th><th>Date</th><th>Size</th></tr>\n";
	while (<USERDIR>){
		chop($_);
		($id,$from,$to,$date,$size) = split(/\|/,$_);
		$outbound .= "<tr><td><a href='$id'>$from -&gt;</td><td>$to</td><td>$date</td><td>$size</td></tr>\n";
		$USERDATA[1][0] += $size;
		$USERDATA[1][1] += $email;
	}
	$outbound .= "</table><hr size=1>\n";
	# cerramos fichero
	close USERDIR;

	# Write output: header + inbound + outbound
	open(RESULT,">$CONFIGURATION->{output_dir}/$user.html") or die("Couldn't write HTML result file for user $user 
: $!");
	# HEADER : once we have calculated totals...
	print RESULT<<EOF;

<html>
<head>
<title>Sendmailizer - Analisis de log de sendmail y MTAs : $user</title>
</head>
<body>
<center><h3>Sendmailizer - Analisis de Log para usuario $user</h3></center>
<table border=1>
<tr><th></th><th>Entrante</th><th>Saliente<th><th>Total</th></tr>
<tr><td>Tama&ntilde;o</td><td>$USERDATA[0][1]</td><td>$USERDATA[1][1]</td><td></td></tr>
<tr><td>Total</td><td>$USERDATA[0][0]</td><td>$USERDATA[1][0]</td><td><td></tr>
</table><hr size=1>
$inbound
$outbound
<center>
Generado por Sendmailizer - v1.0 - (C) 2003 Pello Xabier Altadill Izura<br>
Distributed under GPL - Check for versions at www.pello.info
</center>
</body>
</html>
EOF
	
	close(RESULT);

	print "Sendmailizer> Finished report for $user \n";

}

}


1;


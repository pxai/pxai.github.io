#!/usr/bin/perl

# Sendmailizer.pl
# Autor: Allconnections - Pello Xabier Altadill Izura
# Email: webmaster@allconnections.net
# Internet: http://www.allconnections.net


require Utils;
require Parser;
require HTMLGenerator;

my %CONFIGURATION = {};
my $config_file = "/etc/sendmailizer.conf";
my %RESULT = {};

# If no argument is passed, we use default
$config_file = (!defined($ARGV[0]))?$config_file:$ARGV[0];

Utils::log("loading values from: $config_file");

# First, we must load config values
Utils->new()->loadConfig($config_file,\%CONFIGURATION);

Utils::log($CONFIGURATION{input_file} ." output: " .$CONFIGURATION{'output_dir'});

# Parse file: create object and parse
$parser = Parser->new();
@RESULT = $parser->parse($CONFIGURATION{input_file},$CONFIGURATION{output_dir},$CONFIGURATION{mta},$CONFIGURATION{local_domains});

# Create generator object
$htmlgenerator = HTMLGenerator->new();
# Generate ouput using parsed data
$htmlgenerator->generate_html(\%CONFIGURATION,\@RESULT);

# Generate graphics
#&generate_graphics();

# Finish, give elapsed time, etc..
Utils::finish();

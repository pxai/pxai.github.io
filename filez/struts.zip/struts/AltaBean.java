/**
 * AltaBean.java
 * Pello Xabier Altadill Izura
 */

package pxai.struts.alta.bean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletException;
import com.jazztel.numeracionip.comun.Log;
import com.jazztel.numeracionip.comun.Propiedades;
import com.jazztel.numeracionip.comun.DataService;
import com.jazztel.numeracionip.comun.Data;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import pxai.struts.alta.form.AltaForm;



/**
 * Implementa la l�gica de negocio para el proceso Alta
 * @author Pello Xabier Altadill Izura, AXPE
 * @version 1.0 
 * date 23/1/02
*/
public class AltaBean {

	
	/**
	* @field Constante que identifica el estado libre en la tabla de estados
	*/
	private static final Integer _ESTADO = new Integer(1);


	
	/**
	* alta
	* 
	* Da el alta de un usuario
	* @param formulario con los datos a guardar
	*
	* @return null si no hay errores o ActionErrors con los 
	* errores capturados en caso de error.
	*/
	public synchronized ActionErrors alta (ActionForm theActionForm) {
					
		//Instancia un objrcto ActionErrors para recoger los errores
		ActionErrors theActionErrors = null;
		Connection conn  = null;
		Statement stmn = null;

		try	{
			// Casting de ActionForm a nuestro FORM concreto
			AltaForm form = (AltaForm)theActionForm;
			
			// AQUI SER REALIZA UNA CONEXION A UNA ORIGEN DE DATOS ODBC,
			// PARA INSERTAR EL NUEVO USUARIO. NO RESULTA UNA FORMA MUY CORRECTA
			// DE HACERLO, MENOS AUN EN SERVIDORES DE APLICACIONES Y EN APLICACIONES
			// BIEN ESTRUCTURADAS, PERO PARA SIMPLIFICAR EL EJEMPLO SE HA HECHO ASI.
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			conn = DriverManager.getConnection("jdbc:odbc:usuarios","db_user","db_password");
			
			// CREAMOS la SENTENCIA
			stmn = conn.createStatement();
			// Siii, ya se que es una forma poco elegante de alterar
			// la BBDD, pero se trata de simplificar.
			stmn.executeUpdate("INSERT INTO USUARIOS VALUES ('"+form.getUsername()+"','"+form.getPassword()+"',"+form.getEdad()+",'"+form.getFechanacimiento()+"','"+form.getProfesion()+"')");
			
			// Cerramos sentencia y conexion
			stmn.close();
			conn.close();
			
			// Si llegamos aqui: Devolvemos objeto ActionErrors (nulo == sin error)
			return theActionErrors;			
							
		} catch(Exception e){			
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			theActionErrors = new ActionErrors();
			theActionErrors.add("alta",new ActionError("alta.bean.error"));
			return theActionErrors;
		}
		
	}	//Logica de Negocio
	
	
		
}	// Fin class
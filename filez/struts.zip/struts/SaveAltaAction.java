/**
 * SaveAltaAction.java
 * Pello Xabier Altadill Izura
 */

package pxai.struts.alta.action;

import java.io.IOException;
import java.util.Locale;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;
import pxai.struts.alta.bean.AltaBean;
import com.jazztel.numeracionip.comun.Log;
import com.jazztel.numeracionip.comun.Data;

/**
 * Invoca al bean de l�gica de negocio para procesar la migracion 
 * en caso de encontrar datos validos devuelve un objeto data en
 * la sesi�n.
 * @author Pello Xabier Altadill Izura
 * @version 1.0 , date 13/2/02
*/
public final class SaveAltaAction extends Action {

	/**
	* Procesa la peticion HTTP (request) especificada y genera su correspondiente
	* respuesta HTTP (response) (o lo redirige a otro componente web que podria crear).
	* Devuelve una instancia code>ActionForward</code> que describe a DONDE y COMO
	* se redirige el control, o sino, si la respuesta se ha completado se devolveria
	* <code>null</code>
	*
	* @param mapping El mapeo utilizado para seleccionar esta instancia
	* @param request El request que estamos procesando
	* @param actionForm La instancia ActionForm que estamos utilizando (si la hay)
	* @param response La respuesta HTTP que creamos.
	*
	* @exception IOException en caso de error de entrada/salida (i/o)
	* @exception ServletException en caso de error de servlet
	*/
    public ActionForward perform(ActionMapping mapping,	 ActionForm theForm,
						HttpServletRequest request, HttpServletResponse response)
						throws IOException, ServletException {

		// Extract attributes and parameters we will need
		Locale locale = getLocale(request);
		MessageResources messages = getResources();
		HttpSession session = request.getSession();
		
		String action = request.getParameter("action");
		if (action == null)
		    action = "Create";
	
		ActionErrors errors = null;

		try	{
			/********************** LOGICA DE NEGOCIO *****************************/

			//Instancia el bean de l�gica de negocio				
	        AltaBean theAltaBean = new AltaBean();
			
			//Invoca al proceso de carga y recoge el valor de vuelta
			errors = theAltaBean.alta(theForm);
			
			/********************** FIN de LOGICA DE NEGOCIO **********************/
			
			if (errors==null ) //Se ejecut� correctamente
				return (mapping.findForward("success"));
			else { //Hubo errores
				saveErrors(request,errors);
				return (mapping.findForward("failure"));
			}	
			
		}catch (Exception e) {
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			errors = new ActionErrors();
			errors.add("action",new ActionError("alta.save.error"));
			saveErrors(request,errors);
			return (mapping.findForward("failure"));
		}

    }


}

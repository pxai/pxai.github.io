/**
 * AltaForm.java
 * Pello Xabier Altadill Izura
 */

package pxai.struts.alta.form;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import com.jazztel.numeracionip.comun.IP;
import com.jazztel.numeracionip.comun.Log;
import java.sql.Date;

/**
 * AltaForm
 * 
 * Implementa el formulario de ALTA que se muestra en html 
 * @author   Pello Xabier Altadill Izura
 * @version 1.0 
 * date 13/2/02
*/
public final class AltaForm extends ActionForm  {


	/**
	* @field Mantenimiento de la accion que estamos procesando (Create or Edit).
	* atributo IMPRESCINDIBLE para STRUS
	*/
    private String action = "Create";

	private String username = null;
	private String password = null;
	private Integer edad = null;
	private String fechanacimiento = null;
	private String profesion = null;


	/**
	* Devuelve la accion.
	*
	* @return String la accion
	*/
    public String getAction() {

		return (this.action);
    }


	/**
	* Establece la accion
	*
	* @param action La nueva accion
	*/
    public void setAction(String action) {

        this.action = action;
    }


	/**
	* getUsername
	* Devuelve nombre de usuario
	* @return String
	*/	
	public String getUsername() {
		return (this.username); 
	}
		
	/**
	* setUsername
	* Establece el nombre de usuario
	* @param String
	*/
	public void setUsername(String username) {
		this.username = username; 
	}

	/**
	* getPassword
	* Devuelve el password
	* @return String
	*/	
	public String getPassword() {
		return (this.password); 
	}

	/**
	* setPassword
	* Establece el password
	* @param String
	*/
	public void setPassword(String password) {
		System.out.println("Aqui estamos: " +password);
		this.password = password; 
	}




	/**
	* getEdad
	* Devuelve edad
	* @return Integer
	*/	
	public Integer getEdad() {
		return (this.edad); 
	}

	/**
	* setEdad
	* Establece la edad
	* @param Integer
	*/
	public void setEdad(Integer edad) {
		this.edad = edad; 
	}


	/**
	* getFechanacimiento
	* Devuelve la fecha de nacimiento dd/mm/aaaa
	* @return String
	*/
	public String getFechanacimiento() {
		return (this.fechanacimiento); 
	}
	
	/**
	* setFechanacimiento
	* Establece la fechanacimiento
	* @param String
	*/
	public void setFechanacimiento(String fechanacimiento) {
		this.fechanacimiento = fechanacimiento; 
	}



	/**
	* getProfesion
	* Devuelve la profesion
	* @return String
	*/
	public String getProfesion() {
		return (this.profesion); 
	}

	/**
	* setProfesion
	* Establece la profesion
	* @param String
	*/	
	public void setProfesion(String profesion) {
		this.profesion = profesion; 
	}
	
	

	/**
	* Resetea todas las propiedades a sus valores por defecto.
	*
	* @param mapping El mapping utilizado por la instancia.
	* @param request El servlet request que estamos procesando.
	*/
    public void reset(ActionMapping mapping, HttpServletRequest request) {

        this.action = "Create";


    }


	/**
	* Valida las propiedades asignadas desde el HTTP request
	* y devuelve un objeto <code>ActionErrors</code> que encapsula cualquier
	* validaci�n de error que haya sido encontrada. Si no se han encontrado errores
	* , devuelve <code>null</code> o un objeto <code>ActionErrors</code> sin mensajes
	* de error grabados.
	*
	* @param mapping El mapping utilizado por la instancia.
	* @param request El servlet request que estamos procesando.
	*/
	public ActionErrors validate(ActionMapping mapping,
	                       HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();
		
		if (getUsername().trim().compareTo("") == 0 || getUsername() == null) {
			// El nombre de usuario es nulo, se devuelve mensaje de error
			errors.add("alta",new ActionError("alta.username.nulo"));
		}

		if (getPassword().trim().compareTo("") == 0 || getPassword() == null) {
			// El password es nulo, se devuelve mensaje de error
			errors.add("alta",new ActionError("alta.password.nulo"));
		}

		return errors;

	}


}//class
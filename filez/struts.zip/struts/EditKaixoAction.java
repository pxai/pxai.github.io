/**
 * EditKaixoAction.java
 * Pello Xabier Altadill Izura
 */

package pxai.struts.kaixo.action;


import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Locale;
import java.util.Vector;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;
import org.apache.struts.util.PropertyUtils;
import com.jazztel.numeracionip.comun.Log;



/**
 * EditKaixoAction.java
 * Maneja las peticiones enviadas por el browser 
 * en el url se pondra: /kaixo.do y struts cargara esta clase
 * que redirigira el flujo a una jsp: Kaixo.jsp
 *
 * @author Pello Xabier Altadill Izura
 * @version 1.0 ,date 13/2/02
*/
public final class EditKaixoAction extends Action {



	/**
	* Procesa la peticion HTTP (request) especificada y genera su correspondiente
	* respuesta HTTP (response) (o lo redirige a otro componente web que podria crear).
	* Devuelve una instancia code>ActionForward</code> que describe a DONDE y COMO
	* se redirige el control, o sino, si la respuesta se ha completado se devolveria
	* <code>null</code>
	*
	* @param mapping El mapeo utilizado para seleccionar esta instancia
	* @param request El request que estamos procesando
	* @param actionForm La instancia ActionForm que estamos utilizando (si la hay)
	* @param response La respuesta HTTP que creamos.
	*
	* @exception IOException en caso de error de entrada/salida (i/o)
	* @exception ServletException en caso de error de servlet
	*/
	public ActionForward perform(ActionMapping mapping,
						ActionForm form,
						HttpServletRequest request,
						HttpServletResponse response)
						throws IOException, ServletException {

		// Extrae los atributos que se necesitan
		Locale locale = getLocale(request);
		MessageResources messages = getResources();
		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		ActionErrors errors = null;
				
		try {
		
		if (action == null)
			action = "Create";

		if (servlet.getDebug() >= 1)
			servlet.log("EditKaixoAction:  Procesando action " + action);
		/***** Logica segun el parametro action (no imprescindible)**************/
		/************************************ fin de logica *********************/
		// Redirige el control en caso de exito a la pagina espcificada en struts-config.xml

		if (servlet.getDebug() >= 1)
			servlet.log(" Redirigiendo a pagina 'success'");

		return (mapping.findForward("success"));

		} catch (Exception e) {
			e.printStackTrace(System.out);//Escribe en el fichero de log del servidor de aplicaciones
			errors = new ActionErrors();
			errors.add("action",new ActionError("action.perform.carga.error"));//Se incluye un mensaje de error que se encuentra en el fichero especificado especificado en las propiedades de Struts
			saveErrors(request,errors);
			return (mapping.findForward("failure"));
		}
	}

}
// CountRMI server side

import java.rmi.*;
import java.rmi.server.*;


public class CountRMIServer
{	
	
	public static void main (String args[])	
	{
		System.setSecurityManager(new RMISecurityManager());
		
		try	{
				CountRMIImpl myCount = new CountRMIImpl("my CountRMI");	
				System.out.println("Count Server v0.0 ready to go!");
			} catch (Exception e)
			{System.err.println("Excepcion del sistema!"+e.getMessage());
			 e.printStackTrace();
			}
	}
}
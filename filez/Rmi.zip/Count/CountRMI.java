
// Remote Interface.


public interface CountRMI extends java.rmi.Remote	{

	public int increment() 	throws java.rmi.RemoteException;
	int sum() throws java.rmi.RemoteException;
	void sum (int _val) throws java.rmi.RemoteException;
}
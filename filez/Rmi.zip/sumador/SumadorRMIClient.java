// SumadorRMI client side

import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

public class SumadorRMIClient 
{	
	
	public static void main (String args[])	
	{
		System.setSecurityManager(new RMISecurityManager());
		int sum1, sum2;
		DataInputStream is = new DataInputStream(System.in);		

		try	{
				SumadorRMI myCount = (SumadorRMI)Naming.lookup("rmi://"+
								args[0]+"/"+"Sumador");	
				System.out.println("Setting Sum to 0...");
				myCount.sum(0);
				System.out.println("Inserteme Sum1:");	
				sum1 = Integer.parseInt(is.readLine());
				System.out.println("Inserteme Sum2:");	
				sum2 = Integer.parseInt(is.readLine());	
		
				System.out.println("Incrementing...");
				
				long startTime = System.currentTimeMillis();
				System.out.println("Sum = "+myCount.increment(sum1,sum2));
				long stopTime = System.currentTimeMillis();				
				System.out.println("Execution time start= "+startTime);
				System.out.println("Execution time end= "+stopTime);
				System.out.println("Execution time (msec)= "+(stopTime-startTime)+" mili-secs.");
			} catch (Exception e)
			{System.err.println("Excepcion del sistema!"+e);
			}
		System.exit(0);
	}




}
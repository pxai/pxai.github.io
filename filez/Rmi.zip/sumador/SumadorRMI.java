// Remote Interface.


public interface SumadorRMI extends java.rmi.Remote	{

	public int increment(int val1,int val2) throws java.rmi.RemoteException;
	int sum() throws java.rmi.RemoteException;
	void sum (int _val) throws java.rmi.RemoteException;
}
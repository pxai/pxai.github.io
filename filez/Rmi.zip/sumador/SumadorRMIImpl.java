// SumadorRMI implementation

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

public class SumadorRMIImpl 
extends UnicastRemoteObject 
implements SumadorRMI	
{	
	private int sum;


	public SumadorRMIImpl (String name) 
	throws RemoteException
	{
		super();
		try	{
				Naming.rebind(name,this);
				sum = 0;
			}	catch (Exception e)	{
				System.err.println("Excepci�n: " + e.getMessage());
				e.printStackTrace();
			}
	}
				

	public int sum() 
	throws RemoteException
	{
		return sum;
	}

	public void sum (int val) 
	throws RemoteException
	{
		sum = val;
	}

	public int increment(int val1, int val2) 	
	throws RemoteException
	{	
		return val1+val2;
	}

}
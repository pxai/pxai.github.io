// CountRMI implementation

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

public class CountRMIImpl 
extends UnicastRemoteObject 
implements CountRMI	
{	
	private int sum;
	static int valor = 0;


	public CountRMIImpl (String name) 
	throws RemoteException
	{
		super();
		try	{
				Naming.rebind(name,this);
				sum = 0;
			}	catch (Exception e)	{
				System.err.println("Excepci�n: " + e.getMessage());
				e.printStackTrace();
			}
	}
				

	public int sum() 
	throws RemoteException
	{
		return sum;
	}

	public void sum (int val) 
	throws RemoteException
	{
		sum = val;
	}

	public int increment() 	
	throws RemoteException
	{
		sum++;
		return sum;
	}

	public void darValor (int val) throws java.rmi.RemoteException
	{
		valor = val;
	}

	public int valor () throws java.rmi.RemoteException
	{
		return valor;
	}

}
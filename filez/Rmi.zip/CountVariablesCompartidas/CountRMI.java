
// Remote Interface.


public interface CountRMI extends java.rmi.Remote	{

	static int valor = 0; 	
	
	public int increment() 	throws java.rmi.RemoteException;
	int sum() throws java.rmi.RemoteException;
	public void darValor (int val) throws java.rmi.RemoteException;
	public int valor () throws java.rmi.RemoteException;
	void sum (int _val) throws java.rmi.RemoteException;
}
// CountRMI implementation

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

public class CountRMISeme 
extends CountRMIImpl	
{	
	private int sum;
	static int valor = 0;


	public CountRMISeme (String name) 
	throws RemoteException
	{
		super(name);
		try	{
				Naming.rebind(name,this);
				sum = 0;
			}	catch (Exception e)	{
				System.err.println("Excepci�n: " + e.getMessage());
				e.printStackTrace();
			}
	}
				
}
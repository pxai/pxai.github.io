
import java.awt.*;

//Implementacion del objeto remoto.

public class P

{
	static TextArea tablonPedidos = new TextArea();

// Constructor
public P ()
	{
		super();	
		try {
			System.out.println("Objeto remoto creado!!");
		} catch (Exception x)	{
			System.err.println("Se ha producido una excepcion en el Objeto.");
		}		
	}

// Funcion que debe funcionar solamente en el lado del servidor
public void mostrarVentanaPedidos ()
	{
		Frame ventana = new Frame("Pedidos Pizzeria, v0.1 sicss180");			
			ventana.add(tablonPedidos);
			tablonPedidos.appendText("Esperando pedidos...\n");
			ventana.resize(600,600);
			ventana.show();
	}


public static void main (String args[])
	{
		try {
		P p = new P();
		p.mostrarVentanaPedidos();
		} catch (Exception x) {System.err.println("Error!!!");}
	}
}



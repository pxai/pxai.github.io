//Interfaz del Objeto remoto o servidor de PedidoPizzeria

// Declaracion del paquete.
//package PedidosPizzeria;
import java.rmi.*; 

//Interfaz del objeto remoto.

public interface  PedidoPizzeriaRMI  extends Remote
{
public String MandarPedido (String pedido) throws RemoteException;
}



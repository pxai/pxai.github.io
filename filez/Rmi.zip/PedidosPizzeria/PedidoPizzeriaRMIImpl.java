//Implementacion del Interfaz del Objeto remoto o servidor de PedidoPizzeria

// Declaracion del paquete.
//package PedidosPizzeria;
import java.rmi.*; 
import java.rmi.server.UnicastRemoteObject; 
import java.awt.*;

//Implementacion del objeto remoto.

public class PedidoPizzeriaRMIImpl  
extends UnicastRemoteObject 
implements PedidoPizzeriaRMI
{
	static TextArea tablonPedidos = new TextArea();

// Constructor
public PedidoPizzeriaRMIImpl (String name)
throws RemoteException
	{
		super();	
		try {
			Naming.rebind(name,this);
			System.out.println("Objeto remoto creado!!");
		} catch (Exception x)	{
			System.err.println("Se ha producido una excepcion en el Objeto.");
		}		
	}

// Funcion que debe funcionar solamente en el lado del servidor
public void mostrarVentanaPedidos ()
	{
		Frame ventana = new Frame("Pedidos Pizzeria, v0.1 sicss180");			
			ventana.add(tablonPedidos);
			tablonPedidos.appendText("Esperando pedidos...\n");
			ventana.resize(600,600);
			ventana.show();
	}

// Funcion remota.
public String MandarPedido (String pedido) 
throws RemoteException
	{		
		tablonPedidos.appendText(pedido);
		tablonPedidos.appendText("\n_________________________________________________________\n");
		return("Ok! Ya estamos calentadon su pizza.");
	}
public static void main (String args[])
	{
		try {
		PedidoPizzeriaRMIImpl p = new PedidoPizzeriaRMIImpl("Pedidos");
		p.mostrarVentanaPedidos();
		} catch (RemoteException x) {System.err.println("Error!!!");}
	}
}



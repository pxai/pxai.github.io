import java.applet.*;
import java.awt.*;
import java.rmi.*;


public class PedidoPizzeria extends Applet implements java.awt.event.ActionListener, java.awt.event.ItemListener, java.awt.event.WindowListener {
	private Button ivjButton1 = null;
	private Button ivjButton2 = null;
	private Button ivjButton3 = null;
	private Button ivjButtonCancel1 = null;
	private Button ivjButtonOk = null;
	private Checkbox ivjCheckbox1 = null;
	private Checkbox ivjCheckbox2 = null;
	private Checkbox ivjCheckbox3 = null;
	private Checkbox ivjCheckbox4 = null;
	private Checkbox ivjCheckbox5 = null;
	private Checkbox ivjCheckbox6 = null;
	private Choice ivjChoice11 = null;
	private Choice ivjChoice2 = null;
	private Dialog ivjDialog1 = null;
	private Label ivjLabel1 = null;
	private Label ivjLabel10 = null;
	private Label ivjLabel11 = null;
	private Label ivjLabel2 = null;
	private Label ivjLabel3 = null;
	private Label ivjLabel4 = null;
	private Label ivjLabel5 = null;
	private Label ivjLabel6 = null;
	private Label ivjLabel7 = null;
	private Label ivjLabel8 = null;
	private Label ivjLabelInfoConexion = null;
	private Label ivjLabelPizza = null;
	private Label ivjLabelTama�o = null;
	private List ivjList1 = null;
	private List ivjList2 = null;
	private Panel ivjPanel1 = null;
	private Panel ivjPanel2 = null;
	private GridLayout ivjPanel2GridLayout = null;
	private TextField ivjTextField11 = null;
	private TextField ivjTextField2 = null;
	private TextField ivjTextField3 = null;
	private java.lang.String[] Pizzas = {"Margarita","Rodeo","Ulcerosa","Perforadora","Repetidora",
						"Cuatro Quesos","MegaSicss180","Sicss180 de Luxe","Todo Ajo","Chorizo"};
	private int[] PreciosPizzas = {1000,1250,1315,1390,1475,1590,1700,1890,1975,1315};
	private int[] PreciosTama�os = {0,500,1150,1550,1750};
	private int Tama�o = 0;
	private java.lang.String[] Tama�os = {"Individual","Mediana","Familiar","Perurena","Super Sicss"};
	private int TotalIngredientes = 0;

/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getButton3()) ) {
		conn6(e);
	}
	if ((e.getSource() == getButtonCancel1()) ) {
		conn9(e);
	}
	if ((e.getSource() == getButtonOk()) ) {
		conn10(e);
	}
	if ((e.getSource() == getButtonOk()) ) {
		conn11(e);
	}
	if ((e.getSource() == getButton1()) ) {
		conn12(e);
	}
	// user code begin {2}
	// user code end
}

/**
 * This method was created by a SmartGuide.
 */
private void calcularPrecio() {
	int i;
	int precioFinal = 0;
	int tipo = 0;
	int tama�o = 0;
	int ingredientes = 0;
	
	// Ahora se busca la pizza seleccionada en el array Pizzas
	// que tiene su correspondiente array de precios.
	for (i=0;i<10;i++)
			if (Pizzas[i].equals(getLabelPizza().getText())) break;
	
	// Ahora aplicamos el precio usando el mismo indice de Pizzas
	// para el array preciosPizzas.		
			tipo = PreciosPizzas[i];

	// lo mismo vamos a hacer con los tama�os de las Pizzas
			for (i=0;i<5;i++)
			if (Tama�os[i].equals(getLabelTama�o().getText())) break;
			

	// Ahora aplicamos el precio usando el mismo indice de Tama�os
	// para el array preciosTama�os		
			if (i<5) tama�o = PreciosTama�os[i];
			if (i<5) Tama�o = i + 1; 
			
			precioFinal = tipo + tama�o + (TotalIngredientes * (75*Tama�o));
			
			getLabel10().setText(Integer.toString(precioFinal));
			
			
}
/**
 * conn0:  (Choice11.item.itemStateChanged(java.awt.event.ItemEvent) --> LabelPizza.setText(java.lang.String))
 * @param arg1 java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn0(java.awt.event.ItemEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getLabelPizza().setText(getChoice11().getSelectedItem());
		// user code begin {2}
		calcularPrecio();
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}

/**
 * conn10:  (ButtonOk.action.actionPerformed(java.awt.event.ActionEvent) --> ButtonOk.setEnabled(boolean))
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn10(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getButtonOk().setEnabled(false);
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}

/**
 * conn11:  (ButtonOk.action.actionPerformed(java.awt.event.ActionEvent) --> ButtonCancel1.setVisible(boolean))
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn11(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getButtonCancel1().setVisible(false);
		// user code begin {2}
		mandarMensajeAlServidor();
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}

private void mandarMensajeAlServidor()
{
	String mensaje;
	try {
	// System.setSecurityManager(new RMISecurityManager());
	PedidoPizzeriaRMI myPedido = (PedidoPizzeriaRMI)Naming.lookup("rmi://sicss180/"+"Pedido Pizzeria");	
	mensaje = "Pedido para: " + getTextField11().getText() +"\n";
	mensaje = mensaje + "Direccion: " + getTextField3().getText() +"\n";
	mensaje = mensaje + "Telefono: " + getTextField2().getText() +"\n";
	mensaje = mensaje + "Pizza: " + getLabelPizza().getText() +"\n";
	mensaje = mensaje + "Tama�o: " + getLabelTama�o().getText() +"\n";
	mensaje = mensaje + "Ingredientes adicionales: ";

	for(int i=0;i<TotalIngredientes;i++)
		mensaje = mensaje + getList1().getItem(i) +", ";

	mensaje = mensaje + "\nOtros ingredientes: ";

	if (getCheckbox1().getState()) mensaje = mensaje + getCheckbox1().getLabel()+",";
	if (getCheckbox2().getState()) mensaje = mensaje + getCheckbox2().getLabel()+",";
	if (getCheckbox3().getState()) mensaje = mensaje + getCheckbox3().getLabel()+",";
	if (getCheckbox4().getState()) mensaje = mensaje + getCheckbox4().getLabel()+",";
	if (getCheckbox5().getState()) mensaje = mensaje + getCheckbox5().getLabel()+",";
	if (getCheckbox6().getState()) mensaje = mensaje + getCheckbox6().getLabel()+",";
	mensaje = mensaje + ".\n";
	System.out.println(mensaje);

	getLabelInfoConexion().setText(myPedido.MandarPedido(mensaje));

	} catch (Exception x)	{
			getLabelInfoConexion().setText("Error: "+x.getMessage());
		}
}

/**
 * conn12:  (Button1.action.actionPerformed(java.awt.event.ActionEvent) --> Dialog1.show())
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn12(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDialog1().show();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}

/**
 * conn2:  (Choice2.item.itemStateChanged(java.awt.event.ItemEvent) --> LabelTama�o.setText(java.lang.String))
 * @param arg1 java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn2(java.awt.event.ItemEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getLabelTama�o().setText(getChoice2().getSelectedItem());
		// user code begin {2}
		calcularPrecio();
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}

/**
 * conn4:  (List1.item.itemStateChanged(java.awt.event.ItemEvent) --> List2.addItem(java.lang.String))
 * @param arg1 java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn4(java.awt.event.ItemEvent arg1) {
	
	try {
		// user code begin {1}		
		// user code end
		getList2().addItem(getList1().getSelectedItem());
		// user code begin {2}
		TotalIngredientes ++;
		calcularPrecio();
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// Se calcula el precio por ingrediente a�adido
		// user code end
		handleException(ivjExc);
	}
}

/**
 * conn6:  (Button3.action.actionPerformed(java.awt.event.ActionEvent) --> List2.remove(java.lang.String))
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn6(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getList2().remove(getList2().getSelectedItem());
		// user code begin {2}
		TotalIngredientes--;			
		calcularPrecio();
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}

/**
 * conn8:  (Dialog1.window.windowClosing(java.awt.event.WindowEvent) --> Dialog1.dispose())
 * @param arg1 java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn8(java.awt.event.WindowEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDialog1().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}

/**
 * conn9:  (ButtonCancel1.action.actionPerformed(java.awt.event.ActionEvent) --> Dialog1.dispose())
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn9(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDialog1().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}

/**
 * Gets the applet information.
 * @return java.lang.String
 */
public String getAppletInfo() {
	return "PedidoPizzeria created by sicss180, Java Dept. using VisualAge for Java.";
}

/**
 * Return the Button1 property value.
 * @return java.awt.Button
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Button getButton1() {
	if (ivjButton1 == null) {
		try {
			ivjButton1 = new java.awt.Button();
			ivjButton1.setName("Button1");
			ivjButton1.setBounds(100, 324, 125, 30);
			ivjButton1.setLabel("Enviar Pedido");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjButton1;
}

/**
 * Return the Button2 property value.
 * @return java.awt.Button
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Button getButton2() {
	if (ivjButton2 == null) {
		try {
			ivjButton2 = new java.awt.Button();
			ivjButton2.setName("Button2");
			ivjButton2.setBounds(225, 324, 125, 30);
			ivjButton2.setLabel("Borrar Todo");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjButton2;
}

/**
 * Return the Button3 property value.
 * @return java.awt.Button
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Button getButton3() {
	if (ivjButton3 == null) {
		try {
			ivjButton3 = new java.awt.Button();
			ivjButton3.setName("Button3");
			ivjButton3.setBounds(491, 122, 69, 31);
			ivjButton3.setLabel("Quitar");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjButton3;
}

/**
 * Return the ButtonCancel1 property value.
 * @return java.awt.Button
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Button getButtonCancel1() {
	if (ivjButtonCancel1 == null) {
		try {
			ivjButtonCancel1 = new java.awt.Button();
			ivjButtonCancel1.setName("ButtonCancel1");
			ivjButtonCancel1.setLabel("Cancel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjButtonCancel1;
}

/**
 * Return the ButtonOk property value.
 * @return java.awt.Button
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Button getButtonOk() {
	if (ivjButtonOk == null) {
		try {
			ivjButtonOk = new java.awt.Button();
			ivjButtonOk.setName("ButtonOk");
			ivjButtonOk.setLabel("OK");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjButtonOk;
}

/**
 * Return the Checkbox1 property value.
 * @return java.awt.Checkbox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Checkbox getCheckbox1() {
	if (ivjCheckbox1 == null) {
		try {
			ivjCheckbox1 = new java.awt.Checkbox();
			ivjCheckbox1.setName("Checkbox1");
			ivjCheckbox1.setBounds(329, 214, 125, 30);
			ivjCheckbox1.setLabel("Or�gano");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCheckbox1;
}

/**
 * Return the Checkbox2 property value.
 * @return java.awt.Checkbox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Checkbox getCheckbox2() {
	if (ivjCheckbox2 == null) {
		try {
			ivjCheckbox2 = new java.awt.Checkbox();
			ivjCheckbox2.setName("Checkbox2");
			ivjCheckbox2.setBounds(329, 240, 125, 30);
			ivjCheckbox2.setLabel("Ajo");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCheckbox2;
}

/**
 * Return the Checkbox3 property value.
 * @return java.awt.Checkbox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Checkbox getCheckbox3() {
	if (ivjCheckbox3 == null) {
		try {
			ivjCheckbox3 = new java.awt.Checkbox();
			ivjCheckbox3.setName("Checkbox3");
			ivjCheckbox3.setBounds(329, 268, 125, 30);
			ivjCheckbox3.setLabel("Albahaca");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCheckbox3;
}

/**
 * Return the Checkbox4 property value.
 * @return java.awt.Checkbox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Checkbox getCheckbox4() {
	if (ivjCheckbox4 == null) {
		try {
			ivjCheckbox4 = new java.awt.Checkbox();
			ivjCheckbox4.setName("Checkbox4");
			ivjCheckbox4.setBounds(415, 214, 125, 30);
			ivjCheckbox4.setLabel("Aceite de oliva");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCheckbox4;
}

/**
 * Return the Checkbox5 property value.
 * @return java.awt.Checkbox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Checkbox getCheckbox5() {
	if (ivjCheckbox5 == null) {
		try {
			ivjCheckbox5 = new java.awt.Checkbox();
			ivjCheckbox5.setName("Checkbox5");
			ivjCheckbox5.setBounds(416, 240, 125, 30);
			ivjCheckbox5.setLabel("Sin tomate");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCheckbox5;
}

/**
 * Return the Checkbox6 property value.
 * @return java.awt.Checkbox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Checkbox getCheckbox6() {
	if (ivjCheckbox6 == null) {
		try {
			ivjCheckbox6 = new java.awt.Checkbox();
			ivjCheckbox6.setName("Checkbox6");
			ivjCheckbox6.setBounds(415, 267, 125, 30);
			ivjCheckbox6.setLabel("M�s ajo!!");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCheckbox6;
}

/**
 * Return the Choice11 property value.
 * @return java.awt.Choice
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Choice getChoice11() {
	if (ivjChoice11 == null) {
		try {
			ivjChoice11 = new java.awt.Choice();
			ivjChoice11.setName("Choice11");
			ivjChoice11.setBackground(java.awt.Color.white);
			ivjChoice11.setBounds(161, 176, 126, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjChoice11;
}

/**
 * Return the Choice2 property value.
 * @return java.awt.Choice
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Choice getChoice2() {
	if (ivjChoice2 == null) {
		try {
			ivjChoice2 = new java.awt.Choice();
			ivjChoice2.setName("Choice2");
			ivjChoice2.setBackground(java.awt.Color.white);
			ivjChoice2.setBounds(395, 176, 125, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjChoice2;
}

/**
 * Return the Dialog1 property value.
 * @return java.awt.Dialog
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Dialog getDialog1() {
	if (ivjDialog1 == null) {
		try {
			ivjDialog1 = new java.awt.Dialog(new java.awt.Frame());
			ivjDialog1.setName("Dialog1");
			ivjDialog1.setLayout(null);
			ivjDialog1.setBounds(103, 366, 389, 131);
			ivjDialog1.setTitle("Confirmacion de Pedido");
			ivjDialog1.add(getPanel1(), getPanel1().getName());
			ivjDialog1.setResizable(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDialog1;
}

/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setAlignment(java.awt.Label.RIGHT);
			ivjLabel1.setText("Nombre:");
			ivjLabel1.setBounds(34, 58, 125, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabel1;
}

/**
 * Return the Label10 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabel10() {
	if (ivjLabel10 == null) {
		try {
			ivjLabel10 = new java.awt.Label();
			ivjLabel10.setName("Label10");
			ivjLabel10.setFont(new java.awt.Font("dialog", 1, 26));
			ivjLabel10.setAlignment(java.awt.Label.RIGHT);
			ivjLabel10.setText("0");
			ivjLabel10.setBounds(388, 305, 115, 48);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabel10;
}

/**
 * Return the Label11 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabel11() {
	if (ivjLabel11 == null) {
		try {
			ivjLabel11 = new java.awt.Label();
			ivjLabel11.setName("Label11");
			ivjLabel11.setFont(new java.awt.Font("dialog", 1, 16));
			ivjLabel11.setText("Ptas.");
			ivjLabel11.setBounds(511, 321, 52, 32);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabel11;
}

/**
 * Return the Label2 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabel2() {
	if (ivjLabel2 == null) {
		try {
			ivjLabel2 = new java.awt.Label();
			ivjLabel2.setName("Label2");
			ivjLabel2.setAlignment(java.awt.Label.RIGHT);
			ivjLabel2.setText("Telefono:");
			ivjLabel2.setBounds(34, 90, 125, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabel2;
}

/**
 * Return the Label3 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabel3() {
	if (ivjLabel3 == null) {
		try {
			ivjLabel3 = new java.awt.Label();
			ivjLabel3.setName("Label3");
			ivjLabel3.setAlignment(java.awt.Label.RIGHT);
			ivjLabel3.setText("Direcci�n:");
			ivjLabel3.setBounds(34, 124, 125, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabel3;
}

/**
 * Return the Label4 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabel4() {
	if (ivjLabel4 == null) {
		try {
			ivjLabel4 = new java.awt.Label();
			ivjLabel4.setName("Label4");
			ivjLabel4.setAlignment(java.awt.Label.RIGHT);
			ivjLabel4.setText("Pizza:");
			ivjLabel4.setBounds(34, 174, 125, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabel4;
}

/**
 * Return the Label5 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabel5() {
	if (ivjLabel5 == null) {
		try {
			ivjLabel5 = new java.awt.Label();
			ivjLabel5.setName("Label5");
			ivjLabel5.setAlignment(java.awt.Label.RIGHT);
			ivjLabel5.setText("Tama�o:");
			ivjLabel5.setBounds(302, 175, 89, 28);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabel5;
}

/**
 * Return the Label6 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabel6() {
	if (ivjLabel6 == null) {
		try {
			ivjLabel6 = new java.awt.Label();
			ivjLabel6.setName("Label6");
			ivjLabel6.setText("Ingredientes Adicionales:");
			ivjLabel6.setBounds(21, 216, 138, 31);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabel6;
}

/**
 * Return the Label7 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabel7() {
	if (ivjLabel7 == null) {
		try {
			ivjLabel7 = new java.awt.Label();
			ivjLabel7.setName("Label7");
			ivjLabel7.setFont(new java.awt.Font("helvetica", 1, 20));
			ivjLabel7.setAlignment(java.awt.Label.CENTER);
			ivjLabel7.setText("Pedido de Pizza");
			ivjLabel7.setBounds(129, 9, 247, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabel7;
}

/**
 * Return the Label8 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabel8() {
	if (ivjLabel8 == null) {
		try {
			ivjLabel8 = new java.awt.Label();
			ivjLabel8.setName("Label8");
			ivjLabel8.setFont(new java.awt.Font("helvetica", 1, 14));
			ivjLabel8.setText("Su pedido ser� enviado.  � Esta seguro ?");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabel8;
}

/**
 * Return the LabelInfoConexion property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabelInfoConexion() {
	if (ivjLabelInfoConexion == null) {
		try {
			ivjLabelInfoConexion = new java.awt.Label();
			ivjLabelInfoConexion.setName("LabelInfoConexion");
			ivjLabelInfoConexion.setText("");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabelInfoConexion;
}

/**
 * Return the LabelPizza property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabelPizza() {
	if (ivjLabelPizza == null) {
		try {
			ivjLabelPizza = new java.awt.Label();
			ivjLabelPizza.setName("LabelPizza");
			ivjLabelPizza.setText("");
			ivjLabelPizza.setBounds(394, 32, 166, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabelPizza;
}

/**
 * Return the LabelTama�o property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabelTama�o() {
	if (ivjLabelTama�o == null) {
		try {
			ivjLabelTama�o = new java.awt.Label();
			ivjLabelTama�o.setName("LabelTama�o");
			ivjLabelTama�o.setText("");
			ivjLabelTama�o.setBounds(394, 56, 166, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjLabelTama�o;
}

/**
 * Return the List1 property value.
 * @return java.awt.List
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private List getList1() {
	if (ivjList1 == null) {
		try {
			ivjList1 = new java.awt.List();
			ivjList1.setName("List1");
			ivjList1.setBackground(java.awt.Color.white);
			ivjList1.setBounds(161, 223, 126, 75);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjList1;
}

/**
 * Return the List2 property value.
 * @return java.awt.List
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private List getList2() {
	if (ivjList2 == null) {
		try {
			ivjList2 = new java.awt.List();
			ivjList2.setName("List2");
			ivjList2.setBounds(394, 92, 166, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjList2;
}

/**
 * Return the Panel1 property value.
 * @return java.awt.Panel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Panel getPanel1() {
	if (ivjPanel1 == null) {
		try {
			ivjPanel1 = new java.awt.Panel();
			ivjPanel1.setName("Panel1");
			ivjPanel1.setLayout(new java.awt.BorderLayout());
			ivjPanel1.setBounds(15, 8, 357, 107);
			getPanel1().add("North", getLabel8());
			getPanel1().add("Center", getPanel2());
			getPanel1().add("South", getLabelInfoConexion());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjPanel1;
}

/**
 * Return the Panel2 property value.
 * @return java.awt.Panel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Panel getPanel2() {
	if (ivjPanel2 == null) {
		try {
			ivjPanel2 = new java.awt.Panel();
			ivjPanel2.setName("Panel2");
			ivjPanel2.setLayout(getPanel2GridLayout());
			ivjPanel2.add(getButtonOk(), getButtonOk().getName());
			ivjPanel2.add(getButtonCancel1(), getButtonCancel1().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjPanel2;
}

/**
 * Return the Panel2GridLayout property value.
 * @return java.awt.GridLayout
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private GridLayout getPanel2GridLayout() {
	java.awt.GridLayout ivjPanel2GridLayout = null;
	try {
		/* Create part */
		ivjPanel2GridLayout = new java.awt.GridLayout();
		ivjPanel2GridLayout.setVgap(1);
		ivjPanel2GridLayout.setHgap(2);
		ivjPanel2GridLayout.setColumns(2);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjPanel2GridLayout;
}

/**
 * Return the TextField11 property value.
 * @return java.awt.TextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private TextField getTextField11() {
	if (ivjTextField11 == null) {
		try {
			ivjTextField11 = new java.awt.TextField();
			ivjTextField11.setName("TextField11");
			ivjTextField11.setFont(new java.awt.Font("dialog", 0, 14));
			ivjTextField11.setBackground(java.awt.Color.white);
			ivjTextField11.setBounds(159, 58, 125, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjTextField11;
}

/**
 * Return the TextField2 property value.
 * @return java.awt.TextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private TextField getTextField2() {
	if (ivjTextField2 == null) {
		try {
			ivjTextField2 = new java.awt.TextField();
			ivjTextField2.setName("TextField2");
			ivjTextField2.setFont(new java.awt.Font("dialog", 0, 14));
			ivjTextField2.setBackground(java.awt.Color.white);
			ivjTextField2.setBounds(159, 89, 126, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjTextField2;
}

/**
 * Return the TextField3 property value.
 * @return java.awt.TextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private TextField getTextField3() {
	if (ivjTextField3 == null) {
		try {
			ivjTextField3 = new java.awt.TextField();
			ivjTextField3.setName("TextField3");
			ivjTextField3.setFont(new java.awt.Font("dialog", 0, 14));
			ivjTextField3.setBackground(java.awt.Color.white);
			ivjTextField3.setBounds(159, 119, 201, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjTextField3;
}

/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}

/**
 * This method was created by a SmartGuide.
 */
private void iniciarChoices( ) {
	getChoice11().addItem("Margarita");
	getChoice11().addItem("Rodeo");
	getChoice11().addItem("Ulcerosa");
	getChoice11().addItem("Perforadora");
	getChoice11().addItem("Repetidora");
	getChoice11().addItem("Cuatro Quesos");
	getChoice11().addItem("MegaSicss180");
	getChoice11().addItem("Sicss180 de Luxe");
	getChoice11().addItem("Todo Ajo");
	getChoice11().addItem("Chorizo");
	getChoice2().addItem("Individual");
	getChoice2().addItem("Mediana");
	getChoice2().addItem("Familiar");
	getChoice2().addItem("Perurena");
	getChoice2().addItem("Super Sicss");

	

}
/**
 * This method was created by a SmartGuide.
 */
private void iniciarLista( ) {
	getList1().addItem("Doble queso");
	getList1().addItem("Pepperoni");
	getList1().addItem("Ajo");
	getList1().addItem("Bacon");
	getList1().addItem("Jamon");
	getList1().addItem("Salsa Rodeo");
	getList1().addItem("Salchichas");
	getList1().addItem("Txistorra");
	getList1().addItem("At�n");
	getList1().addItem("Pimiento Vaerde");
	getList1().addItem("Pimiento Rojo");
	getList1().addItem("Esparragos");
	getList1().addItem("Vodka con limon");
	
	
	
}
/**
 * Handle the Applet init method.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void init() {
	super.init();
	try {
		setName("PedidoPizzeria");
		setLayout(null);
		setBackground(java.awt.Color.lightGray);
		setSize(572, 366);
		add(getTextField2(), getTextField2().getName());
		add(getTextField3(), getTextField3().getName());
		add(getLabel1(), getLabel1().getName());
		add(getLabel2(), getLabel2().getName());
		add(getLabel3(), getLabel3().getName());
		add(getTextField11(), getTextField11().getName());
		add(getChoice2(), getChoice2().getName());
		add(getChoice11(), getChoice11().getName());
		add(getLabel4(), getLabel4().getName());
		add(getLabel5(), getLabel5().getName());
		add(getLabel6(), getLabel6().getName());
		add(getList1(), getList1().getName());
		add(getCheckbox1(), getCheckbox1().getName());
		add(getCheckbox2(), getCheckbox2().getName());
		add(getCheckbox3(), getCheckbox3().getName());
		add(getCheckbox4(), getCheckbox4().getName());
		add(getCheckbox5(), getCheckbox5().getName());
		add(getCheckbox6(), getCheckbox6().getName());
		add(getButton1(), getButton1().getName());
		add(getButton2(), getButton2().getName());
		add(getLabelPizza(), getLabelPizza().getName());
		add(getLabelTama�o(), getLabelTama�o().getName());
		add(getLabel10(), getLabel10().getName());
		add(getLabel11(), getLabel11().getName());
		add(getList2(), getList2().getName());
		add(getLabel7(), getLabel7().getName());
		add(getButton3(), getButton3().getName());
		initConnections();
		// user code begin {1}
		iniciarChoices();
		iniciarLista();
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {2}
		// user code end
		handleException(ivjExc);
	}
}

/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getChoice11().addItemListener(this);
	getChoice2().addItemListener(this);
	getList1().addItemListener(this);
	getButton3().addActionListener(this);
	getDialog1().addWindowListener(this);
	getButtonCancel1().addActionListener(this);
	getButtonOk().addActionListener(this);
	getButton1().addActionListener(this);
}

/**
 * Method to handle events for the ItemListener interface.
 * @param e java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void itemStateChanged(java.awt.event.ItemEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getChoice11()) ) {
		conn0(e);
	}
	if ((e.getSource() == getChoice2()) ) {
		conn2(e);
	}
	if ((e.getSource() == getList1()) ) {
		conn4(e);
	}
	// user code begin {2}
	// user code end
}

/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		PedidoPizzeria aPedidoPizzeria = new PedidoPizzeria();
		frame.add("Center", aPedidoPizzeria);
		frame.setSize(aPedidoPizzeria.getSize());
		aPedidoPizzeria.init();
		aPedidoPizzeria.start();
		frame.resize(600,600);
		frame.setVisible(true);

		aPedidoPizzeria.destroy();
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.applet.Applet");
	}
}

/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowActivated(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}

/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowClosed(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}

/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowClosing(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getDialog1()) ) {
		conn8(e);
	}
	// user code begin {2}
	// user code end
}

/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowDeactivated(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}

/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowDeiconified(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}

/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowIconified(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}

/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowOpened(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}

}
//Servidor de PedidoPizzeria


import java.rmi.*; 
import java.rmi.server.*; 

//Servidor del objeto remoto.

public class PedidoPizzeriaRMIServer 
{

public static void main (String args[]) 
	{
		System.setSecurityManager(new RMISecurityManager());
		try	{
				PedidoPizzeriaRMIImpl myPedido = new PedidoPizzeriaRMIImpl("Pedido Pizzeria");
				myPedido.mostrarVentanaPedidos();	
				System.out.println("Pedidos Pizzas Server v0.0 ready to go!");
			} catch (Exception e)
			{System.err.println("Excepcion del sistema!"+e.getMessage());
			 e.printStackTrace();
			}
		
	}

}



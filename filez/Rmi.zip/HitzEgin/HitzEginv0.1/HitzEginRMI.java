
// Remote Interface.


public interface HitzEginRMI extends java.rmi.Remote	{
	
	public void idatzi (String testua) throws java.rmi.RemoteException;
	public void  sartu (String izena) throws java.rmi.RemoteException;
	public void  atera (String izena) throws java.rmi.RemoteException;
	public java.awt.List getivjList () throws java.rmi.RemoteException;	
	public java.awt.TextArea getivjTextArea () throws java.rmi.RemoteException;
	public String  esaldia () throws java.rmi.RemoteException;
}
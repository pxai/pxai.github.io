// HitzEginRMI implementation
import java.awt.*;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

public class HitzEginRMIImpl 
extends UnicastRemoteObject 
implements HitzEginRMI	
{	
	static String esaldia = null;	

	static TextArea ivjTextArea = new TextArea();
		
	static List ivjList = new java.awt.List();

	public HitzEginRMIImpl (String name) 
	throws RemoteException
	{
		super();
		try	{
				Naming.rebind(name,this);				
			}	catch (Exception e)	{
				System.err.println("Excepci�n: " + e.getMessage());
				e.printStackTrace();
			}		
	}
				
	public void idatzi (String testua) throws java.rmi.RemoteException
	{
		ivjTextArea.appendText(testua);
	}

	public void  sartu (String izena) throws java.rmi.RemoteException
	{	
		ivjList.addItem(izena);
	}

	public void  atera (String izena) throws java.rmi.RemoteException
	{
		ivjList.remove(izena);
	}

	public List  getivjList () throws java.rmi.RemoteException
	{
		return ivjList;		
	}

	public TextArea  getivjTextArea () throws java.rmi.RemoteException
	{
		return ivjTextArea;
	}

	public String  esaldia () throws java.rmi.RemoteException
	{
		return esaldia;
	}
}
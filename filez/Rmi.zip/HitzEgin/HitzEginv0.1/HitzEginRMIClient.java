// HitzEginRMI client side

import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.io.*;

public class HitzEginRMIClient 
{	
	
	public static void main (String args[])	
	{
		System.setSecurityManager(new RMISecurityManager());
		
		try	{	int sum1;
				HitzEginRMI myCount = (HitzEginRMI)Naming.lookup("rmi://"+
								args[0]+"/"+"my CountRMI");	

				DataInputStream is = new DataInputStream(System.in);		

				System.out.println("Setting Sum to 0...");
				myCount.sum(0);
				long startTime = System.currentTimeMillis();
				System.out.println("Incrementing...");
				for (int i=0;i<1000;i++) myCount.increment();
				long stopTime = System.currentTimeMillis();
				System.out.println("Sum = "+myCount.sum());

				// Goazen klase aldagaia aldatzera...
				System.out.println("Valor Actual:"+myCount.valor());	
				System.out.println("Inserteme un valor:");	
				sum1 = Integer.parseInt(is.readLine());
				myCount.darValor(sum1);
				System.out.println("Nuevo valor:"+myCount.valor());	

			} catch (Exception e)
			{System.err.println("Excepcion del sistema!"+e);
			}
		System.exit(0);
	}




}
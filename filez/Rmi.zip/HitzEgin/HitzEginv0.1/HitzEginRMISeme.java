// HitzEginRMI implementation son

import java.rmi.*;

public class HitzEginRMISeme 
extends HitzEginRMIImpl	
{	
	public HitzEginRMISeme (String name) 
	throws RemoteException
	{
		super(name);
		try	{
				Naming.rebind(name,this);			
			}	catch (Exception e)	{
				System.err.println("Excepci�n: " + e.getMessage());
				e.printStackTrace();
			}
	}
				
}
// HitzEginRMI server side

import java.rmi.*;
import java.rmi.server.*;


public class HitzEginRMIServer
{	
	
	public static void main (String args[])	
	{
		System.setSecurityManager(new RMISecurityManager());
		
		try	{
				HitzEginRMISeme myCount = new HitzEginRMISeme("my CountRMI");	
				System.out.println("HitzEgin Server v0.0 ready to go!");
			} catch (Exception e)
			{System.err.println("Excepcion del sistema!"+e.getMessage());
			 e.printStackTrace();
			}
	}
}
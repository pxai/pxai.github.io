import java.rmi.*;
import java.applet.*;
import java.awt.*;


public class HitzEgin extends Applet implements java.awt.event.ActionListener, java.awt.event.TextListener {
	private Button ivjButtonConexion = null;
	private Label ivjLabel1 = null;
	private Label ivjLabelUsers = null;
	private Label ivjLabelUsers1 = null;
	private List ivjList1 = null;
	private TextArea ivjTextArea1 = null;
	private TextField ivjTextFieldHitz = null;
	private TextField ivjTextFieldNick = null;
	private HitzEginRMI myCount = null;
	private String izena;


public void actionPerformed(java.awt.event.ActionEvent e) {
	
	if ((e.getSource() == getButtonConexion()) ) {
		conn1(e);
	}
	if ((e.getSource() == getTextFieldHitz()) ) {
		conn2(e);
	}
	if ((e.getSource() == getButtonConexion()) ) {
		conn3(e);
	}
	if ((e.getSource() == getButtonConexion()) ) {
		conn4(e);
	}
	
}

/**
 * conn0:  (TextFieldNick.text.textValueChanged(java.awt.event.TextEvent) --> ButtonConexion.enabled)
 * @param arg1 java.awt.event.TextEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn0(java.awt.event.TextEvent arg1) {
	try {
		getButtonConexion().setEnabled(true);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}

/**
 * conn1:  (ButtonConexion.action.actionPerformed(java.awt.event.ActionEvent) --> TextFieldHitz.setEditable(boolean))
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn1(java.awt.event.ActionEvent arg1) {
	try {
		getTextFieldHitz().setEditable(true);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}

/**
 * conn2:  (TextFieldHitz.action.actionPerformed(java.awt.event.ActionEvent) --> TextFieldHitz.setText(java.lang.String))
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn2(java.awt.event.ActionEvent arg1) {
	try {
		
		myCount.idatzi(izena + ">> "+ getTextFieldHitz().getText()+"\n");
		getTextArea1().appendText(izena + ">> "+ getTextFieldHitz().getText()+"\n");
				
		getTextFieldHitz().setText("");
		ivjTextArea1.setText("");
		getTextArea1().appendText(myCount.getivjTextArea().getText());	
		System.out.println("Ondo goaz.");
		
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}

/**
 * conn3:  (ButtonConexion.action.actionPerformed(java.awt.event.ActionEvent) --> TextFieldNick.setVisible(boolean))
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn3(java.awt.event.ActionEvent arg1) {
	try {
		izena = getTextFieldNick().getText();
		getTextFieldNick().setVisible(false);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}

/**
 * conn4:  (ButtonConexion.action.actionPerformed(java.awt.event.ActionEvent) --> ButtonConexion.setVisible(boolean))
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn4(java.awt.event.ActionEvent arg1) {
	try {
		getButtonConexion().setVisible(false);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}

/**
 * conn5:  (TextArea1.text.textValueChanged(java.awt.event.TextEvent) --> TextArea1.getText())
 * @return java.lang.String
 * @param arg1 java.awt.event.TextEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private String conn5(java.awt.event.TextEvent arg1) {
	String conn5Result = null;
	try {	
		conn5Result = getTextArea1().getText();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	return conn5Result;
}

/**
 * conn6:  (TextFieldHitz.text.textValueChanged(java.awt.event.TextEvent) --> TextArea1.append(java.lang.String))
 * @param arg1 java.awt.event.TextEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn6(java.awt.event.TextEvent arg1) {
	try {		
	} catch (java.lang.Throwable ivjExc) {		
		handleException(ivjExc);
	}
}

/**
 * Gets the applet information.
 * @return java.lang.String
 */
public String getAppletInfo() {
	return "HitzEgin created using VisualAge for Java.";
}

/**
 * Return the ButtonConexion property value.
 * @return java.awt.Button
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Button getButtonConexion() {
	if (ivjButtonConexion == null) {
		try {
			ivjButtonConexion = new java.awt.Button();
			ivjButtonConexion.setName("ButtonConexion");
			ivjButtonConexion.setBounds(141, 25, 125, 30);
			ivjButtonConexion.setEnabled(false);
			ivjButtonConexion.setLabel("Connect!!");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
	return ivjButtonConexion;
}

/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setFont(new java.awt.Font("dialog", 1, 12));
			ivjLabel1.setText("Applet HitzEgin v0.1 beta");
			ivjLabel1.setBackground(new java.awt.Color(49, 138, 192));
			ivjLabel1.setBounds(0, 1, 444, 19);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
	return ivjLabel1;
}

/**
 * Return the LabelUsers property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabelUsers() {
	if (ivjLabelUsers == null) {
		try {
			ivjLabelUsers = new java.awt.Label();
			ivjLabelUsers.setName("LabelUsers");
			ivjLabelUsers.setAlignment(java.awt.Label.CENTER);
			ivjLabelUsers.setText("Users");
			ivjLabelUsers.setBackground(new java.awt.Color(178, 130, 192));
			ivjLabelUsers.setBounds(336, 35, 99, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
	return ivjLabelUsers;
}

/**
 * Return the LabelUsers1 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Label getLabelUsers1() {
	if (ivjLabelUsers1 == null) {
		try {
			ivjLabelUsers1 = new java.awt.Label();
			ivjLabelUsers1.setName("LabelUsers1");
			ivjLabelUsers1.setAlignment(java.awt.Label.LEFT);
			ivjLabelUsers1.setText("^---- Insert Text and press 'Enter'");
			ivjLabelUsers1.setBackground(new java.awt.Color(178, 130, 192));
			ivjLabelUsers1.setBounds(16, 280, 315, 17);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
	return ivjLabelUsers1;
}

/**
 * Return the List1 property value.
 * @return java.awt.List
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private List getList1() {
	if (ivjList1 == null) {
		try {
			ivjList1 = new java.awt.List();
			ivjList1.setName("List1");
			ivjList1.setBackground(java.awt.Color.white);
			ivjList1.setBounds(335, 59, 102, 194);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
	return ivjList1;
}

/**
 * Return the TextArea1 property value.
 * @return java.awt.TextArea
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private TextArea getTextArea1() {
	if (ivjTextArea1 == null) {
		try {
			ivjTextArea1 = new java.awt.TextArea();
			ivjTextArea1 = myCount.getivjTextArea();
			ivjTextArea1.setText("");
			myCount.getivjTextArea().setText("");
			ivjTextArea1.setName("TextArea1");
			ivjTextArea1.setBackground(java.awt.Color.white);
			ivjTextArea1.setBounds(15, 58, 317, 194);
			ivjTextArea1.setEditable(false);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
	return ivjTextArea1;
}

/**
 * Return the TextFieldHitz property value.
 * @return java.awt.TextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private TextField getTextFieldHitz() {
	if (ivjTextFieldHitz == null) {
		try {
			ivjTextFieldHitz = new java.awt.TextField();
			ivjTextFieldHitz.setName("TextFieldHitz");
			ivjTextFieldHitz.setBackground(java.awt.Color.white);
			ivjTextFieldHitz.setBounds(14, 254, 315, 25);
			ivjTextFieldHitz.setEnabled(true);
			ivjTextFieldHitz.setEditable(false);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
	return ivjTextFieldHitz;
}

/**
 * Return the TextFieldNick property value.
 * @return java.awt.TextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private TextField getTextFieldNick() {
	if (ivjTextFieldNick == null) {
		try {
			ivjTextFieldNick = new java.awt.TextField();
			ivjTextFieldNick.setName("TextFieldNick");
			ivjTextFieldNick.setBackground(java.awt.Color.white);
			ivjTextFieldNick.setBounds(14, 25, 125, 30);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjTextFieldNick;
}

/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}

/**
 * Handle the Applet init method.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void init() {
	super.init();
	try {
		myCount = (HitzEginRMI)Naming.lookup("rmi://sicss180/"+"my CountRMI");	
	} catch (Exception e)	{
		System.err.println("Error, causa: "+ e.getMessage());
	}
	try {
		setName("HitzEgin");
		setLayout(null);
		setBackground(java.awt.Color.lightGray);
		setSize(443, 303);
		add(getTextFieldNick(), getTextFieldNick().getName());
		add(getButtonConexion(), getButtonConexion().getName());
		add(getList1(), getList1().getName());
		add(getTextArea1(), getTextArea1().getName());
		add(getTextFieldHitz(), getTextFieldHitz().getName());
		add(getLabelUsers(), getLabelUsers().getName());
		add(getLabel1(), getLabel1().getName());
		add(getLabelUsers1(), getLabelUsers1().getName());
		initConnections();
		// user code begin {1}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {2}
		// user code end
		handleException(ivjExc);
	}
}

/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getTextFieldNick().addTextListener(this);
	getButtonConexion().addActionListener(this);
	getTextFieldHitz().addActionListener(this);
	getTextArea1().addTextListener(this);
	getTextFieldHitz().addTextListener(this);
}

/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		HitzEgin aHitzEgin = new HitzEgin();
		frame.add("Center", aHitzEgin);
		frame.setSize(aHitzEgin.getSize());
		aHitzEgin.init();
		aHitzEgin.start();
		frame.setVisible(true);

		aHitzEgin.destroy();
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.applet.Applet");
	}
}

/**
 * Method to handle events for the TextListener interface.
 * @param e java.awt.event.TextEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void textValueChanged(java.awt.event.TextEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getTextFieldNick()) ) {
		conn0(e);
	}
	if ((e.getSource() == getTextArea1()) ) {
		conn5(e);
	}
	if ((e.getSource() == getTextFieldHitz()) ) {
		conn6(e);
	}
	// user code begin {2}
	// user code end
}

}
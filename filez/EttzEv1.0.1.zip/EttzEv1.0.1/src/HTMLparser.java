
/**
 * T�tulo: un spider ladron<p>
 * Descripci�n: <p>
 * Copyright: Copyright (c) Pello X Altadill Izura . Asier Fdez
 * Empresa: Java Mercenary - Cosa Nostra
 * @author yo mismo
 * @version 1.0
 */
package com.javamercenary.ettze;

import javax.swing.text.html.HTMLEditorKit.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import java.util.*;
import javax.swing.JLabel;
import javax.swing.JList;

public class HTMLparser extends ParserCallback {

  int  Etiketa;
  private MainFrame mf = null;
  private String TaskID = null;
  private Resources resources = null;
    
  public HTMLparser() {
    Etiketa=0;
  }

  public HTMLparser(MainFrame mf,String TaskID,Resources resources) {
    Etiketa=0;
    this.mf = mf;
    this.TaskID = TaskID;
    this.resources = resources;
  }

  public void handleStartTag(HTML.Tag tag,MutableAttributeSet attrib,int pos)
    {
      if (tag.equals(HTML.Tag.A))
      capturaA(attrib);
    }


  public void capturaA(MutableAttributeSet attrib)
  {
  String href = "";
  href=(String)attrib.getAttribute(HTML.Attribute.HREF);
  resources.add(href);
  if (href.startsWith("http://"))
	  href = garbituHREF(href);
 ((PanelTask)mf.TaskTable.get(TaskID)).addElementToList(href);
  mf.printOut(TaskID,"Resource: "+ href,1);
  }

  /**
  * garbituHREF
  * honen bitartez http ostean dagoen testua berreskuratzen dugu.
  */
  private String garbituHREF (String href) {
	String emaitza = "", temp = "", url="";
	StringTokenizer st = new StringTokenizer(href,"/"); 
	
	temp = st.nextToken();
	temp = st.nextToken();
	url = st.nextToken();
	temp = url + "/";
	while(st.hasMoreTokens()) {
		temp +=st.nextToken();
	} 
	emaitza = temp;
	mf.printOut(TaskID,"AHI VA una url: "+url,1); 
	return "/"+emaitza; 
	//return href;
  }

  public void capturaIMG(MutableAttributeSet attrib)
  {
  String src = "";
  String alt = "";
  src=(String)attrib.getAttribute(HTML.Attribute.SRC);
  alt=(String)attrib.getAttribute(HTML.Attribute.ALT);
	((PanelTask)mf.TaskTable.get(TaskID)).addElementToList(src);
  mf.printOut(TaskID,"Resource: "+ src +"-(Alt: "+ alt +")",1);
  }

	/**
	* handleText
	*/
  public void handleText(char [] text,int pos)
    {
    }
	/**
	* handleSimpleTag
	*/
  public void handleSimpleTag(HTML.Tag tag,MutableAttributeSet attrib,int pos)
    {
        if (tag.equals(HTML.Tag.IMG))
				 capturaIMG(attrib);
    }
	/**
	* handleEndTag
	*/
  public void handleEndTag(HTML.Tag tag,int pos)
    {
    }


}
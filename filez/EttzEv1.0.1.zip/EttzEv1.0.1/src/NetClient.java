package com.javamercenary.ettze;

import java.io.*;
import java.net.*;
import javax.swing.text.html.parser.ParserDelegator;

public class NetClient extends Thread {

private static final String VERSION = "JavaBot v1.0>";
private String HOST="www.ebila.com";
private String REQUEST = "/";
private int PORT =7001;
private String downloadRoot = "filez";
private MainFrame mf = null;
private String UserAgent = "EttzE-The Webpire-v1.0.0 .Dptmnt Of Aritificial Inteligence.www.ebila.com";
private String HTTP = "HTTP/1.0";
private String AcceptLanguage = "en";
private String Host = "-"; 
private String Connection = "nokeepalive";
private String TaskID = "";
private Resources resources = null;
private static final int MAX_CONCURRENT_THREAD = 50;
private int threads = 0;

/**
* NetClient constructor
*/
NetClient (String host, int port) {
	HOST = host;
	PORT = port;
}

/**
* NetClient constructor
*/
NetClient (String host, int port,String request) {
	HOST = host;
	PORT = port;
	REQUEST = request;
}

/**
* NetClient constructor
*/
NetClient (MainFrame mf, String host, int port,String request) {
	HOST = host;
	PORT = port;
	REQUEST = request;
	this.mf = mf;
}

/**
* NetClient constructor
*/
NetClient (MainFrame mf, String host, int port,String request,String TaskID, String UserAgent,String HTTP,String AcceptLanguage,String Host, String Connection) {
	HOST = host;
	PORT = port;
	REQUEST = request;
	this.TaskID = TaskID;
	this.mf = mf;
	this.UserAgent = UserAgent;
	this.HTTP = HTTP;
	this.AcceptLanguage = AcceptLanguage;
	this.Host = Host;
	this.Connection = Connection;
	resources = new Resources(TaskID);
}

/**
* inner class
*/
class InnerClient extends Thread {
	String req;
	InnerClient (String req) {
		this.req = req;		
	}
	
	public void run () {
		mf.setStatusBar(threads+" threads running currently.");
		handleFile(tryConnection(HOST,PORT,req));
		resources.markAsChecked(req);
		threads--;	
		mf.setStatusBar(threads+" threads running currently. Resources found: "+resources.size());
	}
	
}

/**
* run
*/
public void run () {
	String moreJob = null;
      try {
 	handleFile(tryConnection(HOST,PORT,REQUEST));threads++;
 	    } catch (Exception e) {
        mf.printOut(TaskID,VERSION+"Can't handle request: "+HOST+":"+PORT+" req: "+REQUEST,1);
      }
  while (true){
	 	while (threads > MAX_CONCURRENT_THREAD) {
  	    try {
 				wait(10000);
 	    	} catch (InterruptedException ie) {
        	mf.printOut(TaskID,VERSION+" Thread interrupted!",1);
      	}
 		}
 		moreJob = resources.gimmeTask();
 		if (moreJob == null) {mf.printOut(TaskID,VERSION+" JOB FINISHED!!",1);break;}
 			mf.printOut(TaskID,VERSION+" More Job: "+moreJob,1);	
 		new InnerClient(moreJob).start();threads++;
 		resources.markChecking(moreJob);
  }
  // System.out.println("Que lo bulko!!: "+resources.dumpTable());
}

/**
* sendRequest
*/
private String sendRequest (String request) {
//	return "GET "+request+" HTTP/1.0 Accept: */*\nAccept-Language: en\nAccept-Encoding: .class \nUser-Agent: Mozilla compatible IE5.0\nHost: -\nConnection: nokeepalive\n";
	return "GET "+request+" "+HTTP+" Accept: */*\nAccept-Language: "+AcceptLanguage+"\nAccept-Encoding: .class \nUser-Agent: "+UserAgent+"\nHost: "+Host+"\nConnection: "+Connection+"\n";
}
/**
* tryConnection
*/
private String tryConnection (String host, int port, String request)  {
	Socket socket = null;
	PrintWriter out = null, outfile = null;
	BufferedReader in = null;
	FileWriter fw = null;
	String filename = "TMP"+System.currentTimeMillis();
        String file = "";

	//if (!request.equals("/"))  filename = request;
	filename = downloadRoot +"/"+filename;

try {
	socket = new Socket(host, port);
	} catch (UnknownHostException e) {
        	mf.printOut(TaskID,VERSION+"> Don't know this host: "+host+ " Exc: "+e.getMessage(),1);
                        return "";
	} catch (IOException e) {
                mf.printOut(TaskID,VERSION+"> 1.-Can't connect to: "+host+ " Exc: "+e.getMessage(),1);
                        return "";
  }
	
	try {
	out = new PrintWriter(socket.getOutputStream(), true);
	in = new BufferedReader(new InputStreamReader(
         socket.getInputStream()));
	outfile = new PrintWriter(new FileWriter (filename));
	} catch (IOException e) {
                mf.printOut(TaskID,VERSION+"> Can't connect to: "+host+ " Exc: "+e.getMessage(),1);
                        return "";
                      }

String userInput = sendRequest(REQUEST);
out.println(userInput);
try {
((PanelTask)mf.TaskTable.get(TaskID)).setServerDataTextField(request);
((PanelTask)mf.TaskTable.get(TaskID)).clearServerData();
mf.printOut(TaskID,VERSION+"> Receiving response from "+host,1);
while ((userInput = in.readLine()) != null) {
    System.out.println(userInput);
    mf.setStatusBar("Receiving data from "+host+" > request :"+request+" (Threads: #"+threads+") (Resources: "+resources.size());
    file += userInput+"\n";
    outfile.println(userInput);
    ((PanelTask)mf.TaskTable.get(TaskID)).addToServerData(userInput+"\n");
}

} catch (IOException e) {
                    mf.printOut(TaskID,VERSION+"> Error while reading from Socket: "+host+" (port: "+port+")",1);
                    return "";
                    }


try {
                      out.close();
		      outfile.close();
                      in.close();
                      socket.close();
} catch (IOException e) {
                    mf.printOut(TaskID,VERSION+"> Error closing Socket: "+host,1);
                    return "";
                      }

	mf.printOut(TaskID,VERSION+"> returning downloaded file...",1);
	return filename;
}

/**
* handleFile
* @param String filename
*/
private void handleFile (String filename) {
  ParserDelegator pd= new ParserDelegator();
  BufferedReader bf = null;
  HTMLparser htmlparser = new HTMLparser(mf,TaskID,resources);
  try {
    if (!filename.equals("")) {
	 mf.printOut(TaskID,VERSION+"> "+filename+": attempting to Xtract resources.",1);
	 bf =new BufferedReader(new FileReader(filename));
	 pd.parse(bf,htmlparser,true);
	 bf.close();
    }
  } catch (IOException ioex) {
	mf.printOut(TaskID,VERSION+"> Error: "+ioex.getMessage(),1);
  }
}

/**
* main
*/
public static void main(String[] args)  {
		System.out.println("EbilaBot, awakening.");
		try {
 	if (args.length == 3) {
		NetClient nc = new NetClient(args[0], Integer.parseInt(args[1]), args[2]);
		nc.start();
	} else
		System.out.println("Try with <HOST> <PORT> <REQUEST>");
		} catch (Exception e) {
		 System.err.println("- Try with <HOST> <PORT> - Error: "+e.getMessage());
		}
  }

}
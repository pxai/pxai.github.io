
/**
 * T�tulo: WebVampire<p>
 * Descripci�n: <p>
 * Copyright: Copyright (c) Pello Xabier Altadill Izura<p>
 * Empresa: Java Dream<p>
 * @author Pello Xabier Altadill Izura
 * @version 1.0
 */
package com.javamercenary.ettze;

import java.awt.*;
import javax.swing.*;

public class PanelServerData extends JPanel {
  GridLayout gridLayout1 = new GridLayout();
  GridLayout gridLayout2 = new GridLayout();
  GridLayout gridLayout3 = new GridLayout();
  FlowLayout flowLayout1 = new FlowLayout();
  JLabel jLabelServerResponse = new JLabel();
  JPanel jPanelResources = new JPanel();
  JPanel jPanelResourcesTitle = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanelServerData = new JPanel();
  JLabel jLabelServerData = new JLabel();
  BorderLayout borderLayout2 = new BorderLayout();
  JTextField jTextFieldResource = new JTextField();
  JTextArea jTextAreaServerData = new JTextArea();
	MainFrame mf = null;
  private String TaskID = "";
  JPanel jPanelData = new JPanel();
  GridLayout gridLayout4 = new GridLayout();
  JPanel jPanelWhois = new JPanel();
  JPanel jPanelRipe = new JPanel();
  JPanel jPanelNic = new JPanel();
  BorderLayout borderLayout3 = new BorderLayout();
  BorderLayout borderLayout4 = new BorderLayout();
  BorderLayout borderLayout5 = new BorderLayout();
  JLabel jLabelWhois = new JLabel();
  JLabel jLabelRipe = new JLabel();
  JLabel jLabelPort = new JLabel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  JTextArea jTextAreaNic = new JTextArea();
  JTextArea jTextAreaRipe = new JTextArea();
  JScrollPane jScrollPaneServerData = new JScrollPane();


  public PanelServerData(MainFrame mf,String TaskID) {
  	this.mf = mf;
  	this.TaskID = TaskID;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    gridLayout2.setColumns(2);
    this.setLayout(gridLayout2);
    gridLayout1.setColumns(2);
    gridLayout3.setColumns(2);
    jLabelServerResponse.setText("Server Response to request:");
    jPanelResources.setLayout(borderLayout1);
    jPanelResourcesTitle.setLayout(flowLayout1);
    jPanelServerData.setLayout(borderLayout2);
    jLabelServerData.setText("Server data");
    jTextFieldResource.setText("jTextField1");
    jTextAreaServerData.setEnabled(false);
    jTextAreaServerData.setEditable(false);
    jPanelData.setLayout(gridLayout4);
    gridLayout4.setRows(3);
    jPanelWhois.setLayout(borderLayout3);
    jPanelRipe.setLayout(borderLayout4);
    jPanelNic.setLayout(borderLayout5);
    jLabelWhois.setText("NIC data:");
    jLabelRipe.setText("Ripe data:");
    jPanelWhois.setToolTipText("Domain name data");
    jPanelRipe.setToolTipText("IP address data");
    jLabelPort.setText("Port Scan:");
    jTextAreaNic.setEditable(false);
    jTextAreaRipe.setEditable(false);
    this.add(jPanelResources, null);
    jPanelResources.add(jLabelPort, BorderLayout.NORTH);
    this.add(jPanelServerData, null);
    jPanelServerData.add(jLabelServerData, BorderLayout.NORTH);
    jPanelServerData.add(jPanelData, BorderLayout.CENTER);
    jPanelData.add(jPanelWhois, null);
    jPanelWhois.add(jPanelResourcesTitle, BorderLayout.NORTH);
    jPanelResourcesTitle.add(jLabelServerResponse, null);
    jPanelResourcesTitle.add(jTextFieldResource, null);
    jPanelWhois.add(jScrollPaneServerData, BorderLayout.CENTER);
    jScrollPaneServerData.getViewport().add(jTextAreaServerData, null);
    jPanelData.add(jPanelRipe, null);
    jPanelRipe.add(jLabelRipe, BorderLayout.NORTH);
    jPanelRipe.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTextAreaRipe, null);
    jPanelData.add(jPanelNic, null);
    jPanelNic.add(jLabelWhois, BorderLayout.NORTH);
    jPanelNic.add(jScrollPane2, BorderLayout.CENTER);
    jScrollPane2.getViewport().add(jTextAreaNic, null);
        this.setName("ServerData");

  }
}
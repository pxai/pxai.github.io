
/**
 * T�tulo: WebVampire<p>
 * Descripci�n: <p>
 * Copyright: Copyright (c) Pello Xabier Altadill Izura<p>
 * Empresa: Java Dream<p>
 * @author Pello Xabier Altadill Izura
 * @version 1.0
 */
package com.javamercenary.ettze;

import java.awt.*;
import javax.swing.*;

public class PanelFilez extends JPanel {
  GridLayout gridLayout1 = new GridLayout();
  JPanel jPanelResources = new JPanel();
  JPanel jPanelTree = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanelResourcesTitle = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  JLabel jLabelResources = new JLabel();
  JLabel jLabelTree = new JLabel();
  JTree jTreeFilez = new JTree();
  MainFrame mf = null;
  private String TaskID = "";
  JList jListResources = null;
  DefaultListModel resourcesList = new DefaultListModel();


  public PanelFilez(MainFrame mf, String TaskID) {
  	this.mf = mf;
  	this.TaskID = TaskID;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
  	jListResources = new JList(resourcesList);
  	JScrollPane listScrollPane = new JScrollPane(jListResources);
    this.setLayout(gridLayout1);
    gridLayout1.setColumns(2);
    jPanelResources.setLayout(borderLayout1);
    jPanelTree.setLayout(borderLayout2);
    jPanelResourcesTitle.setLayout(flowLayout1);
    jLabelResources.setText("Resources found:");
    jLabelTree.setText("Downloaded filez:");
    this.add(jPanelResources, null);
    jPanelResources.add(jPanelResourcesTitle, BorderLayout.NORTH);
    jPanelResources.add(listScrollPane, BorderLayout.CENTER);
    jPanelResourcesTitle.add(jLabelResources, null);
    this.add(jPanelTree, null);
    jPanelTree.add(jLabelTree, BorderLayout.NORTH);
    jPanelTree.add(jTreeFilez, BorderLayout.CENTER);
    this.setName("Filez");
  }
}
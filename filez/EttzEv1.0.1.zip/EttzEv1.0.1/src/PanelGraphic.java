
/**
 * T�tulo: WebVampire<p>
 * Descripci�n: <p>
 * Copyright: Copyright (c) Pello Xabier Altadill Izura<p>
 * Empresa: Java Dream<p>
 * @author Pello Xabier Altadill Izura
 * @version 1.0
 */
package com.javamercenary.ettze;

import java.awt.*;
import javax.swing.*;

public class PanelGraphic extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  JLabel jLabelGraphic = new JLabel();
  MainFrame mf = null;
  private String TaskID = "";


  public PanelGraphic(MainFrame mf, String TaskID) {
  	this.mf = mf;
  	this.TaskID = TaskID;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    jLabelGraphic.setText("Graphic of Server content:");
    this.setLayout(borderLayout1);
    this.add(jLabelGraphic, BorderLayout.NORTH);
        this.setName("Graphic");

  }
}
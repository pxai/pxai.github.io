/**
* SAREA
* klase maltzur honen bitartez, emandako host
* baten TCP portu guztiak konprobatzen dira,
* 0tik 1024 artio.
* konprobazioa bakoitzeko thread bat osatuz errendimendua
* hobe daiteke, ETA HORIXE da HEMEN egiten dena.
*/
package com.javamercenary.ettze;
//import gunea
import java.io.IOException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.DataInputStream;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.net.*;

// Klasearen deklarazioa
public
class NmapClone
implements Runnable {

        // Atributuak
        protected Socket socket = null;
        protected DatagramSocket datagramSocket = null;
        protected DatagramPacket datagramPacket = null;
        protected InetAddress helbidea = null;
        protected byte[] buffer = new byte[128];
        public int portuakaztertzeko = 1025;
        protected int portuak = 0;
        protected int current = 0;
        protected String host;
        protected FileWriter fw;
        private static final String fitxategiSarrera ="src/services";
        protected Hashtable portuEsanahia= new Hashtable();
        protected long hasiera;

    // eraikitzailea
    public NmapClone (String host) {
      this.host = host;
      hasieratu();
      run();
    }

    // eraikitzailea
    public NmapClone (String host, int portuakaztertzeko) {
      this.host = host;
      this.portuakaztertzeko = portuakaztertzeko;
      hasieratu();
      run();
    }


    // run
    public void run () {
     System.out.println("NmapClone-Thread> HOST: "+host+" portuak[1-"+portuakaztertzeko+"]");
     hasiera = System.currentTimeMillis();
     while(portuak < portuakaztertzeko)
		sareaAztertu();
        try {
     fw.close();
        } catch (IOException e) {
            System.err.println("Errorea fitxategia ixterakoan: "+e.getMessage());
        }
     hasiera = System.currentTimeMillis() -hasiera;
     System.out.println("NmapClone> Elapsed Time: "+(hasiera/60000)+"m. "+(hasiera/1000)+"s.");
     System.out.println("NmapClone> MilaEsker NmapClone erabiltzeagatik!");
    }

 

    // hasieratu
    private void hasieratu () {
     try {
         kargatuFitxategia();
         fw = new FileWriter("emaitzak.txt");
        } catch (IOException e) {
            System.err.println("Errorea fitxategia irekitzerakoan: "+e.getMessage());
        }
    }

    // kargatuFitxategia
    private void kargatuFitxategia() {

          String hitza = "";
	  String portua = "";
          StringTokenizer st;
          BufferedReader di = null;
		int kont = 0;
       try {
          di = new BufferedReader(new FileReader(fitxategiSarrera));

        while (!((hitza = di.readLine()) == null) ) {
                st = new StringTokenizer(hitza);
                hitza = st.nextToken();
                portua = st.nextToken();
                portuEsanahia.put(portua,hitza);kont++;
        }
                System.out.println("NmapClone-Thread>Portuen fitxategia kargatu da.("+kont+" zerbitzu)");
        di.close();
        } catch (IOException e) {
            System.err.println("Errorea fitxategia irekitzerakoan: "+e.getMessage());
        }

    }

class SareaThread extends Thread {
     int portua;
     String esanahia = "?";

     SareaThread (int portua) {
        this.portua = portua;
        if (portuEsanahia.contains(portua+"")) esanahia = (String)portuEsanahia.get(portua+"");

     }
     public void run () {
            TCPkonexioaProbatu(portua);
		System.out.println("NmapClone>"+portua+" bukatua");
     }

    // TCP konexioa probatu
    private void TCPkonexioaProbatu (int portua) {
	String userInput = ""; 
	BufferedReader in = null;
    try {
      socket = new Socket(host, portua);
	in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	while ((userInput = in.readLine()) != null) {
    		System.out.println("\nNmapClone> Erantzuna hau jaso da  "+portua+"-n >"+userInput);
 	}
      socket.close();
      gordeLerroa(host+" makinan "+portua+ " portua irekia: " +esanahia);
      System.out.println("\n"+host+" makinan "+portua+ " TCP portua irekia: "+esanahia);
        } catch (IOException e) {
        }
    }

    // UDP konexioa probatu
    private boolean UDPkonexioaProbatu (int portua) {
     try {
      String hitza = "NmapClonev1.0.1";
      helbidea = InetAddress.getByName(host);
      buffer = hitza.getBytes();
      datagramSocket = new DatagramSocket(portua);
      datagramPacket = new DatagramPacket(buffer,buffer.length, helbidea,portua);
      datagramSocket.connect(helbidea,portua);   //jdk1.2
      datagramSocket.disconnect(); //jdk1.2
      datagramSocket.send(datagramPacket);
      datagramSocket.close();
      return true;
        } catch (IOException e) {
            return false;
        }
    }
 } // SareaThread bukatua

    private void sareaAztertu () {
	for (int i = 0;i<portuakaztertzeko;i++) {
                if ((current % 20) == 0)
                        System.out.print(i+"#");
                new SareaThread(i).start();
		portuak++;
	}
    }

    //emaitza fitxategian lerroa gordetzen duen metodoa
    private void gordeLerroa (String lerroa) {
     try {
        fw.write(lerroa+"\n");
        } catch (IOException e) {
            System.err.println("Errorea lerroa gordetzerakoan: "+e.getMessage());
        }
    }

    public static void main(String[] args) throws IOException {
	long hasiera = 0;
     hasiera = System.currentTimeMillis();
     if (args.length < 1) {
      System.out.println("Erabilpena: java NmapClone <host>");
      System.exit(1);
     }
        NmapClone sarea2 = new NmapClone(args[0]);
     hasiera = System.currentTimeMillis() -hasiera;
     System.out.println("NmapClone> Elapsed Time: "+(hasiera/60000)+"m. "+(hasiera/1000)+"s.");
     System.out.println("NmapClone> MilaEsker NmapClone erabiltzeagatik!");
    }


}

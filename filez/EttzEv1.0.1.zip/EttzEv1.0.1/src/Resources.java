/**
 * T�tulo: WebVampire<p>
 * Descripci�n: <p>
 * Copyright: Copyright (c) Pello Xabier Altadill Izura<p>
 * Empresa: JavaMercenary & Cosa Nostra<p>
 * @author Pello Xabier Altadill Izura
 * @version 1.0
 */
 
 package com.javamercenary.ettze;
 
 import java.util.Hashtable;
 import java.util.Enumeration;
 
 
 /**
 * En esta clase se guardan todos los enlaces encontrados.
 * es una extension de tabla hash, reutilizando asi todas sus capacidades y a�adiendoles
 * otras para nuestros propositos.
 * Si un elemento tiene la marca "OK" ha sido revisado
 * de lo contrario, la marca seria: "N". "C" significa que se esta chequeando.
 */
 public class Resources extends Hashtable {
 	private String TaskID = "";
 	
 	/**
 	* Resources
 	*/
 	Resources (String TaskID) {
 		this.TaskID = TaskID;
 	}
 	
 	/**
 	* isChecked
 	* Este metodo mira si un enlace o recurso ha sido revisado
 	* @param String resource
 	* @return boolean
 	*/
 	public boolean isChecked (String resource) {
 		return ((String)get(resource)).equals("OK");
 	}
 	
 	/**
 	* markAsChecked
	* se da por marcado un elemento
 	* @param String resource
 	*/
 	public void markAsChecked (String resource) {
 		remove(resource);
 		put(resource,"OK");
 	}
 	
 	/**
 	* markChecking
	* se esta analizando un elemento
 	* @param String resource
 	*/
 	public void markChecking (String resource) {
 		remove(resource);
 		put(resource,"C");
 	}

 	/**
 	* add
	* @param String resource
 	*/
 	public void add (String resource) {
		try {
 		if (!containsKey(resource))
 			put(resource,"N");
		} catch (Exception e) {
			System.err.println("Error while adding to resources table.");
		}
 	}
 	
 	/**
 	* gimmeTask
 	* 'dame curro' recorre la tabla y busca resources sin revisar
 	* si devuelve null, significa: QUE HEMOS ACABADO!!
 	* @return resource
 	*/
 	public String gimmeTask () {	
 		String emaitza = null, current="";
 	 Enumeration e = keys();
 	 while (e.hasMoreElements())	{
 	 	current = (String)e.nextElement();
 	 	if (get(current).equals("N")) return current;
 	 }
 	 return emaitza;
 	}

 	/**
 	* dumpTable
 	* imprime toda la tabla
 	* @return String
 	*/
 	public String dumpTable () {
 		return this.toString();	
 	}
 }

/**
 * T�tulo: WebVampire<p>
 * Descripci�n: <p>
 * Copyright: Copyright (c) Pello Xabier Altadill Izura<p>
 * Empresa: Java Dream<p>
 * @author Pello Xabier Altadill Izura
 * @version 1.0
 */
package com.javamercenary.ettze;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.StringTokenizer;

public class PanelConfig extends JPanel {
  public String HOST = "";
  JLabel jLabelConfigHost = new JLabel();
  JTextField jTextFieldHost = new JTextField();
  JButton jButtonTest = new JButton();
  JButton jButtonStart = new JButton();
  JLabel jLabelAgent = new JLabel();
  JLabel jLabelUserAgent = new JLabel();
  JLabel jLabelHost = new JLabel();
  JTextField jTextFieldClientHost = new JTextField();
  JLabel jLabelLanguage = new JLabel();
  JTextField jTextLanguage = new JTextField();
  JCheckBox jCheckBoxType = new JCheckBox();
  JCheckBox jCheckBoxPortScan = new JCheckBox();
  JCheckBox jCheckRecurse = new JCheckBox();
  JCheckBox jCheckBoxRecurseSubDomains = new JCheckBox();
  JButton jButtonStop = new JButton();
	MainFrame mf = null;
	private String TaskID = "";
  DefaultListModel agentsList = new DefaultListModel();
  JComboBox jComboBoxUserAgent = new JComboBox();


  public PanelConfig(MainFrame mf,String TaskID) {
  	this.mf  = mf;
  	this.TaskID = TaskID;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    jComboBoxUserAgent.setBounds(new Rectangle(86, 206, 281, 16));
    jComboBoxUserAgent.addItem("EttzE-The Webpire-v1.0.0 .Dptmnt Of Aritificial Inteligence.www.javamercenary.com");
    jComboBoxUserAgent.addItem("MSProxy/2.0");
    jComboBoxUserAgent.addItem("Mozilla/4.0 (compatible; MSIE 5.0; Windows 98; DigExt)");
    jComboBoxUserAgent.addItem("Mozilla/4.5 [es]C-CCK-MCD KTL27  (Win95; I)");
    jComboBoxUserAgent.addItem("Mozilla/4.08 (Macintosh; I; PPC, Nav)");

    jLabelConfigHost.setText("Host:");
    jLabelConfigHost.setBounds(new Rectangle(15, 23, 41, 17));
    this.setToolTipText("Task configuration");
    this.setLayout(null);
        this.setName("Settings");
    jTextFieldHost.setText("www.cisco.com");
    jTextFieldHost.setBounds(new Rectangle(55, 23, 110, 21));
    jButtonTest.setToolTipText("Test if host exists");
    jButtonTest.setText("Test");
    jButtonTest.setBounds(new Rectangle(173, 23, 64, 21));
    jButtonTest.addActionListener(new java.awt.event.ActionListener() {

      public void actionPerformed(ActionEvent e) {
        jButtonTest_actionPerformed(e);
      }
    });
    jButtonStart.setToolTipText("Start scan");
    jButtonStart.setText("START");
    jButtonStart.setBounds(new Rectangle(285, 8, 108, 90));
    jButtonStart.addActionListener(new java.awt.event.ActionListener() {

      public void actionPerformed(ActionEvent e) {
        jButtonStart_actionPerformed(e);
      }
    });
    jLabelAgent.setText("Agent options:");
    jLabelAgent.setBounds(new Rectangle(23, 172, 106, 17));
    jLabelUserAgent.setBounds(new Rectangle(17, 205, 75, 17));
    jLabelUserAgent.setText("User Agent:");
    jLabelHost.setBounds(new Rectangle(18, 228, 65, 17));
    jLabelHost.setText("Request:");
    jTextFieldClientHost.setBounds(new Rectangle(85, 226, 59, 21));
    jTextFieldClientHost.setText("/");
    jLabelLanguage.setBounds(new Rectangle(18, 252, 65, 17));
    jLabelLanguage.setText("Language:");
    jTextLanguage.setBounds(new Rectangle(84, 249, 110, 21));
    jTextLanguage.setText("en");
    jCheckBoxType.setText("Scan&Download");
    jCheckBoxType.setBounds(new Rectangle(55, 51, 149, 25));
    jCheckBoxPortScan.setText("Scan Server Ports");
    jCheckBoxPortScan.setBounds(new Rectangle(55, 77, 149, 25));
    jCheckRecurse.setText("Recurse All");
    jCheckRecurse.setBounds(new Rectangle(55, 130, 149, 25));
    jCheckBoxRecurseSubDomains.setText("Recurse Subdomains");
    jCheckBoxRecurseSubDomains.setBounds(new Rectangle(55, 104, 149, 25));
    jButtonStop.setToolTipText("Stop scanning server");
    jButtonStop.setText("STOP");
    jButtonStop.setEnabled(false);
    jButtonStop.setBounds(new Rectangle(285, 102, 108, 90));
    jButtonStop.addActionListener(new java.awt.event.ActionListener() {

      public void actionPerformed(ActionEvent e) {
        jButtonStop_actionPerformed(e);
      }
    });
    this.add(jLabelConfigHost, null);
    this.add(jTextFieldHost, null);
    this.add(jButtonTest, null);
    this.add(jLabelAgent, null);
    this.add(jLabelUserAgent, null);
    this.add(jTextFieldClientHost, null);
    this.add(jLabelHost, null);
    this.add(jLabelLanguage, null);
    this.add(jTextLanguage, null);
    this.add(jCheckBoxType, null);
    this.add(jCheckBoxPortScan, null);
    this.add(jCheckBoxRecurseSubDomains, null);
    this.add(jCheckRecurse, null);
    this.add(jButtonStart, null);
    this.add(jButtonStop, null);
    this.add(jComboBoxUserAgent, null);

  }

  void jButtonTest_actionPerformed(ActionEvent e) {

  }

  void jButtonStart_actionPerformed(ActionEvent e) {
	String host = "";
	int port = 80;
	mf.printOut(TaskID,"Bilatzen: "+jTextFieldHost.getText(),1);
        StringTokenizer st = new StringTokenizer(jTextFieldHost.getText(),":");
        if (st.hasMoreTokens()) host = st.nextToken();
        if (st.hasMoreTokens()) port = Integer.parseInt(st.nextToken());
				HOST = host;
				new NetClient(mf,host,port,jTextFieldClientHost.getText(),TaskID,(String)jComboBoxUserAgent.getSelectedItem(),"HTTP/1.0",jTextLanguage.getText(),"-","nokeepalive").start();
				jButtonStart.setEnabled(false);
				jButtonStop.setEnabled(true);

  }

  void jButtonStop_actionPerformed(ActionEvent e) {
				jButtonStop.setEnabled(false);
				jButtonStart.setEnabled(true);
  }
}
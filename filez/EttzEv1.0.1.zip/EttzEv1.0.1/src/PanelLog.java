
/**
 * T�tulo: WebVampire<p>
 * Descripci�n: <p>
 * Copyright: Copyright (c) Pello Xabier Altadill Izura<p>
 * Empresa: Java Dream<p>
 * @author Pello Xabier Altadill Izura
 * @version 1.0
 */
package com.javamercenary.ettze;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class PanelLog extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  JScrollPane jScrollPaneLog = new JScrollPane();
  JTextArea jTextArea1 = new JTextArea();
  JLabel jLabelLog = new JLabel();
  MainFrame mf = null;
  private String TaskID = "";
  JPanel jPanel1 = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  JButton jButtonClear = new JButton();


  public PanelLog(MainFrame mf,String TaskID) {
  	this.mf = mf;
  	this.TaskID = TaskID;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    jLabelLog.setText("Log for Task:");
    jTextArea1.setEnabled(true);
    jTextArea1.setEditable(false);
    jPanel1.setLayout(flowLayout1);
    jButtonClear.setText("Clear Log");
    jButtonClear.addActionListener(new java.awt.event.ActionListener() {

      public void actionPerformed(ActionEvent e) {
        jButtonClear_actionPerformed(e);
      }
    });
    this.add(jScrollPaneLog, BorderLayout.CENTER);
    this.add(jLabelLog, BorderLayout.NORTH);
    this.add(jPanel1, BorderLayout.SOUTH);
    jPanel1.add(jButtonClear, null);
    jScrollPaneLog.getViewport().add(jTextArea1, null);
        this.setName("Log");

  }

  void jButtonClear_actionPerformed(ActionEvent e) {
    jTextArea1.setText("");
  }
}
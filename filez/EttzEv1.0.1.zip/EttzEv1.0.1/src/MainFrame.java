
/**
 * T�tulo: WebVampire<p>
 * Descripci�n: <p>
 * Copyright: Copyright (c) Pello Xabier Altadill Izura<p>
 * Empresa: Java Dream<p>
 * @author Pello Xabier Altadill Izura
 * @version 1.0
 */
package com.javamercenary.ettze;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Date;
import java.util.Hashtable;

public class MainFrame extends JFrame {
  private static String VERSION = "";
  JPanel contentPane;
  JMenuBar menuBar1 = new JMenuBar();
  JMenu menuFile = new JMenu();
  JMenuItem menuFileExit = new JMenuItem();
  JMenu menuHelp = new JMenu();
  JMenuItem menuHelpAbout = new JMenuItem();
  JToolBar toolBar = new JToolBar();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  ImageIcon image1;
  ImageIcon image2;
  ImageIcon image3;
  JLabel statusBar = new JLabel();
  BorderLayout borderLayout1 = new BorderLayout();
  TabbedPaneCentral tabbedpanecentral =new TabbedPaneCentral();
  Hashtable TaskTable = new Hashtable();

  //Construir el marco
  public MainFrame(String Version) {
	this.VERSION = Version;
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  //Inicializaci�n de componentes
  private void jbInit() throws Exception  {
	printOut("",VERSION+ " started!",1);
    image1 = new ImageIcon(MainFrame.class.getResource("/icons/openFile.gif"));
    image2 = new ImageIcon(MainFrame.class.getResource("/icons/closeFile.gif"));
    image3 = new ImageIcon(MainFrame.class.getResource("/icons/help.gif"));
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(borderLayout1);
    this.setSize(new Dimension(500, 400));
    this.setTitle(VERSION);
    this.addWindowListener(new java.awt.event.WindowAdapter() {

      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
    statusBar.setText(" ");
    menuFile.setText("Archivo");
    menuFileExit.setText("Salir");
    menuFileExit.addActionListener(new ActionListener()  {

      public void actionPerformed(ActionEvent e) {
        fileExit_actionPerformed(e);
      }
    });
    menuHelp.setText("Ayuda");
    menuHelpAbout.setText("Acerca de");
    menuHelpAbout.addActionListener(new ActionListener()  {

      public void actionPerformed(ActionEvent e) {
        helpAbout_actionPerformed(e);
      }
    });
    jButton1.setIcon(image1);
    jButton1.setToolTipText("Abrir archivo");
    jButton2.setIcon(image2);
    jButton2.setToolTipText("Cerrar archivo");
    jButton3.setIcon(image3);
    jButton3.setToolTipText("Ayuda");
    toolBar.add(jButton1);
    toolBar.add(jButton2);
    toolBar.add(jButton3);
    menuFile.add(menuFileExit);
    menuHelp.add(menuHelpAbout);
    menuBar1.add(menuFile);
    menuBar1.add(menuHelp);
    this.setJMenuBar(menuBar1);
    contentPane.add(toolBar, BorderLayout.NORTH);
    contentPane.add(statusBar, BorderLayout.SOUTH);
    PanelTask pt = new PanelTask(this,"Task1");
    TaskTable.put("Task1",pt);
    tabbedpanecentral.add(pt);
    contentPane.add(tabbedpanecentral,BorderLayout.CENTER);
    this.setTitle(VERSION);
    this.show();
  }

  //Realizar Archivo | Salir
  public void fileExit_actionPerformed(ActionEvent e) {
    System.exit(0);
  }

  //Realizar Ayuda | Acerca de
  public void helpAbout_actionPerformed(ActionEvent e) {
    MainFrame_AcercaDe dlg = new MainFrame_AcercaDe(this);
    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
    dlg.setModal(true);
    dlg.show();
  }

  //Modificado para poder salir cuando se cierra la ventana
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      fileExit_actionPerformed(null);
    }
  }

  /**
   * printOut
   * a method to print Out every log messages.
   * @param int newLine
   * @param String message
   */
  public void printOut (String ID, String message, int newLine) {
    String message_to_print = message;
    if (newLine == 1) message_to_print += "\n";
    message_to_print = new Date().toString()+">> "+message_to_print;
    System.out.print(message_to_print);
    setStatusBar(message_to_print);
    if (!TaskTable.isEmpty())
    ((PanelTask)TaskTable.get(ID)).addToLog(message_to_print);
  }

  void this_windowClosing(WindowEvent e) {
    System.exit(0);
  }

 /**
 * setStatusBar 
 */
  public void setStatusBar (String text) {
	statusBar.setText(text);
  }
}

/**
 * T�tulo: WebVampire<p>
 * Descripci�n: <p>
 * Copyright: Copyright (c) Pello Xabier Altadill Izura<p>
 * Empresa: Java Dream<p>
 * @author Pello Xabier Altadill Izura
 * @version 1.0
 */
package com.javamercenary.ettze;

import java.awt.*;
import javax.swing.*;

public class PanelTask extends JPanel {
  private String TaskID = "Task";
  private int ID = 0;
  BorderLayout borderLayout1 = new BorderLayout();
  JTabbedPane jTabbedPaneTask = new JTabbedPane();
  private MainFrame mf = null;
  private PanelConfig panelConfig = null;
  private PanelFilez panelFilez = null;
  private PanelGraphic panelGraphic = null;
  private PanelServerData panelServerData = null;
  private PanelLog panelLog = null;

  public PanelTask(MainFrame mf,String TaskID) {
  	this.mf = mf;
  	this.TaskID = TaskID;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    this.add(jTabbedPaneTask, BorderLayout.CENTER);
    panelConfig = new PanelConfig(mf,TaskID);
    jTabbedPaneTask.add(panelConfig);
    panelFilez = new PanelFilez(mf,TaskID);
    jTabbedPaneTask.add(panelFilez);
		panelGraphic = new PanelGraphic(mf,TaskID);
    jTabbedPaneTask.add(panelGraphic);
    panelServerData = new PanelServerData(mf,TaskID);
    jTabbedPaneTask.add(panelServerData);
    panelLog = new PanelLog(mf,TaskID);
    jTabbedPaneTask.add(panelLog);
        this.setName(TaskID);
  }
  
  /**
  * clearServerData
  */
  public void clearServerData () {
  	panelServerData.jTextAreaServerData.setText("");
  }
  
  /**
  * addToServerData
  * @param String textToAppend
  */
  public void addToServerData (String textToAppend) {
  	panelServerData.jTextAreaServerData.append(textToAppend);
  }
  
    /**
  * addToLog
  * @param String textToAppend
  */
  public void addToLog (String textToAppend) {
  	panelLog.jTextArea1.append(textToAppend);
  }
  /**
  * setServerDataTextField
  * @param String textForField
  */
  public void setServerDataTextField (String textForField) {
  	panelServerData.jTextFieldResource.setText(textForField);
  }

  /**
  * addElementToList
  * @param String elementToAdd
  */
  public void addElementToList (String elementToAdd) {
	if (!panelFilez.resourcesList.contains(elementToAdd))
  	panelFilez.resourcesList.addElement(elementToAdd);
  }

 /**
  * getHost
  * @return String 
  */
  public String getHost () {
  	return panelConfig.HOST;
  }

  
}
package info.pello.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.text.method.CharacterPickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.format.Time;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;

public class DialogsActivity extends Activity {
	
	public static final int ID_MI_DIALOG = 1;
	public static final int ID_ALERT_DIALOG = 2;
	public static final int ID_CHARACTER_PICKER_DIALOG = 3;
	public static final int ID_DATE_PICKER_DIALOG = 4;
	public static final int ID_TIME_PICKER_DIALOG = 5;
	public static final int ID_PROGRESS_DIALOG = 6;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        
        final Button btnDialog = (Button) findViewById(R.id.btnDialog);
        
        btnDialog.setOnClickListener(new View.OnClickListener() {
    	    public void onClick(View view) {
    	    	showDialog(ID_MI_DIALOG);
    	    }
    	});
        
      final Button btnAlertDialog = (Button) findViewById(R.id.btnAlertDialog);
        
      	btnAlertDialog.setOnClickListener(new View.OnClickListener() {
    	    public void onClick(View view) {
    	    	showDialog(ID_ALERT_DIALOG);
    	    }
    	});

      final Button btnCharacterPickerDialog = (Button) findViewById(R.id.btnCharacterPickerDialog);
        
      btnCharacterPickerDialog.setOnClickListener(new View.OnClickListener() {
    	    public void onClick(View view) {
    	    	showDialog(ID_CHARACTER_PICKER_DIALOG);
    	    }
    	});

      	
      final Button btnDatePickerDialog = (Button) findViewById(R.id.btnDatePickerDialog);
        
      	btnDatePickerDialog.setOnClickListener(new View.OnClickListener() {
    	    public void onClick(View view) {
    	    	showDialog(ID_DATE_PICKER_DIALOG);
    	    }
    	});
      	
      	final Button btnTimePickerDialog = (Button) findViewById(R.id.btnTimePickerDialog);
        
      	btnTimePickerDialog.setOnClickListener(new View.OnClickListener() {
    	    public void onClick(View view) {
    	    	showDialog(ID_TIME_PICKER_DIALOG);
    	    }
    	});   	

      	final Button btnProgressDialog = (Button) findViewById(R.id.btnProgressDialog);
        
      	btnProgressDialog.setOnClickListener(new View.OnClickListener() {
    	    public void onClick(View view) {
    	    	showDialog(ID_PROGRESS_DIALOG);
    	    }
    	}); 

    }
    
    /**
     * onCreateDialog
     * Lo necesitamos para crear dialogos
     */
    @Override
    protected Dialog onCreateDialog(int id) {
        final TextView txtvResultado = (TextView) findViewById(R.id.txtvResultado);
        switch (id) {
        case ID_MI_DIALOG:
        	Context mContext = getApplicationContext();
        	LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        	View layout = inflater.inflate(R.layout.mi_dialog,
        	                               (ViewGroup) findViewById(R.id.layout_root));
        	
        	AlertDialog.Builder miBuilder = new AlertDialog.Builder(this);
        	miBuilder.setView(layout)
        			.setMessage("Que pasa chacho")
        	       .setCancelable(false)
        	       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
        	           public void onClick(DialogInterface dialog, int id) {
        	        	   txtvResultado.setText("Elegiste yes");
        	           }
        	       });
        	AlertDialog miDialog = miBuilder.create();

        	return miDialog;
        	
        case ID_ALERT_DIALOG:
        	AlertDialog.Builder builder = new AlertDialog.Builder(this);
        	builder.setMessage("Are you sure you want to exit?")
        	       .setCancelable(false)
        	       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
        	           public void onClick(DialogInterface dialog, int id) {
        	        	   txtvResultado.setText("Elegiste yes");
        	           }
        	       })
        	       .setNegativeButton("No", new DialogInterface.OnClickListener() {
        	           public void onClick(DialogInterface dialog, int id) {
        	                dialog.cancel();
         	        	   txtvResultado.setText("Elegiste NO");
        	           }
        	       });
        	AlertDialog alert = builder.create();
        	return alert;
        case ID_CHARACTER_PICKER_DIALOG:
        	CharacterPickerDialog characterPickerDialog =
                    new CharacterPickerDialog(this,txtvResultado,null, "", true);
        	
                   	return characterPickerDialog; 	
       
        case ID_DATE_PICKER_DIALOG:

        	DatePickerDialog dateDialog =
            new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker view, int ano,
                        int mes, int dia) {
                        txtvResultado.setText(ano+"-"+mes+"-"+dia);
                    }
                }, 0, 0, 0);
        	return dateDialog;
        case ID_TIME_PICKER_DIALOG:
            
        	TimePickerDialog timeDialog =
            new TimePickerDialog(this,
                 new TimePickerDialog.OnTimeSetListener() {

					@Override
					public void onTimeSet(TimePicker view,
							int hora, int minuto) {
		                     txtvResultado.setText(hora+":"+minuto);
					}
            }, 0, 0, true);
        	return timeDialog; 	
        case ID_PROGRESS_DIALOG:
            
        	ProgressDialog progressDialog = new ProgressDialog(this);
        	return progressDialog; 
        }
      return null;
    }

}

package info.pello.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class CamaraActivity extends Activity {
	static final int TAKE_AVATAR_CAMERA_REQUEST = 1;
	static final int TAKE_AVATAR_GALLERY_REQUEST = 2;
	TextView tvResultado;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        tvResultado = (TextView) this.findViewById(R.id.tvResultado);
        Intent pictureIntent = new Intent(
        		android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        		startActivityForResult(pictureIntent, TAKE_AVATAR_CAMERA_REQUEST);
    }
    
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == TAKE_AVATAR_CAMERA_REQUEST) {
            if (resultCode == RESULT_OK) {
                // Image captured and saved to fileUri specified in the Intent
                tvResultado.setText("Image saved to:\n" +
                         data.getData() + "," + Toast.LENGTH_LONG +",");
            } else if (resultCode == RESULT_CANCELED) {
                // User cancelled the image capture
            } else {
                // Image capture failed, advise user
            }
        }

    }
    public void sacarFoto (View v) {
    	
    }
}
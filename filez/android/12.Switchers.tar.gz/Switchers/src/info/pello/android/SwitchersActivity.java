package info.pello.android;

import java.util.Vector;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.ViewSwitcher;


public class SwitchersActivity extends Activity {
	private Button btnAvanzar;
	private ImageSwitcher imageSwitcher;
	private TextSwitcher textSwitcher;
	private String[] textos;
	private String[] imagenes;
	private int current = 0;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        textos = new String[]{"Messi","Xabi","Cristiano"};
        imagenes = new String[]{"messi","xabi","cristiano"};
        
        btnAvanzar = (Button) findViewById(R.id.button1);
        imageSwitcher = (ImageSwitcher) findViewById(R.id.imageSwitcher1);
		imageSwitcher.setFactory(new MiImageSwitcherFactory());

		textSwitcher = (TextSwitcher) findViewById(R.id.textSwitcher1);
   		textSwitcher.setFactory(new MiTextSwitcherFactory());
   		textSwitcher.setCurrentText("Texto inicial");

 
    }
    
    public void adelante(View v) {
    	textSwitcher.setText(textos[current]);

    	if (current < textos.length-1) {
            current++;
    	} else {
    		current = 0;
    	}

	}


    /**
     * MiTextSwitcherFactory
     * 
     * Genera el siguiente View de tipo TextSwitcher
     * 
     */
    	private class MiImageSwitcherFactory implements ViewSwitcher.ViewFactory {
    		public View makeView() {
    			   ImageView imageView = new ImageView(SwitchersActivity.this);
    		        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
    		        imageView .setLayoutParams(new ImageSwitcher.LayoutParams(
    		            LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
    		        return imageView ;
    		        
    		}
    	}

    	/**
    	 * MiTextSwitcherFactory
    	 * 
    	 * Genera el siguiente View de tipo TextSwitcher
    	 * 
    	 */
    	private class MiTextSwitcherFactory implements ViewSwitcher.ViewFactory {
    		public View makeView() {
    			TextView textView = new TextView(SwitchersActivity.this);
    			textView.setGravity(Gravity.CENTER);
    			return textView;

    		}
    	}
    	

}


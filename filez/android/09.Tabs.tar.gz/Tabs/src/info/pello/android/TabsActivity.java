package info.pello.android;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class TabsActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        TabHost host = (TabHost) findViewById(R.id.LosTabs);
        host.setup();

        TabSpec tab1 = host.newTabSpec("tab1");
        tab1.setIndicator(getResources().getString(R.string.tab1));
        tab1.setContent(R.id.ScrollView1);
        host.addTab(tab1);

        TabSpec tab2 = host.newTabSpec("tab2");
        tab2.setIndicator(getResources().getString(R.string.tab2));
        tab2.setContent(R.id.ScrollView2);
        host.addTab(tab2);

        TabSpec tab3 = host.newTabSpec("tab3");
        tab3.setIndicator(getResources().getString(R.string.tab3));
        tab3.setContent(R.id.ScrollView3);
        host.addTab(tab3);

    }
}
package info.pello.android;

import java.util.Iterator;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;

public class MapasActivity extends Activity {
	
	// Las cajas de texto
	private EditText etLugar;
	private EditText etCoordenadas;
	private TextView tvPosibles;
	private GPSCoords coordenadas;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        etLugar = (EditText) this.findViewById(R.id.etBuscar);
        etCoordenadas = (EditText) this.findViewById(R.id.etCoordenadas);
        tvPosibles = (TextView) this.findViewById(R.id.tvPosibles);
    }
    
    /**
     * abrirMapa
     * Abre la aplicación del mapa
     * @param v
     */
    public void abrirMapa (View v) {
    	   // Try to resolve string into GPS coords
        //String placeToFind = etLugar.getText().toString();
        //buscarLugar(v);


        //etCoordenadas.setText(coordenadas.toString());
        coordenadas.mLat = 1.0f;
        coordenadas.mLon = 1.0f;
        try  {
        // Launch map with gps coords
        String geoURI = String.format("geo:%f,%f?z=10", coordenadas.mLat, coordenadas.mLon);
        Uri geo = Uri.parse(geoURI);
        Intent geoMap = new Intent(Intent.ACTION_VIEW, geo);
        startActivity(geoMap);
        } catch (NullPointerException npe) {
        	Log.e("debug","Mensaje npe: " + npe.getMessage());
        } catch (Exception ex) {
        	Log.e("debug","Mensaje ex: " + ex.getMessage());
        }
    }

    /**
     * buscarLugar
     * @param v
     */
    public void buscarLugar (View v) {
    	tvPosibles.setText("Buscando...");
    	final Geocoder coder = new Geocoder(getApplicationContext());
        boolean bResolvedAddress = false;
    	GPSCoords mFavPlaceCoords;
    	String resultado = "";
    	int i = 1;
    	
        try {

            List<Address> geocodeResults = coder.getFromLocationName(etLugar.getText().toString(), 1);
            Iterator<Address> locations = geocodeResults.iterator();

            while (locations.hasNext()) {
                Address loc = locations.next();
                mFavPlaceCoords = new GPSCoords((float) loc.getLatitude(), (float) loc.getLongitude());
                resultado += i + "." + mFavPlaceCoords.toString() + "\n";
                bResolvedAddress = true;
                i++;
            }
            tvPosibles.setText(resultado);
        } catch (Exception e) {
            Log.e("debug", "Failed to geocode location", e);
            coordenadasActuales();
        }
    	
    }

    
    /**
     * coordenadasActuales
     * saca las últimas coordenadas conocidas por el dispositivo
     */
    private void coordenadasActuales() {
        float lat = 0, lon = 0;

        try {
            LocationManager locMgr = (LocationManager) getSystemService(LOCATION_SERVICE);
            Location recentLoc = locMgr.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            lat = (float) recentLoc.getLatitude();
            lon = (float) recentLoc.getLongitude();
        } catch (Exception e) {
            Log.e("debug", "Location failed", e);
        }
        coordenadas = new GPSCoords(lat, lon);
        tvPosibles.setText(coordenadas.toString());

    }

    
    private class GPSCoords {
        float mLat, mLon;

        GPSCoords(float lat, float lon) {
            mLat = lat;
            mLon = lon;

        }
        public String toString () {
        	return mLat +":"+mLon;
        }
    }
    
}
package info.pello.android;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MostrarFicheroActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        InputStream iFile = getResources().openRawResource(R.raw.texto);
        TextView helpText = (TextView) findViewById(R.id.fichero_ejemplo);
        String strFile = leerFichero(iFile);
        helpText.setText(strFile);
        
    }

    /**
     * leerFichero
     * Versión rápida tal y como se cuenta en:
     * http://weblogs.java.net/blog/pat/archive/2004/10/stupid_scanner_1.html
     * @param iFile
     * @return
     */
	private String leerFichero(InputStream iFile) {
	    	    try {
	    	        return new java.util.Scanner(iFile,"UTF-8").useDelimiter("\\A").next();
	    	    } catch (java.util.NoSuchElementException e) {
	    	        return "";
	    	    } 
	      
	  }
}
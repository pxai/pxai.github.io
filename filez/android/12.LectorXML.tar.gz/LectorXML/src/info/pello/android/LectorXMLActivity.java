package info.pello.android;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Hashtable;

import org.xmlpull.v1.XmlPullParserException;
import android.app.Activity;
import android.content.res.XmlResourceParser;
import android.os.Bundle;
import android.widget.TextView;

public class LectorXMLActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        TextView txtvFichero = (TextView) this.findViewById(R.id.txtvFichero);
        
        txtvFichero.setText(cargarXML());
    }
    
    private String cargarXML () {
    	String resultado = "";
    	
    	 // TODO: Contact the server and retrieve a batch of question data, beginning at startQuestionNumber
        XmlResourceParser ficheroXML;

        try {
	        ficheroXML = getResources().getXml(R.xml.items);
	
	        // Parse the XML
	        int eventType = -1;
	
	        // Vamos leyendo
	        while (eventType != XmlResourceParser.END_DOCUMENT) {
	            if (eventType == XmlResourceParser.START_TAG) {
	
	                // Get the name of the tag (eg questions or question)
	                String strName = ficheroXML.getName();
	
	                if (strName.equals("item")) {
	
	                    String numero = ficheroXML.getAttributeValue(null, "id");
	                    String texto = ficheroXML.getAttributeValue(null, "texto");
	                    String url = ficheroXML.getAttributeValue(null, "url");
	
	                    resultado += "nº:" + numero + ". Texto:" + texto + " url:" + url + "\n";
	                    
	                }
	            }
	            eventType = ficheroXML.next();
	        }
	        
        } catch (XmlPullParserException xmle) {
        	resultado += xmle.getMessage();
        } catch (IOException ioex) {
        	resultado += ioex.getMessage();        	
        }
        
    	return resultado;
    }
}
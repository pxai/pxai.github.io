package info.pello.android;

import java.util.Enumeration;
import java.util.Vector;

public class Dados extends Vector<Dado>  {

	private int _total;
	private int _caras;
	
	/**
	 * Dados
	 * Constructor por defecto
	 */
	Dados () {
		super();
		_total = 1;
		_caras = 6;
		init();
	}
	
	/**
	 * Dados
	 * Constructor con parámetro
	 * @param int total
	 */
	Dados (int total) {
		super();
		_total = total;
		_caras = 6;
		init();
	}

	/**
	 * Dados
	 * Constructor con parámetro
	 * @param int total
	 * @param int caras
	 */
	Dados (int total, int caras) {
		_total = total;
		_caras = caras;
		init();
	}
	
	private void init () {
		for (int i=0;i<_total;i++) {
			meter(new Dado(_caras));
		}
	}
	
	/**
	 * meter
	 * Mete un nuevo dado en el conjunto
	 */
	public void meter (Dado dado) {
		this.addElement(dado);
	}

	/**
	 * lanzar
	 * Lanza los dados del conjunto
	 * y devuelve un string
	 */
	public String lanzar () {
		String resultado = "";
		
		for (int i=0; i< this.size();i++) {
			resultado += i +" : "+this.elementAt(i).roll()+"\n";
		}
		
		return resultado;
	}
	
	
}

package info.pello.android;

import java.util.Random;

public class Dado {
	private int _caras;
	
	/**
	 * Dado
	 * Constructor por defecto
	 */
	Dado () {
		_caras = 6;
	}
	
	/**
	 * Dado
	 * Constructor con parámetros
	 * @param caras
	 */
	Dado (int caras){
		_caras = caras;
	}
	
	/**
	 * roll
	 * lanzar el dado, devuelve el resultado
	 * @return
	 */
	public int roll () {
		int resultado = 0;
		Random random = new Random();
		
		resultado = random.nextInt(_caras) + 1;
		
		return resultado;
	}
	
}

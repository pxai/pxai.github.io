package info.pello.android;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Locale;

public class DadosActivity extends Activity {
	private TextView tvResult;
	private TextView tvLocale;
	private EditText etDiceType;
	private EditText etDiceQty;
	private Dados dados;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        
        tvLocale = (TextView) findViewById(R.id.tvLocale);
        tvResult = (TextView) findViewById(R.id.tvResult);
        etDiceType = (EditText) findViewById(R.id.etDiceType);
        etDiceQty = (EditText) findViewById(R.id.etDiceQty);
     
        
        // info de las locales
        Configuration configuracion = getResources().getConfiguration();
        Locale localizacion = configuracion.locale;
        
        tvLocale.setText(localizacion.getCountry() +","+localizacion.getDisplayLanguage());

   }
    
    /**
     * roll
     * Se llama al pulsar el botón
     * @param v
     */
    public void roll (View v) {
    	int caras = 0;
    	int cantidad = 0;
    	try {
    		caras = Integer.parseInt(etDiceType.getText().toString());
    		cantidad = Integer.parseInt(etDiceQty.getText().toString());
    	} catch (Exception ex) {
    		caras = 6;
    		cantidad = 2;
    	}
    	
    	dados = new Dados(cantidad, caras);
    	
    	tvResult.setText(dados.lanzar());
    }
}